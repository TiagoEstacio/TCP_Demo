/* =============================================================================
   TCP Parameters Matrix - reference data model for SQL Server
   -----------------------------------------------------------------------------
   Purpose  : Reference schema for the TCP (Target Candidate Profile) validation
              matrix. In OutSystems, create the entities in Service Studio from
              this model (OutSystems owns the physical OSUSR_* tables). Use the
              views and procedures below as the source for Advanced SQL nodes,
              or deploy them on an external database consumed via Integration
              Builder.
   Sections : 1. Static entities (OutSystems Static Entities) + seed data
              2. Reference entities (Program, Target, Pillar, Unit, Attribute)
              3. Versioned matrix (Tcp, TcpVersion and children)
              4. Experiments and scoring results
              5. Indexes
              6. Views (flattened facts for comparison)
              7. Procedures (create draft, publish, compare, score)
   Notes    : - LineageKey is uniqueidentifier here; in OutSystems use Text(36).
              - Audit "user" columns hold the OutSystems {User}.Id (int).
              - CHECK constraints / filtered indexes document the rules; in
                OutSystems enforce them in server actions.
   ============================================================================= */
SET NOCOUNT ON;
GO

/* =============================================================================
   1. STATIC ENTITIES
   ============================================================================= */

CREATE TABLE dbo.AttributeDataType (
    Id          int           NOT NULL CONSTRAINT PK_AttributeDataType PRIMARY KEY,
    Code        varchar(20)   NOT NULL CONSTRAINT UQ_AttributeDataType_Code UNIQUE,
    Label       nvarchar(50)  NOT NULL,
    SortOrder   int           NOT NULL,
    IsActive    bit           NOT NULL CONSTRAINT DF_AttributeDataType_IsActive DEFAULT (1)
);

CREATE TABLE dbo.ComparisonOperator (
    Id          int           NOT NULL CONSTRAINT PK_ComparisonOperator PRIMARY KEY,
    Code        varchar(20)   NOT NULL CONSTRAINT UQ_ComparisonOperator_Code UNIQUE,
    Label       nvarchar(50)  NOT NULL,
    Symbol      nvarchar(10)  NOT NULL,
    ValueCount  tinyint       NOT NULL CONSTRAINT CK_ComparisonOperator_ValueCount CHECK (ValueCount BETWEEN 0 AND 2),
    ForNumeric  bit           NOT NULL,
    ForText     bit           NOT NULL,
    ForBoolean  bit           NOT NULL,
    SortOrder   int           NOT NULL,
    IsActive    bit           NOT NULL CONSTRAINT DF_ComparisonOperator_IsActive DEFAULT (1)
);

CREATE TABLE dbo.RatingLevel (
    Id              int           NOT NULL CONSTRAINT PK_RatingLevel PRIMARY KEY,
    Code            varchar(20)   NOT NULL CONSTRAINT UQ_RatingLevel_Code UNIQUE,
    Label           nvarchar(50)  NOT NULL,
    ScoreFactor     decimal(5,4)  NOT NULL CONSTRAINT CK_RatingLevel_ScoreFactor CHECK (ScoreFactor BETWEEN 0 AND 1),
    EvaluationOrder int           NOT NULL,
    ColorToken      varchar(30)   NOT NULL,
    IsActive        bit           NOT NULL CONSTRAINT DF_RatingLevel_IsActive DEFAULT (1)
);

CREATE TABLE dbo.CriticalityLevel (
    Id              int           NOT NULL CONSTRAINT PK_CriticalityLevel PRIMARY KEY,
    Code            varchar(20)   NOT NULL CONSTRAINT UQ_CriticalityLevel_Code UNIQUE,
    Label           nvarchar(50)  NOT NULL,
    DefaultWeight   decimal(9,4)  NOT NULL CONSTRAINT CK_CriticalityLevel_DefaultWeight CHECK (DefaultWeight >= 0),
    SortOrder       int           NOT NULL,
    IsActive        bit           NOT NULL CONSTRAINT DF_CriticalityLevel_IsActive DEFAULT (1)
);

CREATE TABLE dbo.CriterionType (
    Id               int           NOT NULL CONSTRAINT PK_CriterionType PRIMARY KEY,
    Code             varchar(30)   NOT NULL CONSTRAINT UQ_CriterionType_Code UNIQUE,
    Label            nvarchar(100) NOT NULL,
    AllowsAttributes bit           NOT NULL,
    IsGoNoGo         bit           NOT NULL,
    SortOrder        int           NOT NULL,
    IsActive         bit           NOT NULL CONSTRAINT DF_CriterionType_IsActive DEFAULT (1)
);

CREATE TABLE dbo.TcpVersionStatus (
    Id          int           NOT NULL CONSTRAINT PK_TcpVersionStatus PRIMARY KEY,
    Code        varchar(20)   NOT NULL CONSTRAINT UQ_TcpVersionStatus_Code UNIQUE,
    Label       nvarchar(50)  NOT NULL,
    IsEditable  bit           NOT NULL,
    SortOrder   int           NOT NULL,
    IsActive    bit           NOT NULL CONSTRAINT DF_TcpVersionStatus_IsActive DEFAULT (1)
);

CREATE TABLE dbo.ExperimentOutcome (
    Id          int           NOT NULL CONSTRAINT PK_ExperimentOutcome PRIMARY KEY,
    Code        varchar(20)   NOT NULL CONSTRAINT UQ_ExperimentOutcome_Code UNIQUE,
    Label       nvarchar(50)  NOT NULL,
    SortOrder   int           NOT NULL,
    IsActive    bit           NOT NULL CONSTRAINT DF_ExperimentOutcome_IsActive DEFAULT (1)
);

CREATE TABLE dbo.ChangeType (
    Id          int           NOT NULL CONSTRAINT PK_ChangeType PRIMARY KEY,
    Code        varchar(20)   NOT NULL CONSTRAINT UQ_ChangeType_Code UNIQUE,
    Label       nvarchar(50)  NOT NULL,
    SortOrder   int           NOT NULL,
    IsActive    bit           NOT NULL CONSTRAINT DF_ChangeType_IsActive DEFAULT (1)
);
GO

/* ---- Static seed data (mirror these records in the OutSystems Static Entities) ---- */
INSERT INTO dbo.AttributeDataType (Id, Code, Label, SortOrder) VALUES
    (1, 'NUMERIC',  N'Numeric',            1),
    (2, 'TEXT',     N'Text',               2),
    (3, 'PRESENCE', N'Presence (exists)',  3);

INSERT INTO dbo.ComparisonOperator (Id, Code, Label, Symbol, ValueCount, ForNumeric, ForText, ForBoolean, SortOrder) VALUES
    ( 1, 'LT',         N'Lower than',          N'<',      1, 1, 0, 0,  1),
    ( 2, 'LTE',        N'Lower or equal',      N'<=',     1, 1, 0, 0,  2),
    ( 3, 'GT',         N'Greater than',        N'>',      1, 1, 0, 0,  3),
    ( 4, 'GTE',        N'Greater or equal',    N'>=',     1, 1, 0, 0,  4),
    ( 5, 'EQ',         N'Equal to',            N'=',      1, 1, 1, 0,  5),
    ( 6, 'NEQ',        N'Not equal to',        N'<>',     1, 1, 1, 0,  6),
    ( 7, 'BETWEEN',    N'Between (inclusive)', N'[a,b]',  2, 1, 0, 0,  7),
    ( 8, 'OUTSIDE',    N'Outside range',       N']a,b[',  2, 1, 0, 0,  8),
    ( 9, 'CONTAINS',   N'Contains text',       N'~',      1, 0, 1, 0,  9),
    (10, 'EXISTS',     N'Exists',              N'yes',    0, 0, 0, 1, 10),
    (11, 'NOT_EXISTS', N'Does not exist',      N'no',     0, 0, 0, 1, 11);

INSERT INTO dbo.RatingLevel (Id, Code, Label, ScoreFactor, EvaluationOrder, ColorToken) VALUES
    (1, 'GOOD',   N'Good',   1.0000, 1, 'status-good'),
    (2, 'MEDIUM', N'Medium', 0.5000, 2, 'status-warning'),
    (3, 'BAD',    N'Bad',    0.0000, 3, 'status-critical');

INSERT INTO dbo.CriticalityLevel (Id, Code, Label, DefaultWeight, SortOrder) VALUES
    (1, 'LOW',    N'Low',    1.0000, 1),
    (2, 'MEDIUM', N'Medium', 2.0000, 2),
    (3, 'HIGH',   N'High',   3.0000, 3);

INSERT INTO dbo.CriterionType (Id, Code, Label, AllowsAttributes, IsGoNoGo, SortOrder) VALUES
    (1, 'KEY_QUANT',      N'Key Quantitative Parameters',    1, 0, 1),
    (2, 'KEY_COMPETITOR', N'Key Competitor Parameters',      1, 0, 2),
    (3, 'GO_NO_GO',       N'Quantitative Go/No-Go Criteria', 1, 1, 3),
    (4, 'RATIONALE',      N'Rationale',                      0, 0, 4);

INSERT INTO dbo.TcpVersionStatus (Id, Code, Label, IsEditable, SortOrder) VALUES
    (1, 'DRAFT',      N'Draft',      1, 1),
    (2, 'IN_REVIEW',  N'In Review',  0, 2),
    (3, 'PUBLISHED',  N'Published',  0, 3),
    (4, 'SUPERSEDED', N'Superseded', 0, 4),
    (5, 'ARCHIVED',   N'Archived',   0, 5);

INSERT INTO dbo.ExperimentOutcome (Id, Code, Label, SortOrder) VALUES
    (1, 'GO',         N'Go',         1),
    (2, 'NO_GO',      N'No-Go',      2),
    (3, 'INCOMPLETE', N'Incomplete', 3);

INSERT INTO dbo.ChangeType (Id, Code, Label, SortOrder) VALUES
    (1, 'ADDED',     N'Added',     1),
    (2, 'REMOVED',   N'Removed',   2),
    (3, 'MODIFIED',  N'Modified',  3),
    (4, 'UNCHANGED', N'Unchanged', 4);
GO

/* =============================================================================
   2. REFERENCE ENTITIES (user-extensible master data, not versioned)
   ============================================================================= */

CREATE TABLE dbo.Program (
    Id          bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Program PRIMARY KEY,
    Code        nvarchar(30)   NULL,              -- NULL for a new program (name only)
    Name        nvarchar(200)  NOT NULL,
    IsExisting  bit            NOT NULL,          -- 1 = existing research program
    ExternalRef nvarchar(50)   NULL,              -- id in the portfolio system, if any
    IsActive    bit            NOT NULL CONSTRAINT DF_Program_IsActive DEFAULT (1),
    CreatedBy   int            NOT NULL,
    CreatedOn   datetime2(3)   NOT NULL CONSTRAINT DF_Program_CreatedOn DEFAULT (SYSUTCDATETIME()),
    UpdatedBy   int            NULL,
    UpdatedOn   datetime2(3)   NULL,
    CONSTRAINT CK_Program_ExistingHasCode CHECK (IsExisting = 0 OR Code IS NOT NULL)
);
CREATE UNIQUE INDEX UX_Program_Code       ON dbo.Program (Code) WHERE Code IS NOT NULL;
CREATE UNIQUE INDEX UX_Program_NameNoCode ON dbo.Program (Name) WHERE Code IS NULL;

CREATE TABLE dbo.Target (
    Id          bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Target PRIMARY KEY,
    ProgramId   bigint         NOT NULL CONSTRAINT FK_Target_Program REFERENCES dbo.Program (Id),
    Name        nvarchar(200)  NOT NULL,
    Description nvarchar(2000) NULL,
    IsActive    bit            NOT NULL CONSTRAINT DF_Target_IsActive DEFAULT (1),
    CreatedBy   int            NOT NULL,
    CreatedOn   datetime2(3)   NOT NULL CONSTRAINT DF_Target_CreatedOn DEFAULT (SYSUTCDATETIME()),
    UpdatedBy   int            NULL,
    UpdatedOn   datetime2(3)   NULL,
    CONSTRAINT UQ_Target_Program_Name UNIQUE (ProgramId, Name)
);

CREATE TABLE dbo.Pillar (
    Id          int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Pillar PRIMARY KEY,
    Name        nvarchar(100)  NOT NULL CONSTRAINT UQ_Pillar_Name UNIQUE,
    Description nvarchar(1000) NULL,
    IsSystem    bit            NOT NULL CONSTRAINT DF_Pillar_IsSystem DEFAULT (0),  -- 0 = custom
    IsActive    bit            NOT NULL CONSTRAINT DF_Pillar_IsActive DEFAULT (1),
    SortOrder   int            NOT NULL CONSTRAINT DF_Pillar_SortOrder DEFAULT (100),
    CreatedBy   int            NULL,
    CreatedOn   datetime2(3)   NOT NULL CONSTRAINT DF_Pillar_CreatedOn DEFAULT (SYSUTCDATETIME())
);

CREATE TABLE dbo.Unit (
    Id          int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Unit PRIMARY KEY,
    Symbol      nvarchar(20)   NOT NULL CONSTRAINT UQ_Unit_Symbol UNIQUE,
    Name        nvarchar(100)  NOT NULL,
    IsActive    bit            NOT NULL CONSTRAINT DF_Unit_IsActive DEFAULT (1)
);

CREATE TABLE dbo.Attribute (
    Id            int IDENTITY(1,1) NOT NULL CONSTRAINT PK_Attribute PRIMARY KEY,
    Name          nvarchar(200)  NOT NULL,
    Description   nvarchar(1000) NULL,
    DataTypeId    int            NOT NULL CONSTRAINT FK_Attribute_DataType REFERENCES dbo.AttributeDataType (Id),
    DefaultUnitId int            NULL     CONSTRAINT FK_Attribute_Unit     REFERENCES dbo.Unit (Id),
    IsSystem      bit            NOT NULL CONSTRAINT DF_Attribute_IsSystem DEFAULT (0),
    IsActive      bit            NOT NULL CONSTRAINT DF_Attribute_IsActive DEFAULT (1),
    CreatedBy     int            NULL,
    CreatedOn     datetime2(3)   NOT NULL CONSTRAINT DF_Attribute_CreatedOn DEFAULT (SYSUTCDATETIME()),
    UpdatedBy     int            NULL,
    UpdatedOn     datetime2(3)   NULL
);
CREATE UNIQUE INDEX UX_Attribute_Name_Unit ON dbo.Attribute (Name, DefaultUnitId);
GO

/* Seed: predefined pillars (users can add custom ones with IsSystem = 0) */
INSERT INTO dbo.Pillar (Name, IsSystem, SortOrder) VALUES
    (N'Safety',        1, 1),
    (N'Potency',       1, 2),
    (N'Selectivity',   1, 3),
    (N'PK/ADME',       1, 4),
    (N'Developability',1, 5),
    (N'Efficacy',      1, 6);

INSERT INTO dbo.Unit (Symbol, Name) VALUES
    (N'nM', N'Nanomolar'), (N'uM', N'Micromolar'), (N'%', N'Percent'),
    (N'h', N'Hours'), (N'mg/kg', N'Milligram per kilogram'), (N'mL/min/kg', N'Clearance'),
    (N'fold', N'Fold ratio');
GO

/* =============================================================================
   3. VERSIONED MATRIX
   Tcp (header) -> TcpVersion (immutable once published) -> TcpPillar
   -> TcpCriterion -> TcpCriterionAttribute -> TcpAttributeRule
   Every row under TcpVersion carries a LineageKey that is copied unchanged to
   the next version: it identifies "the same logical item" across versions.
   ============================================================================= */

CREATE TABLE dbo.Tcp (
    Id                        bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Tcp PRIMARY KEY,
    TargetId                  bigint         NOT NULL CONSTRAINT FK_Tcp_Target REFERENCES dbo.Target (Id),
    Name                      nvarchar(200)  NOT NULL,
    Description               nvarchar(2000) NULL,
    CurrentPublishedVersionId bigint         NULL,     -- FK added after TcpVersion exists
    CreatedBy                 int            NOT NULL,
    CreatedOn                 datetime2(3)   NOT NULL CONSTRAINT DF_Tcp_CreatedOn DEFAULT (SYSUTCDATETIME()),
    UpdatedBy                 int            NULL,
    UpdatedOn                 datetime2(3)   NULL,
    CONSTRAINT UQ_Tcp_Target_Name UNIQUE (TargetId, Name)
);

CREATE TABLE dbo.TcpVersion (
    Id               bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_TcpVersion PRIMARY KEY,
    TcpId            bigint          NOT NULL CONSTRAINT FK_TcpVersion_Tcp      REFERENCES dbo.Tcp (Id),
    VersionNumber    int             NOT NULL,
    StatusId         int             NOT NULL CONSTRAINT FK_TcpVersion_Status   REFERENCES dbo.TcpVersionStatus (Id),
    BasedOnVersionId bigint          NULL     CONSTRAINT FK_TcpVersion_BasedOn  REFERENCES dbo.TcpVersion (Id),
    ChangeSummary    nvarchar(2000)  NULL,
    SnapshotJson     nvarchar(max)   NULL,     -- optional frozen copy written on Publish
    SnapshotHash     varbinary(32)   NULL,     -- SHA2_256 of SnapshotJson
    CreatedBy        int             NOT NULL,
    CreatedOn        datetime2(3)    NOT NULL CONSTRAINT DF_TcpVersion_CreatedOn DEFAULT (SYSUTCDATETIME()),
    SubmittedBy      int             NULL,
    SubmittedOn      datetime2(3)    NULL,
    PublishedBy      int             NULL,
    PublishedOn      datetime2(3)    NULL,
    CONSTRAINT UQ_TcpVersion_Tcp_Number UNIQUE (TcpId, VersionNumber)
);
-- At most one open (Draft or In Review) version per TCP
CREATE UNIQUE INDEX UX_TcpVersion_OneOpen ON dbo.TcpVersion (TcpId) WHERE StatusId IN (1, 2);
-- At most one Published version per TCP
CREATE UNIQUE INDEX UX_TcpVersion_OnePublished ON dbo.TcpVersion (TcpId) WHERE StatusId = 3;

ALTER TABLE dbo.Tcp ADD CONSTRAINT FK_Tcp_CurrentPublishedVersion
    FOREIGN KEY (CurrentPublishedVersionId) REFERENCES dbo.TcpVersion (Id);

CREATE TABLE dbo.TcpVersionCriticalityWeight (
    Id                 bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_TcpVersionCriticalityWeight PRIMARY KEY,
    TcpVersionId       bigint        NOT NULL CONSTRAINT FK_TVCW_Version     REFERENCES dbo.TcpVersion (Id),
    CriticalityLevelId int           NOT NULL CONSTRAINT FK_TVCW_Criticality REFERENCES dbo.CriticalityLevel (Id),
    Weight             decimal(9,4)  NOT NULL CONSTRAINT CK_TVCW_Weight CHECK (Weight >= 0),
    CONSTRAINT UQ_TVCW_Version_Level UNIQUE (TcpVersionId, CriticalityLevelId)
);

CREATE TABLE dbo.TcpPillar (
    Id                 bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_TcpPillar PRIMARY KEY,
    TcpVersionId       bigint           NOT NULL CONSTRAINT FK_TcpPillar_Version REFERENCES dbo.TcpVersion (Id),
    LineageKey         uniqueidentifier NOT NULL CONSTRAINT DF_TcpPillar_LineageKey DEFAULT (NEWID()),
    PillarId           int              NOT NULL CONSTRAINT FK_TcpPillar_Pillar  REFERENCES dbo.Pillar (Id),
    Weight             decimal(9,4)     NOT NULL CONSTRAINT CK_TcpPillar_Weight CHECK (Weight >= 0),
    KeyDesignPrinciple nvarchar(2000)   NOT NULL,   -- the question this pillar parametrizes
    SortOrder          int              NOT NULL CONSTRAINT DF_TcpPillar_SortOrder DEFAULT (0),
    CreatedBy          int              NULL,
    CreatedOn          datetime2(3)     NOT NULL CONSTRAINT DF_TcpPillar_CreatedOn DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT UQ_TcpPillar_Version_Pillar  UNIQUE (TcpVersionId, PillarId),
    CONSTRAINT UQ_TcpPillar_Version_Lineage UNIQUE (TcpVersionId, LineageKey)
);

CREATE TABLE dbo.TcpCriterion (
    Id              bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_TcpCriterion PRIMARY KEY,
    TcpPillarId     bigint           NOT NULL CONSTRAINT FK_TcpCriterion_Pillar REFERENCES dbo.TcpPillar (Id),
    LineageKey      uniqueidentifier NOT NULL CONSTRAINT DF_TcpCriterion_LineageKey DEFAULT (NEWID()),
    CriterionTypeId int              NOT NULL CONSTRAINT FK_TcpCriterion_Type   REFERENCES dbo.CriterionType (Id),
    [Text]          nvarchar(4000)   NULL,      -- rationale text, or a note for the other types
    SortOrder       int              NOT NULL CONSTRAINT DF_TcpCriterion_SortOrder DEFAULT (0),
    CreatedBy       int              NULL,
    CreatedOn       datetime2(3)     NOT NULL CONSTRAINT DF_TcpCriterion_CreatedOn DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT UQ_TcpCriterion_Pillar_Type    UNIQUE (TcpPillarId, CriterionTypeId),
    CONSTRAINT UQ_TcpCriterion_Pillar_Lineage UNIQUE (TcpPillarId, LineageKey)
);

CREATE TABLE dbo.TcpCriterionAttribute (
    Id                 bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_TcpCriterionAttribute PRIMARY KEY,
    TcpCriterionId     bigint           NOT NULL CONSTRAINT FK_TCA_Criterion   REFERENCES dbo.TcpCriterion (Id),
    LineageKey         uniqueidentifier NOT NULL CONSTRAINT DF_TCA_LineageKey DEFAULT (NEWID()),
    AttributeId        int              NOT NULL CONSTRAINT FK_TCA_Attribute   REFERENCES dbo.Attribute (Id),
    UnitId             int              NULL     CONSTRAINT FK_TCA_Unit        REFERENCES dbo.Unit (Id),
    CriticalityLevelId int              NOT NULL CONSTRAINT FK_TCA_Criticality REFERENCES dbo.CriticalityLevel (Id),
    Notes              nvarchar(2000)   NULL,
    SortOrder          int              NOT NULL CONSTRAINT DF_TCA_SortOrder DEFAULT (0),
    CreatedBy          int              NULL,
    CreatedOn          datetime2(3)     NOT NULL CONSTRAINT DF_TCA_CreatedOn DEFAULT (SYSUTCDATETIME()),
    CONSTRAINT UQ_TCA_Criterion_Attribute UNIQUE (TcpCriterionId, AttributeId),
    CONSTRAINT UQ_TCA_Criterion_Lineage   UNIQUE (TcpCriterionId, LineageKey)
);

CREATE TABLE dbo.TcpAttributeRule (
    Id                      bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_TcpAttributeRule PRIMARY KEY,
    TcpCriterionAttributeId bigint         NOT NULL CONSTRAINT FK_TAR_CriterionAttribute REFERENCES dbo.TcpCriterionAttribute (Id),
    RatingLevelId           int            NOT NULL CONSTRAINT FK_TAR_Rating   REFERENCES dbo.RatingLevel (Id),
    OperatorId              int            NOT NULL CONSTRAINT FK_TAR_Operator REFERENCES dbo.ComparisonOperator (Id),
    NumericValue            decimal(28,8)  NULL,
    NumericValueTo          decimal(28,8)  NULL,   -- only for BETWEEN / OUTSIDE
    TextValue               nvarchar(500)  NULL,   -- only for text operators
    Comment                 nvarchar(1000) NULL,
    CONSTRAINT UQ_TAR_Attribute_Rating UNIQUE (TcpCriterionAttributeId, RatingLevelId),
    CONSTRAINT CK_TAR_Range CHECK (NumericValueTo IS NULL OR NumericValue IS NULL OR NumericValueTo >= NumericValue)
);
GO

/* =============================================================================
   4. EXPERIMENTS AND SCORING RESULTS
   ============================================================================= */

CREATE TABLE dbo.Experiment (
    Id           bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_Experiment PRIMARY KEY,
    TcpVersionId bigint         NOT NULL CONSTRAINT FK_Experiment_Version REFERENCES dbo.TcpVersion (Id),  -- pinned version
    Name         nvarchar(200)  NOT NULL,
    ExternalRef  nvarchar(100)  NULL,     -- ELN / LIMS id
    CompoundRef  nvarchar(100)  NULL,
    RunDate      date           NULL,
    Notes        nvarchar(4000) NULL,
    TotalScore   decimal(9,4)   NULL,     -- 0..100, result snapshot
    Coverage     decimal(5,4)   NULL,     -- rated / total attributes
    OutcomeId    int            NULL CONSTRAINT FK_Experiment_Outcome REFERENCES dbo.ExperimentOutcome (Id),
    ScoredOn     datetime2(3)   NULL,
    CreatedBy    int            NOT NULL,
    CreatedOn    datetime2(3)   NOT NULL CONSTRAINT DF_Experiment_CreatedOn DEFAULT (SYSUTCDATETIME()),
    UpdatedBy    int            NULL,
    UpdatedOn    datetime2(3)   NULL
);

CREATE TABLE dbo.ExperimentMeasurement (
    Id                      bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ExperimentMeasurement PRIMARY KEY,
    ExperimentId            bigint         NOT NULL CONSTRAINT FK_EM_Experiment         REFERENCES dbo.Experiment (Id),
    TcpCriterionAttributeId bigint         NOT NULL CONSTRAINT FK_EM_CriterionAttribute REFERENCES dbo.TcpCriterionAttribute (Id),
    NumericValue            decimal(28,8)  NULL,
    TextValue               nvarchar(500)  NULL,
    IsPresent               bit            NULL,
    RatingLevelId           int            NULL CONSTRAINT FK_EM_Rating REFERENCES dbo.RatingLevel (Id),  -- computed
    Comment                 nvarchar(1000) NULL,
    CONSTRAINT UQ_EM_Experiment_Attribute UNIQUE (ExperimentId, TcpCriterionAttributeId)
);

CREATE TABLE dbo.ExperimentPillarScore (
    Id           bigint IDENTITY(1,1) NOT NULL CONSTRAINT PK_ExperimentPillarScore PRIMARY KEY,
    ExperimentId bigint        NOT NULL CONSTRAINT FK_EPS_Experiment REFERENCES dbo.Experiment (Id),
    TcpPillarId  bigint        NOT NULL CONSTRAINT FK_EPS_Pillar     REFERENCES dbo.TcpPillar (Id),
    Score        decimal(9,4)  NULL,      -- 0..1, NULL when nothing rated
    RatedCount   int           NOT NULL,
    TotalCount   int           NOT NULL,
    CONSTRAINT UQ_EPS_Experiment_Pillar UNIQUE (ExperimentId, TcpPillarId)
);
GO

/* =============================================================================
   5. INDEXES (FK lookups and lineage history)
   ============================================================================= */
CREATE INDEX IX_Target_ProgramId              ON dbo.Target (ProgramId);
CREATE INDEX IX_Tcp_TargetId                  ON dbo.Tcp (TargetId);
CREATE INDEX IX_TcpVersion_Tcp_Status         ON dbo.TcpVersion (TcpId, StatusId);
CREATE INDEX IX_TcpPillar_LineageKey          ON dbo.TcpPillar (LineageKey);
CREATE INDEX IX_TcpCriterion_LineageKey       ON dbo.TcpCriterion (LineageKey);
CREATE INDEX IX_TCA_LineageKey                ON dbo.TcpCriterionAttribute (LineageKey);
CREATE INDEX IX_TCA_AttributeId               ON dbo.TcpCriterionAttribute (AttributeId);
CREATE INDEX IX_Experiment_TcpVersionId       ON dbo.Experiment (TcpVersionId);
CREATE INDEX IX_EM_CriterionAttribute         ON dbo.ExperimentMeasurement (TcpCriterionAttributeId);
GO

/* =============================================================================
   6. VIEWS
   vw_TcpVersionFacts: every versioned row unpivoted to
   (TcpVersionId, ItemLevel, LineageKey, ItemPath, FieldName, FieldValue).
   Comparing two versions = FULL OUTER JOIN on (ItemLevel, LineageKey, FieldName).
   ============================================================================= */
CREATE OR ALTER VIEW dbo.vw_TcpVersionFacts
AS
/* Pillars */
SELECT  tp.TcpVersionId,
        CAST('Pillar' AS varchar(20))              AS ItemLevel,
        CAST(tp.LineageKey AS varchar(80))         AS LineageKey,
        CAST(p.Name AS nvarchar(400))              AS ItemPath,
        f.FieldName,
        f.FieldValue
FROM    dbo.TcpPillar AS tp
JOIN    dbo.Pillar    AS p ON p.Id = tp.PillarId
CROSS APPLY (VALUES
        (CAST('Pillar' AS varchar(50)),   CAST(p.Name AS nvarchar(4000))),
        ('Weight',                        CONVERT(nvarchar(4000), tp.Weight)),
        ('KeyDesignPrinciple',            CAST(tp.KeyDesignPrinciple AS nvarchar(4000)))
) AS f (FieldName, FieldValue)

UNION ALL
/* Criteria (sections) */
SELECT  tp.TcpVersionId,
        'Criterion',
        CAST(tc.LineageKey AS varchar(80)),
        CAST(p.Name + N' / ' + ct.Label AS nvarchar(400)),
        f.FieldName,
        f.FieldValue
FROM    dbo.TcpCriterion  AS tc
JOIN    dbo.TcpPillar     AS tp ON tp.Id = tc.TcpPillarId
JOIN    dbo.Pillar        AS p  ON p.Id  = tp.PillarId
JOIN    dbo.CriterionType AS ct ON ct.Id = tc.CriterionTypeId
CROSS APPLY (VALUES
        (CAST('CriterionType' AS varchar(50)), CAST(ct.Label AS nvarchar(4000))),
        ('Text',                                CAST(tc.[Text] AS nvarchar(4000)))
) AS f (FieldName, FieldValue)

UNION ALL
/* Attributes */
SELECT  tp.TcpVersionId,
        'Attribute',
        CAST(ta.LineageKey AS varchar(80)),
        CAST(p.Name + N' / ' + ct.Label + N' / ' + a.Name AS nvarchar(400)),
        f.FieldName,
        f.FieldValue
FROM    dbo.TcpCriterionAttribute AS ta
JOIN    dbo.TcpCriterion          AS tc ON tc.Id = ta.TcpCriterionId
JOIN    dbo.TcpPillar             AS tp ON tp.Id = tc.TcpPillarId
JOIN    dbo.Pillar                AS p  ON p.Id  = tp.PillarId
JOIN    dbo.CriterionType         AS ct ON ct.Id = tc.CriterionTypeId
JOIN    dbo.Attribute             AS a  ON a.Id  = ta.AttributeId
JOIN    dbo.CriticalityLevel      AS cl ON cl.Id = ta.CriticalityLevelId
LEFT JOIN dbo.Unit                AS u  ON u.Id  = ta.UnitId
CROSS APPLY (VALUES
        (CAST('Attribute' AS varchar(50)), CAST(a.Name AS nvarchar(4000))),
        ('Unit',                            CAST(u.Symbol AS nvarchar(4000))),
        ('Criticality',                     CAST(cl.Label AS nvarchar(4000))),
        ('Notes',                           CAST(ta.Notes AS nvarchar(4000)))
) AS f (FieldName, FieldValue)

UNION ALL
/* Rules (Good / Medium / Bad); lineage = attribute lineage + rating code */
SELECT  tp.TcpVersionId,
        'Rule',
        CAST(CAST(ta.LineageKey AS varchar(36)) + ':' + rl.Code AS varchar(80)),
        CAST(p.Name + N' / ' + ct.Label + N' / ' + a.Name + N' / ' + rl.Label AS nvarchar(400)),
        f.FieldName,
        f.FieldValue
FROM    dbo.TcpAttributeRule      AS r
JOIN    dbo.TcpCriterionAttribute AS ta ON ta.Id = r.TcpCriterionAttributeId
JOIN    dbo.TcpCriterion          AS tc ON tc.Id = ta.TcpCriterionId
JOIN    dbo.TcpPillar             AS tp ON tp.Id = tc.TcpPillarId
JOIN    dbo.Pillar                AS p  ON p.Id  = tp.PillarId
JOIN    dbo.CriterionType         AS ct ON ct.Id = tc.CriterionTypeId
JOIN    dbo.Attribute             AS a  ON a.Id  = ta.AttributeId
JOIN    dbo.RatingLevel           AS rl ON rl.Id = r.RatingLevelId
JOIN    dbo.ComparisonOperator    AS op ON op.Id = r.OperatorId
CROSS APPLY (VALUES
        (CAST('Condition' AS varchar(50)),
         CAST(CASE op.ValueCount
                WHEN 0 THEN op.Label
                WHEN 2 THEN op.Label + N' ' + CONVERT(nvarchar(50), r.NumericValue)
                              + N' and ' + CONVERT(nvarchar(50), r.NumericValueTo)
                ELSE op.Symbol + N' ' +
                     CASE WHEN a.DataTypeId = 2 THEN N'"' + r.TextValue + N'"'
                          ELSE CONVERT(nvarchar(50), r.NumericValue) END
              END AS nvarchar(4000))),
        ('Comment', CAST(r.Comment AS nvarchar(4000)))
) AS f (FieldName, FieldValue)

UNION ALL
/* Scoring configuration snapshotted in the version */
SELECT  w.TcpVersionId,
        'Scoring',
        CAST('CRITICALITY:' + cl.Code AS varchar(80)),
        CAST(N'Criticality weight / ' + cl.Label AS nvarchar(400)),
        CAST('Weight' AS varchar(50)),
        CONVERT(nvarchar(4000), w.Weight)
FROM    dbo.TcpVersionCriticalityWeight AS w
JOIN    dbo.CriticalityLevel            AS cl ON cl.Id = w.CriticalityLevelId;
GO

/* =============================================================================
   7. PROCEDURES (reference logic for the OutSystems server actions)
   ============================================================================= */

/* ---- 7.1 Compare two versions: field-level changes ---------------------- */
CREATE OR ALTER PROCEDURE dbo.usp_CompareTcpVersions
    @FromVersionId bigint,
    @ToVersionId   bigint,
    @IncludeUnchanged bit = 0
AS
BEGIN
    SET NOCOUNT ON;

    IF (SELECT COUNT(DISTINCT TcpId) FROM dbo.TcpVersion WHERE Id IN (@FromVersionId, @ToVersionId)) <> 1
        THROW 50010, 'Both versions must exist and belong to the same TCP.', 1;

    WITH F AS (SELECT * FROM dbo.vw_TcpVersionFacts WHERE TcpVersionId = @FromVersionId),
         T AS (SELECT * FROM dbo.vw_TcpVersionFacts WHERE TcpVersionId = @ToVersionId)
    SELECT  COALESCE(T.ItemLevel,  F.ItemLevel)  AS ItemLevel,
            COALESCE(T.LineageKey, F.LineageKey) AS LineageKey,
            COALESCE(T.ItemPath,   F.ItemPath)   AS ItemPath,
            COALESCE(T.FieldName,  F.FieldName)  AS FieldName,
            F.FieldValue                         AS OldValue,
            T.FieldValue                         AS NewValue,
            CASE WHEN F.LineageKey IS NULL THEN 'ADDED'
                 WHEN T.LineageKey IS NULL THEN 'REMOVED'
                 WHEN EXISTS (SELECT F.FieldValue EXCEPT SELECT T.FieldValue) THEN 'MODIFIED'
                 ELSE 'UNCHANGED' END            AS ChangeTypeCode
    FROM    F
    FULL OUTER JOIN T
            ON  T.ItemLevel  = F.ItemLevel
            AND T.LineageKey = F.LineageKey
            AND T.FieldName  = F.FieldName
    WHERE   @IncludeUnchanged = 1
         OR F.LineageKey IS NULL
         OR T.LineageKey IS NULL
         OR EXISTS (SELECT F.FieldValue EXCEPT SELECT T.FieldValue)
    ORDER BY ItemPath, ItemLevel, FieldName;
END;
GO

/* ---- 7.2 Create a draft by deep-copying the published version ----------
   The LineageKey doubles as the old->new mapping key, so no id map table is
   needed: each child is attached to the new parent with the same lineage. */
CREATE OR ALTER PROCEDURE dbo.usp_CreateDraftVersion
    @TcpId        bigint,
    @UserId       int,
    @NewVersionId bigint OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @SourceVersionId bigint, @NextNumber int;

    IF EXISTS (SELECT 1 FROM dbo.TcpVersion WHERE TcpId = @TcpId AND StatusId IN (1, 2))
        THROW 50001, 'This TCP already has a Draft or In Review version.', 1;

    SELECT @SourceVersionId = CurrentPublishedVersionId FROM dbo.Tcp WHERE Id = @TcpId;
    SELECT @NextNumber = ISNULL(MAX(VersionNumber), 0) + 1 FROM dbo.TcpVersion WHERE TcpId = @TcpId;

    BEGIN TRANSACTION;

    INSERT INTO dbo.TcpVersion (TcpId, VersionNumber, StatusId, BasedOnVersionId, CreatedBy)
    VALUES (@TcpId, @NextNumber, 1, @SourceVersionId, @UserId);
    SET @NewVersionId = SCOPE_IDENTITY();

    -- scoring weights: copy from source, default from the static entity otherwise
    INSERT INTO dbo.TcpVersionCriticalityWeight (TcpVersionId, CriticalityLevelId, Weight)
    SELECT @NewVersionId, cl.Id, COALESCE(src.Weight, cl.DefaultWeight)
    FROM   dbo.CriticalityLevel AS cl
    LEFT JOIN dbo.TcpVersionCriticalityWeight AS src
           ON src.TcpVersionId = @SourceVersionId AND src.CriticalityLevelId = cl.Id
    WHERE  cl.IsActive = 1;

    IF @SourceVersionId IS NOT NULL
    BEGIN
        INSERT INTO dbo.TcpPillar (TcpVersionId, LineageKey, PillarId, Weight, KeyDesignPrinciple, SortOrder, CreatedBy)
        SELECT @NewVersionId, sp.LineageKey, sp.PillarId, sp.Weight, sp.KeyDesignPrinciple, sp.SortOrder, @UserId
        FROM   dbo.TcpPillar AS sp
        WHERE  sp.TcpVersionId = @SourceVersionId;

        INSERT INTO dbo.TcpCriterion (TcpPillarId, LineageKey, CriterionTypeId, [Text], SortOrder, CreatedBy)
        SELECT np.Id, sc.LineageKey, sc.CriterionTypeId, sc.[Text], sc.SortOrder, @UserId
        FROM   dbo.TcpCriterion AS sc
        JOIN   dbo.TcpPillar    AS sp ON sp.Id = sc.TcpPillarId AND sp.TcpVersionId = @SourceVersionId
        JOIN   dbo.TcpPillar    AS np ON np.LineageKey = sp.LineageKey AND np.TcpVersionId = @NewVersionId;

        INSERT INTO dbo.TcpCriterionAttribute (TcpCriterionId, LineageKey, AttributeId, UnitId, CriticalityLevelId, Notes, SortOrder, CreatedBy)
        SELECT nc.Id, sa.LineageKey, sa.AttributeId, sa.UnitId, sa.CriticalityLevelId, sa.Notes, sa.SortOrder, @UserId
        FROM   dbo.TcpCriterionAttribute AS sa
        JOIN   dbo.TcpCriterion          AS sc ON sc.Id = sa.TcpCriterionId
        JOIN   dbo.TcpPillar             AS sp ON sp.Id = sc.TcpPillarId AND sp.TcpVersionId = @SourceVersionId
        JOIN   dbo.TcpCriterion          AS nc ON nc.LineageKey = sc.LineageKey
        JOIN   dbo.TcpPillar             AS np ON np.Id = nc.TcpPillarId AND np.TcpVersionId = @NewVersionId;

        INSERT INTO dbo.TcpAttributeRule (TcpCriterionAttributeId, RatingLevelId, OperatorId, NumericValue, NumericValueTo, TextValue, Comment)
        SELECT na.Id, sr.RatingLevelId, sr.OperatorId, sr.NumericValue, sr.NumericValueTo, sr.TextValue, sr.Comment
        FROM   dbo.TcpAttributeRule      AS sr
        JOIN   dbo.TcpCriterionAttribute AS sa ON sa.Id = sr.TcpCriterionAttributeId
        JOIN   dbo.TcpCriterion          AS sc ON sc.Id = sa.TcpCriterionId
        JOIN   dbo.TcpPillar             AS sp ON sp.Id = sc.TcpPillarId AND sp.TcpVersionId = @SourceVersionId
        JOIN   dbo.TcpCriterionAttribute AS na ON na.LineageKey = sa.LineageKey
        JOIN   dbo.TcpCriterion          AS nc ON nc.Id = na.TcpCriterionId
        JOIN   dbo.TcpPillar             AS np ON np.Id = nc.TcpPillarId AND np.TcpVersionId = @NewVersionId;
    END;

    COMMIT TRANSACTION;
END;
GO

/* ---- 7.3 Publish a version (validations + status switch) --------------- */
CREATE OR ALTER PROCEDURE dbo.usp_PublishVersion
    @VersionId bigint,
    @UserId    int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @TcpId bigint, @StatusId int, @WeightTotal decimal(19,4);

    SELECT @TcpId = TcpId, @StatusId = StatusId FROM dbo.TcpVersion WHERE Id = @VersionId;

    IF @StatusId NOT IN (1, 2)
        THROW 50020, 'Only Draft or In Review versions can be published.', 1;

    SELECT @WeightTotal = SUM(Weight) FROM dbo.TcpPillar WHERE TcpVersionId = @VersionId;
    IF ISNULL(@WeightTotal, 0) <> 100
        THROW 50021, 'Pillar weights must total 100.', 1;

    -- every Go/No-Go attribute needs a Bad rule
    IF EXISTS (
        SELECT 1
        FROM   dbo.TcpCriterionAttribute AS ta
        JOIN   dbo.TcpCriterion  AS tc ON tc.Id = ta.TcpCriterionId
        JOIN   dbo.CriterionType AS ct ON ct.Id = tc.CriterionTypeId AND ct.IsGoNoGo = 1
        JOIN   dbo.TcpPillar     AS tp ON tp.Id = tc.TcpPillarId AND tp.TcpVersionId = @VersionId
        WHERE  NOT EXISTS (SELECT 1 FROM dbo.TcpAttributeRule AS r
                           WHERE r.TcpCriterionAttributeId = ta.Id AND r.RatingLevelId = 3))
        THROW 50022, 'Every Go/No-Go attribute needs a Bad rule.', 1;

    -- operator must match the attribute data type
    IF EXISTS (
        SELECT 1
        FROM   dbo.TcpAttributeRule      AS r
        JOIN   dbo.ComparisonOperator    AS op ON op.Id = r.OperatorId
        JOIN   dbo.TcpCriterionAttribute AS ta ON ta.Id = r.TcpCriterionAttributeId
        JOIN   dbo.Attribute             AS a  ON a.Id  = ta.AttributeId
        JOIN   dbo.TcpCriterion          AS tc ON tc.Id = ta.TcpCriterionId
        JOIN   dbo.TcpPillar             AS tp ON tp.Id = tc.TcpPillarId AND tp.TcpVersionId = @VersionId
        WHERE  (a.DataTypeId = 1 AND op.ForNumeric = 0)
            OR (a.DataTypeId = 2 AND op.ForText    = 0)
            OR (a.DataTypeId = 3 AND op.ForBoolean = 0))
        THROW 50023, 'An operator does not match its attribute data type.', 1;

    BEGIN TRANSACTION;

    UPDATE dbo.TcpVersion SET StatusId = 4                       -- Superseded
    WHERE  TcpId = @TcpId AND StatusId = 3;

    UPDATE dbo.TcpVersion
    SET    StatusId = 3, PublishedBy = @UserId, PublishedOn = SYSUTCDATETIME()
    WHERE  Id = @VersionId;

    UPDATE dbo.Tcp
    SET    CurrentPublishedVersionId = @VersionId, UpdatedBy = @UserId, UpdatedOn = SYSUTCDATETIME()
    WHERE  Id = @TcpId;

    COMMIT TRANSACTION;
END;
GO

/* ---- 7.4 Score an experiment ------------------------------------------
   1) rate each measurement: first matching rule in Good -> Medium -> Bad order
   2) pillar score  = sum(criticality weight x rating factor) / sum(weight), rated only
   3) TCP score     = 100 x sum(pillar weight x pillar score) / sum(pillar weight), rated pillars only
   4) outcome       = No-Go if any Go/No-Go attribute is Bad,
                      Incomplete if any Go/No-Go attribute is unrated, else Go       */
CREATE OR ALTER PROCEDURE dbo.usp_ScoreExperiment
    @ExperimentId bigint
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;

    /* 1. rating per measurement */
    UPDATE m
    SET    m.RatingLevelId = x.RatingLevelId
    FROM   dbo.ExperimentMeasurement AS m
    JOIN   dbo.TcpCriterionAttribute AS ca ON ca.Id = m.TcpCriterionAttributeId
    JOIN   dbo.Attribute             AS a  ON a.Id  = ca.AttributeId
    OUTER APPLY (
        SELECT TOP (1) r.RatingLevelId
        FROM   dbo.TcpAttributeRule   AS r
        JOIN   dbo.ComparisonOperator AS op ON op.Id = r.OperatorId
        JOIN   dbo.RatingLevel        AS rl ON rl.Id = r.RatingLevelId
        WHERE  r.TcpCriterionAttributeId = ca.Id
          AND  1 = CASE op.Code
                    WHEN 'LT'  THEN CASE WHEN m.NumericValue <  r.NumericValue THEN 1 ELSE 0 END
                    WHEN 'LTE' THEN CASE WHEN m.NumericValue <= r.NumericValue THEN 1 ELSE 0 END
                    WHEN 'GT'  THEN CASE WHEN m.NumericValue >  r.NumericValue THEN 1 ELSE 0 END
                    WHEN 'GTE' THEN CASE WHEN m.NumericValue >= r.NumericValue THEN 1 ELSE 0 END
                    WHEN 'EQ'  THEN CASE WHEN a.DataTypeId = 2
                                         THEN CASE WHEN m.TextValue = r.TextValue THEN 1 ELSE 0 END
                                         WHEN m.NumericValue = r.NumericValue THEN 1 ELSE 0 END
                    WHEN 'NEQ' THEN CASE WHEN a.DataTypeId = 2
                                         THEN CASE WHEN m.TextValue <> r.TextValue THEN 1 ELSE 0 END
                                         WHEN m.NumericValue <> r.NumericValue THEN 1 ELSE 0 END
                    WHEN 'BETWEEN'    THEN CASE WHEN m.NumericValue BETWEEN r.NumericValue AND r.NumericValueTo THEN 1 ELSE 0 END
                    WHEN 'OUTSIDE'    THEN CASE WHEN m.NumericValue < r.NumericValue OR m.NumericValue > r.NumericValueTo THEN 1 ELSE 0 END
                    WHEN 'CONTAINS'   THEN CASE WHEN CHARINDEX(r.TextValue, m.TextValue) > 0 THEN 1 ELSE 0 END
                    WHEN 'EXISTS'     THEN CASE WHEN m.IsPresent = 1 THEN 1 ELSE 0 END
                    WHEN 'NOT_EXISTS' THEN CASE WHEN m.IsPresent = 0 THEN 1 ELSE 0 END
                    ELSE 0 END
        ORDER BY rl.EvaluationOrder
    ) AS x
    WHERE  m.ExperimentId = @ExperimentId;

    /* 2. pillar scores */
    DELETE FROM dbo.ExperimentPillarScore WHERE ExperimentId = @ExperimentId;

    INSERT INTO dbo.ExperimentPillarScore (ExperimentId, TcpPillarId, Score, RatedCount, TotalCount)
    SELECT  e.Id,
            tp.Id,
            SUM(CASE WHEN m.RatingLevelId IS NOT NULL THEN w.Weight * rl.ScoreFactor END)
              / NULLIF(SUM(CASE WHEN m.RatingLevelId IS NOT NULL THEN w.Weight END), 0),
            COUNT(m.RatingLevelId),
            COUNT(ca.Id)
    FROM    dbo.Experiment             AS e
    JOIN    dbo.TcpPillar              AS tp ON tp.TcpVersionId = e.TcpVersionId
    JOIN    dbo.TcpCriterion           AS tc ON tc.TcpPillarId = tp.Id
    JOIN    dbo.TcpCriterionAttribute  AS ca ON ca.TcpCriterionId = tc.Id
    JOIN    dbo.TcpVersionCriticalityWeight AS w
            ON w.TcpVersionId = e.TcpVersionId AND w.CriticalityLevelId = ca.CriticalityLevelId
    LEFT JOIN dbo.ExperimentMeasurement AS m
            ON m.ExperimentId = e.Id AND m.TcpCriterionAttributeId = ca.Id
    LEFT JOIN dbo.RatingLevel           AS rl ON rl.Id = m.RatingLevelId
    WHERE   e.Id = @ExperimentId
    GROUP BY e.Id, tp.Id;

    /* 3 + 4. experiment total, coverage and outcome */
    UPDATE  e
    SET     TotalScore = s.TotalScore,
            Coverage   = s.Coverage,
            OutcomeId  = CASE
                            WHEN EXISTS (SELECT 1 FROM dbo.TcpPillar AS tp
                                         JOIN dbo.TcpCriterion AS tc ON tc.TcpPillarId = tp.Id
                                         JOIN dbo.CriterionType AS ct ON ct.Id = tc.CriterionTypeId AND ct.IsGoNoGo = 1
                                         JOIN dbo.TcpCriterionAttribute AS ca ON ca.TcpCriterionId = tc.Id
                                         JOIN dbo.ExperimentMeasurement AS m ON m.TcpCriterionAttributeId = ca.Id AND m.ExperimentId = e.Id
                                         WHERE tp.TcpVersionId = e.TcpVersionId AND m.RatingLevelId = 3)
                                 THEN 2   -- No-Go
                            WHEN EXISTS (SELECT 1 FROM dbo.TcpPillar AS tp
                                         JOIN dbo.TcpCriterion AS tc ON tc.TcpPillarId = tp.Id
                                         JOIN dbo.CriterionType AS ct ON ct.Id = tc.CriterionTypeId AND ct.IsGoNoGo = 1
                                         JOIN dbo.TcpCriterionAttribute AS ca ON ca.TcpCriterionId = tc.Id
                                         LEFT JOIN dbo.ExperimentMeasurement AS m ON m.TcpCriterionAttributeId = ca.Id AND m.ExperimentId = e.Id
                                         WHERE tp.TcpVersionId = e.TcpVersionId AND m.RatingLevelId IS NULL)
                                 THEN 3   -- Incomplete
                            ELSE 1        -- Go
                         END,
            ScoredOn   = SYSUTCDATETIME()
    FROM    dbo.Experiment AS e
    CROSS APPLY (
        SELECT  100 * SUM(tp.Weight * ps.Score)
                    / NULLIF(SUM(CASE WHEN ps.Score IS NOT NULL THEN tp.Weight END), 0) AS TotalScore,
                CAST(SUM(ps.RatedCount) AS decimal(19,4)) / NULLIF(SUM(ps.TotalCount), 0) AS Coverage
        FROM    dbo.ExperimentPillarScore AS ps
        JOIN    dbo.TcpPillar             AS tp ON tp.Id = ps.TcpPillarId
        WHERE   ps.ExperimentId = e.Id
    ) AS s
    WHERE   e.Id = @ExperimentId;

    COMMIT TRANSACTION;
END;
GO
