/*!
 * tcp-thresholds.js 1.0
 * Validation and the threshold bar for Good / Medium / Bad parameter rules.
 * No dependencies. Works in any browser and in OutSystems JavaScript nodes
 * (exposed as window.TcpThresholds). Also loads in Node for tests.
 *
 * Rule shape (what JSONSerialize of the ThresholdRule structure produces):
 *   { "Rating": "GOOD" | "MEDIUM" | "BAD",
 *     "Operator": "LT" | "LTE" | "GT" | "GTE" | "EQ" | "NEQ" | "BETWEEN" | "OUTSIDE"
 *                 | "CONTAINS" | "EXISTS" | "NOT_EXISTS" | "",
 *     "Value": "10", "ValueTo": "", "Text": "" }
 * Values are text so an empty box can be told apart from 0. Both "10.5" and
 * "10,5" are accepted. camelCase keys (rating, operator, value...) work too.
 *
 * Main calls
 *   TcpThresholds.validate(rules, dataType, options)            -> rich result object
 *   TcpThresholds.validateForOutSystems(rulesJson, dataType, optionsJson) -> JSON text
 *   TcpThresholds.renderBar(elementOrId, rules, dataType, options)       -> { issues, markerRating }
 *   TcpThresholds.operatorsForOutSystems(dataType)                        -> JSON text
 *   TcpThresholds.valueCount(operatorCode)                               -> 0, 1 or 2
 *
 * dataType: "NUMERIC" (default), "TEXT" or "PRESENCE".
 * Rules are applied Good -> Medium -> Bad: the first one that matches a result wins,
 * exactly as the scoring function in the database does.
 */
(function (root, factory) {
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.TcpThresholds = api;
})(typeof window !== 'undefined' ? window : this, function () {
  'use strict';

  /* ------------------------------------------------------------------ reference data */
  var OPERATORS = {
    LT:         { short: '<',        label: 'Lower than',          values: 1, types: ['NUMERIC'] },
    LTE:        { short: '≤',   label: 'Lower or equal',      values: 1, types: ['NUMERIC'] },
    GT:         { short: '>',        label: 'Greater than',        values: 1, types: ['NUMERIC'] },
    GTE:        { short: '≥',   label: 'Greater or equal',    values: 1, types: ['NUMERIC'] },
    EQ:         { short: '=',        label: 'Equal to',            values: 1, types: ['NUMERIC', 'TEXT'] },
    NEQ:        { short: '≠',   label: 'Not equal to',        values: 1, types: ['NUMERIC', 'TEXT'] },
    BETWEEN:    { short: 'between',  label: 'Between (inclusive)', values: 2, types: ['NUMERIC'] },
    OUTSIDE:    { short: 'outside',  label: 'Outside range',       values: 2, types: ['NUMERIC'] },
    CONTAINS:   { short: 'contains', label: 'Contains text',       values: 1, types: ['TEXT'] },
    EXISTS:     { short: 'present',  label: 'Exists',              values: 0, types: ['PRESENCE'] },
    NOT_EXISTS: { short: 'absent',   label: 'Does not exist',      values: 0, types: ['PRESENCE'] }
  };
  var RATINGS = ['GOOD', 'MEDIUM', 'BAD'];
  var FIELDS = ['Operator', 'Value', 'ValueTo', 'Text'];

  // Every text the user can see. Override any of them per call (options.messages)
  // or once for the app with TcpThresholds.setMessages({...}), e.g. for translations.
  var MESSAGES = {
    ratingGOOD: 'Good', ratingMEDIUM: 'Medium', ratingBAD: 'Bad',
    required: 'Set a {rating} condition.',
    unknownOperator: 'Choose a condition from the list.',
    operatorType: 'This condition can’t be used for {type} attributes.',
    valueRequired: 'Enter a value.',
    valueNumber: 'Enter a number, for example 10 or 0.5.',
    valueMin: 'Enter {min} or more.',
    valueMax: 'Enter {max} or less.',
    valueToRequired: 'Enter the upper value.',
    valueToOrder: 'Enter a value of at least {from}.',
    textRequired: 'Enter the text to match.',
    gapBelow: 'Results below {b} are not rated.',
    gapAbove: 'Results above {a} are not rated.',
    gapBetween: 'Results between {a} and {b} are not rated.',
    gapPoint: 'A result of exactly {a} is not rated.',
    gapPresent: 'A present result is not rated.',
    gapAbsent: 'An absent result is not rated.',
    unreachable: '{rating} never applies: {earlier} already cover{s} all of its values.',
    overlap: '{first} and {second} overlap {where}. {first} takes priority there.',
    whereBelow: 'below {b}', whereAbove: 'above {a}', whereBetween: 'from {a} to {b}',
    duplicateText: '{first} and {second} both match “{text}”. {first} takes priority.',
    barEmpty: 'Enter thresholds to see the scale.',
    typeNUMERIC: 'numeric', typeTEXT: 'text', typePRESENCE: 'present / absent',
    notRated: 'not rated'
  };

  function setMessages(overrides) {
    for (var k in overrides) if (Object.prototype.hasOwnProperty.call(overrides, k)) MESSAGES[k] = overrides[k];
  }
  function msgSet(options) {
    var m = {}, k;
    for (k in MESSAGES) m[k] = MESSAGES[k];
    if (options && options.messages) for (k in options.messages) m[k] = options.messages[k];
    return m;
  }
  function fill(template, values) {
    return String(template).replace(/\{(\w+)\}/g, function (_, key) {
      return values[key] === undefined || values[key] === null ? '' : String(values[key]);
    });
  }

  /* ------------------------------------------------------------------ input helpers */
  function parseJson(v, fallback) {
    if (v === undefined || v === null || v === '') return fallback;
    if (typeof v !== 'string') return v;
    try { return JSON.parse(v); } catch (e) { return fallback; }
  }

  function parseNumber(v) {
    if (v === undefined || v === null) return { empty: true };
    if (typeof v === 'number') return isFinite(v) ? { value: v } : { invalid: true };
    var s = String(v).replace(/\s/g, '');
    if (!s) return { empty: true };
    if (s.indexOf(',') >= 0 && s.indexOf('.') < 0) s = s.replace(',', '.');
    if (!/^[-+]?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?$/.test(s)) return { invalid: true };
    return { value: Number(s) };
  }

  function pick(o, names) {
    for (var i = 0; i < names.length; i++) if (o[names[i]] !== undefined) return o[names[i]];
    return undefined;
  }

  // Accepts an array of rules, a JSON string of it, or an object keyed by rating.
  function normalise(rules) {
    rules = parseJson(rules, []);
    var list = [];
    if (Array.isArray(rules)) list = rules;
    else if (rules && typeof rules === 'object') {
      for (var key in rules) {
        if (!Object.prototype.hasOwnProperty.call(rules, key)) continue;
        var r = rules[key] || {};
        if (pick(r, ['Rating', 'rating']) === undefined) { r = shallowCopy(r); r.Rating = key; }
        list.push(r);
      }
    }
    var out = {};
    list.forEach(function (r) {
      if (!r) return;
      var rating = String(pick(r, ['Rating', 'rating', 'RatingCode', 'ratingCode']) || '').toUpperCase();
      if (RATINGS.indexOf(rating) < 0) return;
      out[rating] = {
        rating: rating,
        operator: String(pick(r, ['Operator', 'operator', 'OperatorCode', 'operatorCode']) || '').toUpperCase(),
        valueRaw: pick(r, ['Value', 'value', 'NumericValue', 'numericValue']),
        valueToRaw: pick(r, ['ValueTo', 'valueTo', 'value_to', 'NumericValueTo', 'numericValueTo']),
        text: pick(r, ['Text', 'text', 'TextValue', 'textValue'])
      };
    });
    return out;
  }
  function shallowCopy(o) { var c = {}; for (var k in o) c[k] = o[k]; return c; }

  function normType(t) {
    t = String(t || 'NUMERIC').toUpperCase();
    return t === 'TEXT' || t === 'PRESENCE' ? t : 'NUMERIC';
  }
  function fmt(n) {
    if (n === -Infinity || n === Infinity) return '';
    var s = String(Number(n.toPrecision(12)));
    return s;
  }
  function valueCount(op) { var o = OPERATORS[String(op || '').toUpperCase()]; return o ? o.values : 0; }

  function describe(rule) {
    if (!rule || !OPERATORS[rule.operator]) return '';
    var o = OPERATORS[rule.operator];
    if (o.values === 0) return o.short;
    if (rule.operator === 'BETWEEN') return fmt(rule.value) + ' – ' + fmt(rule.valueTo);
    if (rule.operator === 'OUTSIDE') return 'outside ' + fmt(rule.value) + ' – ' + fmt(rule.valueTo);
    if (rule.text !== undefined && rule.text !== null && rule.value === undefined) {
      return (rule.operator === 'CONTAINS' ? 'contains ' : o.short + ' ') + '“' + rule.text + '”';
    }
    return o.short + ' ' + fmt(rule.value);
  }

  /* ------------------------------------------------------------------ rule matching */
  function matches(r, v) {
    var a = r.value, b = r.valueTo;
    switch (r.operator) {
      case 'LT': return v < a;
      case 'LTE': return v <= a;
      case 'GT': return v > a;
      case 'GTE': return v >= a;
      case 'EQ': return v === a;
      case 'NEQ': return v !== a;
      case 'BETWEEN': return v >= a && v <= b;
      case 'OUTSIDE': return v < a || v > b;
      default: return false;
    }
  }
  function rateAt(complete, v) {
    for (var i = 0; i < RATINGS.length; i++) {
      var r = complete[RATINGS[i]];
      if (r && matches(r, v)) return RATINGS[i];
    }
    return null;
  }

  // Splits the number line at every threshold. Ratings can only change at a
  // threshold, so one probe per interval and per threshold gives the exact picture.
  function pieces(complete, extraPoints) {
    var pts = [];
    RATINGS.forEach(function (c) {
      var r = complete[c];
      if (!r) return;
      [r.value, r.valueTo].forEach(function (v) { if (typeof v === 'number' && isFinite(v) && pts.indexOf(v) < 0) pts.push(v); });
    });
    (extraPoints || []).forEach(function (v) { if (typeof v === 'number' && isFinite(v) && pts.indexOf(v) < 0) pts.push(v); });
    pts.sort(function (x, y) { return x - y; });
    if (!pts.length) return { pts: [], list: [] };
    var lo = pts[0], hi = pts[pts.length - 1];
    var step = Math.max(Math.abs(hi - lo), Math.abs(hi), 1);
    var list = [{ a: -Infinity, b: lo, probe: lo - step }];
    pts.forEach(function (p, i) {
      list.push({ a: p, b: p, point: true, probe: p });
      if (i < pts.length - 1) list.push({ a: p, b: pts[i + 1], probe: (p + pts[i + 1]) / 2 });
    });
    list.push({ a: hi, b: Infinity, probe: hi + step });
    list.forEach(function (s) { s.r = rateAt(complete, s.probe); });
    return { pts: pts, list: list };
  }

  /* ------------------------------------------------------------------ validation */
  function validate(rulesInput, dataType, options) {
    options = parseJson(options, {}) || {};
    var M = msgSet(options);
    var type = normType(dataType);
    var rules = normalise(rulesInput);
    var required = (options.requireRatings || []).map(function (x) { return String(x).toUpperCase(); });
    if (options.isGoNoGo && required.indexOf('BAD') < 0) required.push('BAD');
    var min = parseNumber(options.min), max = parseNumber(options.max);

    var fields = {}, complete = {}, warnings = [], isValid = true;
    RATINGS.forEach(function (rating) {
      var f = fields[rating] = { Operator: '', Value: '', ValueTo: '', Text: '' };
      var r = rules[rating];
      var ratingName = M['rating' + rating];
      var op = r ? r.operator : '';
      if (!op) {
        if (required.indexOf(rating) >= 0) f.Operator = fill(M.required, { rating: ratingName });
        return;
      }
      var meta = OPERATORS[op];
      if (!meta) { f.Operator = M.unknownOperator; return; }
      if (meta.types.indexOf(type) < 0) { f.Operator = fill(M.operatorType, { type: M['type' + type] }); return; }

      var c = { rating: rating, operator: op };
      if (meta.values >= 1 && type === 'TEXT') {
        var t = r.text === undefined || r.text === null ? '' : String(r.text);
        if (!t.trim()) f.Text = M.textRequired; else c.text = t.trim();
      } else if (meta.values >= 1) {
        var v = parseNumber(r.valueRaw);
        if (v.empty) f.Value = M.valueRequired;
        else if (v.invalid) f.Value = M.valueNumber;
        else if (min.value !== undefined && v.value < min.value) f.Value = fill(M.valueMin, { min: fmt(min.value) });
        else if (max.value !== undefined && v.value > max.value) f.Value = fill(M.valueMax, { max: fmt(max.value) });
        else c.value = v.value;
        if (meta.values === 2) {
          var w = parseNumber(r.valueToRaw);
          if (w.empty) f.ValueTo = M.valueToRequired;
          else if (w.invalid) f.ValueTo = M.valueNumber;
          else if (min.value !== undefined && w.value < min.value) f.ValueTo = fill(M.valueMin, { min: fmt(min.value) });
          else if (max.value !== undefined && w.value > max.value) f.ValueTo = fill(M.valueMax, { max: fmt(max.value) });
          else if (c.value !== undefined && w.value < c.value) f.ValueTo = fill(M.valueToOrder, { from: fmt(c.value) });
          else c.valueTo = w.value;
        }
      }
      if (!f.Operator && !f.Value && !f.ValueTo && !f.Text) complete[rating] = c;
    });
    RATINGS.forEach(function (rating) {
      FIELDS.forEach(function (k) { if (fields[rating][k]) isValid = false; });
    });

    // Range warnings (gaps, overlaps, ratings that never apply) only once every
    // started rule is complete, so half-typed values don't produce false alarms.
    // options.warnWhileIncomplete = true shows them for the complete rules anyway.
    var analysis = null;
    if (!isValid && !options.warnWhileIncomplete) {
      // no range warnings yet
    } else if (type === 'NUMERIC') {
      analysis = pieces(complete);
      if (analysis.list.length) numericWarnings(analysis.list, complete, warnings, M);
    } else if (type === 'PRESENCE') {
      presenceWarnings(complete, warnings, M);
    } else {
      textWarnings(complete, warnings, M);
    }

    return {
      isValid: isValid,
      hasWarnings: warnings.length > 0,
      fields: fields,
      warnings: warnings,
      complete: complete,
      dataType: type,
      summary: RATINGS.filter(function (c) { return complete[c]; })
        .map(function (c) { return M['rating' + c] + ' ' + describe(complete[c]); }).join(', ')
    };
  }

  function numericWarnings(list, complete, warnings, M) {
    // gaps
    list.forEach(function (s, i) {
      if (s.r) return;
      var m;
      if (s.point) {
        if (list[i - 1] && list[i - 1].r && list[i + 1] && list[i + 1].r) m = fill(M.gapPoint, { a: fmt(s.a) });
      } else if (s.a === -Infinity) m = fill(M.gapBelow, { b: fmt(s.b) });
      else if (s.b === Infinity) m = fill(M.gapAbove, { a: fmt(s.a) });
      else m = fill(M.gapBetween, { a: fmt(s.a), b: fmt(s.b) });
      if (m) warnings.push({ rating: '', kind: 'gap', message: m });
    });
    // ratings that never win
    var unreachable = {};
    RATINGS.forEach(function (rating, idx) {
      if (!complete[rating]) return;
      var wins = list.some(function (s) { return s.r === rating; });
      if (wins) return;
      unreachable[rating] = true;
      var earlier = RATINGS.slice(0, idx).filter(function (c) { return complete[c]; }).map(function (c) { return M['rating' + c]; });
      warnings.push({ rating: rating, kind: 'unreachable', message: fill(M.unreachable, {
        rating: M['rating' + rating], earlier: earlier.join(' and '), s: earlier.length === 1 ? 's' : '' }) });
    });
    // overlapping ranges (intervals only; a shared boundary value is normal)
    for (var i = 0; i < RATINGS.length; i++) {
      for (var j = i + 1; j < RATINGS.length; j++) {
        var A = complete[RATINGS[i]], B = complete[RATINGS[j]];
        if (!A || !B || unreachable[RATINGS[j]]) continue;
        var spans = [], cur = null;
        list.forEach(function (s) {
          if (s.point) return;
          if (matches(A, s.probe) && matches(B, s.probe)) {
            if (cur && cur.b === s.a) cur.b = s.b; else { cur = { a: s.a, b: s.b }; spans.push(cur); }
          } else cur = null;
        });
        spans.forEach(function (sp) {
          var where = sp.a === -Infinity ? fill(M.whereBelow, { b: fmt(sp.b) })
            : sp.b === Infinity ? fill(M.whereAbove, { a: fmt(sp.a) })
            : fill(M.whereBetween, { a: fmt(sp.a), b: fmt(sp.b) });
          warnings.push({ rating: RATINGS[j], kind: 'overlap', message: fill(M.overlap, {
            first: M['rating' + RATINGS[i]], second: M['rating' + RATINGS[j]], where: where }) });
        });
      }
    }
  }

  function presenceRating(complete, present) {
    for (var i = 0; i < RATINGS.length; i++) {
      var r = complete[RATINGS[i]];
      if (r && ((r.operator === 'EXISTS' && present) || (r.operator === 'NOT_EXISTS' && !present))) return RATINGS[i];
    }
    return null;
  }
  function presenceWarnings(complete, warnings, M) {
    var any = RATINGS.some(function (c) { return complete[c]; });
    if (!any) return;
    var p = presenceRating(complete, true), a = presenceRating(complete, false);
    if (!p) warnings.push({ rating: '', kind: 'gap', message: M.gapPresent });
    if (!a) warnings.push({ rating: '', kind: 'gap', message: M.gapAbsent });
    RATINGS.forEach(function (rating, idx) {
      if (!complete[rating] || rating === p || rating === a) return;
      var earlier = RATINGS.slice(0, idx).filter(function (c) { return complete[c]; }).map(function (c) { return M['rating' + c]; });
      warnings.push({ rating: rating, kind: 'unreachable', message: fill(M.unreachable, {
        rating: M['rating' + rating], earlier: earlier.join(' and '), s: earlier.length === 1 ? 's' : '' }) });
    });
  }
  function textWarnings(complete, warnings, M) {
    for (var i = 0; i < RATINGS.length; i++) {
      for (var j = i + 1; j < RATINGS.length; j++) {
        var A = complete[RATINGS[i]], B = complete[RATINGS[j]];
        if (A && B && A.operator === 'EQ' && B.operator === 'EQ' && A.text.toLowerCase() === B.text.toLowerCase()) {
          warnings.push({ rating: RATINGS[j], kind: 'duplicate', message: fill(M.duplicateText, {
            first: M['rating' + RATINGS[i]], second: M['rating' + RATINGS[j]], text: B.text }) });
        }
      }
    }
  }

  // Flat result for OutSystems: one message attribute per input, so each widget's
  // Valid / ValidationMessage can be assigned without filtering lists.
  function toOutSystems(result) {
    var out = {
      IsValid: result.isValid,
      HasWarnings: result.hasWarnings,
      WarningsText: result.warnings.map(function (w) { return w.message; }).join('\n'),
      Warnings: result.warnings.map(function (w) { return { Rating: w.rating, Kind: w.kind, Message: w.message }; }),
      Summary: result.summary
    };
    var names = { GOOD: 'Good', MEDIUM: 'Medium', BAD: 'Bad' };
    RATINGS.forEach(function (rating) {
      FIELDS.forEach(function (k) { out[names[rating] + k + 'Message'] = result.fields[rating][k]; });
    });
    return out;
  }
  function validateForOutSystems(rulesJson, dataType, optionsJson) {
    return JSON.stringify(toOutSystems(validate(rulesJson, dataType, parseJson(optionsJson, {}))));
  }

  function operatorsFor(dataType) {
    var type = normType(dataType);
    return Object.keys(OPERATORS).filter(function (k) { return OPERATORS[k].types.indexOf(type) >= 0; })
      .map(function (k) { return { Value: k, Label: OPERATORS[k].short, Description: OPERATORS[k].label, ValueCount: OPERATORS[k].values }; });
  }
  function operatorsForOutSystems(dataType) { return JSON.stringify(operatorsFor(dataType)); }

  /* ------------------------------------------------------------------ the bar */
  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text !== undefined) e.textContent = text;
    return e;
  }

  function renderBar(target, rulesInput, dataType, options) {
    options = parseJson(options, {}) || {};
    var node = typeof target === 'string' ? document.getElementById(target) : target;
    if (!node) return { issues: [], markerRating: null };
    var M = msgSet(options);
    var result = validate(rulesInput, dataType, options);
    var type = result.dataType, complete = result.complete;
    var issues = result.warnings.filter(function (w) { return w.kind === 'gap'; }).map(function (w) { return w.message; });
    var root = el('div', 'tcp-tb');
    node.innerHTML = '';
    node.appendChild(root);
    var any = RATINGS.some(function (c) { return complete[c]; });
    if (!any) {
      root.className = 'tcp-tb tcp-tb-empty';
      root.textContent = M.barEmpty;
      return { issues: issues, markerRating: null };
    }

    if (type !== 'NUMERIC') {
      root.className = 'tcp-tb tcp-tb-cats';
      var cats = [];
      if (type === 'PRESENCE') {
        [true, false].forEach(function (present) {
          var r = presenceRating(complete, present);
          cats.push({ label: (present ? 'Present' : 'Absent') + ': ' + (r ? M['rating' + r] : M.notRated), r: r });
        });
      } else {
        RATINGS.forEach(function (c) { if (complete[c]) cats.push({ label: M['rating' + c] + ': ' + describe(complete[c]), r: c }); });
      }
      cats.forEach(function (c) { root.appendChild(el('span', 'tcp-tb-cat ' + (c.r ? 'tcp-tb-' + c.r.toLowerCase() : 'tcp-tb-gap'), c.label)); });
      return { issues: issues, markerRating: null };
    }

    var marker = parseNumber(options.marker);
    var a = pieces(complete, marker.value !== undefined ? [marker.value] : []);
    var lo = a.pts[0], hi = a.pts[a.pts.length - 1];
    var log = options.scale === 'log' || (options.scale !== 'linear' && lo > 0 && hi / lo >= 50);
    var dlo, dhi;
    if (log) { dlo = lo / 2.5; dhi = hi * 2.5; }
    else if (lo === hi) { var d = Math.max(Math.abs(lo) * 0.5, 1); dlo = lo - d; dhi = hi + d; }
    else { var pad = (hi - lo) * 0.25; dlo = lo - pad; dhi = hi + pad; if (lo >= 0 && dlo < 0) dlo = 0; }
    var f = function (v) { return log ? Math.log(v) / Math.LN10 : v; };
    var pos = function (v) { return Math.max(0, Math.min(100, ((f(v) - f(dlo)) / (f(dhi) - f(dlo))) * 100)); };

    var bar = el('div', 'tcp-tb-bar');
    var track = el('div', 'tcp-tb-track');
    bar.appendChild(track);
    if (options.height) bar.style.height = options.height + 'px';
    var labels = [];
    a.list.forEach(function (s, i) {
      if (s.point) {
        var prev = a.list[i - 1], next = a.list[i + 1];
        if (s.r !== (prev && prev.r) && s.r !== (next && next.r)) {
          var pt = el('span', 'tcp-tb-pt ' + (s.r ? 'tcp-tb-' + s.r.toLowerCase() : 'tcp-tb-gap'));
          pt.style.left = pos(s.a) + '%';
          track.appendChild(pt);
        }
        return;
      }
      var l = s.a === -Infinity ? 0 : pos(s.a), r = s.b === Infinity ? 100 : pos(s.b);
      if (r - l <= 0) return;
      var seg = el('span', 'tcp-tb-seg ' + (s.r ? 'tcp-tb-' + s.r.toLowerCase() : 'tcp-tb-gap'));
      seg.style.left = l + '%';
      seg.style.width = (r - l) + '%';
      track.appendChild(seg);
      var range = s.a === -Infinity ? 'below ' + fmt(s.b) : s.b === Infinity ? 'above ' + fmt(s.a) : fmt(s.a) + ' to ' + fmt(s.b);
      labels.push((s.r ? M['rating' + s.r] : M.notRated) + ' ' + range);
    });

    var markerRating = null;
    if (marker.value !== undefined) {
      markerRating = rateAt(complete, marker.value);
      var mk = el('span', 'tcp-tb-marker ' + (markerRating ? 'tcp-tb-' + markerRating.toLowerCase() : 'tcp-tb-gap'));
      mk.style.left = pos(marker.value) + '%';
      mk.title = fmt(marker.value) + (options.unit ? ' ' + options.unit : '') + ': ' + (markerRating ? M['rating' + markerRating] : M.notRated);
      bar.appendChild(mk);
    }
    root.appendChild(bar);

    if (options.showTicks !== false) {
      var ticks = el('div', 'tcp-tb-ticks');
      ticks.setAttribute('aria-hidden', 'true');
      var thresholdPts = pieces(complete).pts;
      var last = -100;
      thresholdPts.forEach(function (p, i) {
        var x = pos(p);
        var isLast = i === thresholdPts.length - 1;
        if (x - last < 9 && !isLast) return;
        if (x - last < 9 && ticks.lastChild) ticks.removeChild(ticks.lastChild);
        last = x;
        var t = el('span', x < 4 ? 'tcp-tb-first' : x > 96 ? 'tcp-tb-last' : '', fmt(p) + (isLast && options.unit ? ' ' + options.unit : ''));
        t.style.left = x + '%';
        ticks.appendChild(t);
      });
      root.appendChild(ticks);
    }

    root.setAttribute('role', 'img');
    root.setAttribute('aria-label', labels.join(', ') + (options.unit ? ' (' + options.unit + ')' : '') + (log ? ', log scale' : ''));
    if (log) root.title = 'Log scale';
    return { issues: issues, markerRating: markerRating };
  }

  return {
    version: '1.0',
    OPERATORS: OPERATORS,
    RATINGS: RATINGS,
    setMessages: setMessages,
    validate: validate,
    toOutSystems: toOutSystems,
    validateForOutSystems: validateForOutSystems,
    operatorsFor: operatorsFor,
    operatorsForOutSystems: operatorsForOutSystems,
    valueCount: valueCount,
    describe: describe,
    parseNumber: parseNumber,
    renderBar: renderBar
  };
});
