# Threshold validation and bar for OutSystems

Reusable pieces for the Good / Medium / Bad threshold form:

- **Validation as the user types.** A message under the input that needs fixing, plus warnings about the whole set: gaps no rule covers, ranges that overlap, and a rating that can never apply.
- **The threshold bar.** It shows the Good / Medium / Bad ranges on a scale, marks gaps, and redraws on every change.

It is the same logic as the TCP Matrix web app, packaged as one JavaScript library with no dependencies. The rules are applied in the order Good, Medium, Bad, exactly like the scoring function in the database.

| File | What it is |
| --- | --- |
| `tcp-thresholds.js` | The library. Exposes `window.TcpThresholds`. |
| `tcp-thresholds.css` | Bar and warning styles. Uses OutSystems UI colour tokens when present. |
| `demo.html` | A plain HTML form wired the same way as the OutSystems blocks. Open it in a browser to try it. |
| `tests/tcp-thresholds.test.js` | Unit tests for every rule: `node tests/tcp-thresholds.test.js` |

---

## 1. What the library does

| Call | Use it for | Returns |
| --- | --- | --- |
| `TcpThresholds.validateForOutSystems(rulesJson, dataType, options)` | Validate the three rules | JSON text that deserialises into the `ThresholdValidation` structure |
| `TcpThresholds.renderBar(elementId, rulesJson, dataType, options)` | Draw or redraw the bar inside a container | `{ issues, markerRating }` |
| `TcpThresholds.operatorsForOutSystems(dataType)` | The conditions that fit an attribute type | JSON list of `{ Value, Label, Description, ValueCount }` |
| `TcpThresholds.valueCount(operator)` | How many value boxes a condition needs | 0, 1 or 2 |
| `TcpThresholds.setMessages({...})` | Replace any text, for example for translation | — |

**Rules** are passed as the JSON of a list of `ThresholdRule` records:

```json
[{"Rating":"GOOD","Operator":"GT","Value":"40","ValueTo":"","Text":""},
 {"Rating":"MEDIUM","Operator":"BETWEEN","Value":"10","ValueTo":"40","Text":""},
 {"Rating":"BAD","Operator":"LT","Value":"10","ValueTo":"","Text":""}]
```

`Value` and `ValueTo` are **Text** on purpose. An OutSystems Decimal can't be empty: an empty box becomes 0, and the user would never see "Enter a value". Text keeps the difference, and the library parses it. Both `10.5` and `10,5` are accepted.

**Data types:** `NUMERIC` (default), `TEXT` and `PRESENCE` (exists / absent).

**Operator codes:** `LT LTE GT GTE EQ NEQ BETWEEN OUTSIDE CONTAINS EXISTS NOT_EXISTS`. These are the same codes as the `ComparisonOperator` static entity in the data model.

**Options** (all optional):

| Option | Meaning |
| --- | --- |
| `isGoNoGo: true` | A Bad condition is required (Go/No-Go sections). |
| `requireRatings: ["GOOD","BAD"]` | Any ratings that must be set. |
| `min`, `max` | Allowed value range, e.g. 0 and 100 for %. |
| `unit` | Bar only: shown after the last tick. |
| `marker` | Bar only: a result value to pin on the scale, coloured by the rating it gets. |
| `height`, `showTicks`, `scale: "log" \| "linear"` | Bar only. A log scale is used automatically when the values span 50× or more. |
| `messages: {...}` | Replace texts for this call. |
| `warnWhileIncomplete: true` | Show range warnings before every started rule is complete. Off by default, so half-typed values don't raise false alarms. |

---

## 2. Set up the module

These steps work for O11 Reactive Web and for ODC. Put the pieces in a library module, e.g. `TCP_Thresholds_UI`, so every app can reuse them.

1. **Import the script.** Interface tab > Scripts > right-click > **Import Script** > `tcp-thresholds.js`.
2. **Add the styles.** Paste `tcp-thresholds.css` into the module's theme. Alternatively, paste it into the style sheet of the `ThresholdBar` block.
3. **Load the script where it's used.** Add the imported `tcp-thresholds` script to **Required Scripts** on both blocks below. Do the same on any screen that calls the client actions without one of those blocks on it.
4. **Create the structures** (Data tab > Structures):

**`ThresholdRule`**

| Attribute | Type |
| --- | --- |
| Rating | Text (GOOD, MEDIUM, BAD) |
| Operator | Text (operator code, empty = not set) |
| Value | Text |
| ValueTo | Text |
| Text | Text |

**`ThresholdWarning`**: Rating (Text), Kind (Text: gap, overlap, unreachable, duplicate), Message (Text)

**`ThresholdValidation`**

| Attribute | Type |
| --- | --- |
| IsValid | Boolean |
| HasWarnings | Boolean |
| WarningsText | Text |
| Warnings | ThresholdWarning List |
| Summary | Text |
| GoodOperatorMessage, GoodValueMessage, GoodValueToMessage, GoodTextMessage | Text |
| MediumOperatorMessage, MediumValueMessage, MediumValueToMessage, MediumTextMessage | Text |
| BadOperatorMessage, BadValueMessage, BadValueToMessage, BadTextMessage | Text |

The attribute names must match exactly, because they are the JSON keys. There is one message per input, so each widget's `Valid` and `ValidationMessage` can be assigned directly, without filtering a list.

**`OperatorOption`**: Value (Text), Label (Text), Description (Text), ValueCount (Integer)

---

## 3. Client actions (public)

### `ThresholdValidate`

- **Inputs:** RulesJSON (Text, mandatory), DataType (Text, default `"NUMERIC"`), IsGoNoGo (Boolean), MinValue (Text), MaxValue (Text)
- **Output:** Validation (ThresholdValidation)

Flow:

1. **JavaScript node `Run`**
   - Inputs: RulesJSON, DataType, IsGoNoGo, MinValue, MaxValue
   - Output: ResultJSON (Text)
   ```js
   $parameters.ResultJSON = TcpThresholds.validateForOutSystems(
       $parameters.RulesJSON,
       $parameters.DataType,
       { isGoNoGo: $parameters.IsGoNoGo, min: $parameters.MinValue, max: $parameters.MaxValue });
   ```
2. **JSON Deserialize**: JSON String = `Run.ResultJSON`, Data type = `ThresholdValidation`
3. **Assign**: `Validation = JSONDeserializeValidation.Data`

### `ThresholdOperators`

- **Input:** DataType (Text)
- **Output:** Options (OperatorOption List)

Flow: a JavaScript node (`$parameters.OptionsJSON = TcpThresholds.operatorsForOutSystems($parameters.DataType);`), then JSON Deserialize into `OperatorOption List`, then Assign.

If you'd rather drive the dropdown from your `ComparisonOperator` static entity, use an aggregate filtered on `ForNumeric`, `ForText` or `ForPresence` instead. The codes are the same.

### `ThresholdValueCount` (Function = Yes)

- **Input:** Operator (Text)
- **Output:** Count (Integer)

A single Assign, so it works in `Visible` expressions with no script dependency:

```
Count = If(Operator = "BETWEEN" or Operator = "OUTSIDE", 2,
        If(Operator = "" or Operator = "EXISTS" or Operator = "NOT_EXISTS", 0, 1))
```

---

## 4. Block `ThresholdBar`

Use this block on its own in read-only lists, and inside the editor below.

- **Input parameters:**
  - RulesJSON (Text)
  - DataType (Text, default `"NUMERIC"`)
  - Unit (Text)
  - Marker (Text, optional result value)
  - ShowTicks (Boolean, default True)
  - Height (Integer, default 12)
- **Widgets:** one Container with **Name = `Bar`**, nothing inside it.
- **Required Scripts:** the imported `tcp-thresholds` script
- **Events:** On Ready → `Render`, On Parameters Changed → `Render`
- **Client action `Render`:** one JavaScript node with these inputs:
  - ElementId = `Bar.Id`
  - RulesJSON, DataType, Unit, Marker, ShowTicks, Height

  ```js
  TcpThresholds.renderBar($parameters.ElementId, $parameters.RulesJSON, $parameters.DataType, {
      unit: $parameters.Unit,
      marker: $parameters.Marker,
      showTicks: $parameters.ShowTicks,
      height: $parameters.Height || undefined
  });
  ```

The parent only binds RulesJSON. Whenever that value changes, On Parameters Changed redraws the bar, so the bar follows the inputs as the user types.

**In a read-only list,** bind RulesJSON per row. With SQL Server you can build it in an Advanced SQL query:

```sql
SELECT p.Id,
       (SELECT rl.Code AS Rating, op.Code AS Operator,
               CONVERT(varchar(40), r.NumericValue) AS Value,
               CONVERT(varchar(40), r.NumericValueTo) AS ValueTo,
               r.TextValue AS [Text]
        FROM {TcpAttributeRule} r
        JOIN {RatingLevel} rl ON rl.Id = r.RatingLevelId
        JOIN {ComparisonOperator} op ON op.Id = r.OperatorId
        WHERE r.TcpCriterionAttributeId = p.Id
        FOR JSON PATH) AS RulesJSON
FROM {TcpCriterionAttribute} p
WHERE ...
```

Alternatively, build a `ThresholdRule List` from an aggregate and use `JSONSerialize`.

---

## 5. Block `ThresholdEditor` (the Good / Medium / Bad form)

- **Input parameters:**
  - InitialRulesJSON (Text)
  - DataType (Text)
  - Unit (Text)
  - IsGoNoGo (Boolean)
  - MinValue, MaxValue (Text)
  - ShowAllErrors (Boolean: the parent sets it to True when the user clicks Save)
- **Event:** `Changed`, with RulesJSON (Text) and IsValid (Boolean)
- **Local variables:**
  - GoodRule, MediumRule, BadRule (ThresholdRule)
  - Options (OperatorOption List)
  - Validation (ThresholdValidation)
  - RulesJSON (Text)
  - Touched (Boolean)
- **Required Scripts:** the imported `tcp-thresholds` script

### Layout

Three columns or cards, one per rating, each inside the block's Form. Give the widgets these names, because the assignments below use them:

| Rating | Dropdown (Variable) | Input (Variable) | Input (Variable) | Input (Variable) |
| --- | --- | --- | --- | --- |
| Good | `GoodOperator` (GoodRule.Operator) | `GoodValue` (GoodRule.Value) | `GoodValueTo` (GoodRule.ValueTo) | `GoodText` (GoodRule.Text) |
| Medium | `MediumOperator` | `MediumValue` | `MediumValueTo` | `MediumText` |
| Bad | `BadOperator` | `BadValue` | `BadValueTo` | `BadText` |

- **Dropdowns:** list = `Options`, option text = `Options.Current.Label`, option value = `Options.Current.Value`, empty text = `Not set`.
- **Value inputs:** Input Type Text. Under Attributes, add `inputmode` = `decimal` so phones show the number keypad.
- **Visible**, for example on the Good row:
  - GoodValue: `DataType = "NUMERIC" and ThresholdValueCount(GoodRule.Operator) >= 1`
  - GoodValueTo: `DataType = "NUMERIC" and ThresholdValueCount(GoodRule.Operator) = 2`
  - GoodText: `DataType = "TEXT" and ThresholdValueCount(GoodRule.Operator) >= 1`
- **Below the three cards:**
  - the `ThresholdBar` block, with RulesJSON = `RulesJSON`, DataType = `DataType` and Unit = `Unit`;
  - a List over `Validation.Warnings` showing `Validation.Warnings.Current.Message` (an OutSystems UI Alert, warning style, works well), with Visible = `Validation.HasWarnings`.

### Events

**On Initialize**
1. JSON Deserialize `InitialRulesJSON` into a `ThresholdRule List`.
2. Assign GoodRule, MediumRule and BadRule from it, filtering by Rating. Set Rating to `"GOOD"`, `"MEDIUM"` or `"BAD"` on any that are missing.
3. Call `ThresholdOperators(DataType)` and assign it to `Options`.

**On Ready**, call `Revalidate(ShowErrors = ShowAllErrors)`. This draws the bar for the saved values without shouting at an untouched form.

**On Parameters Changed:** if DataType changed, reload `Options`. Then call `Revalidate(ShowErrors = ShowAllErrors or Touched)`.

**OnChange of all 12 widgets**, the dropdowns and inputs: point every one at the same client action, `RulesOnChange`:

1. Assign `Touched = True`.
2. Call `Revalidate(ShowErrors = True)`.
3. Trigger Event `Changed` with RulesJSON = `RulesJSON` and IsValid = `Validation.IsValid`.

**Client action `Revalidate`** (input ShowErrors, Boolean):

1. **Assign**
   ```
   RulesJSON = "[" + JSONSerialize(GoodRule) + "," + JSONSerialize(MediumRule) + "," + JSONSerialize(BadRule) + "]"
   ```
2. **Call** `ThresholdValidate(RulesJSON, DataType, IsGoNoGo, MinValue, MaxValue)` and assign its result to `Validation`.
3. **If** ShowErrors, **Assign** each widget's validation state, one pair per widget, 24 assignments in a single Assign node. Good row:
   ```
   GoodOperator.Valid             = Validation.GoodOperatorMessage = ""
   GoodOperator.ValidationMessage = Validation.GoodOperatorMessage
   GoodValue.Valid                = Validation.GoodValueMessage = ""
   GoodValue.ValidationMessage    = Validation.GoodValueMessage
   GoodValueTo.Valid              = Validation.GoodValueToMessage = ""
   GoodValueTo.ValidationMessage  = Validation.GoodValueToMessage
   GoodText.Valid                 = Validation.GoodTextMessage = ""
   GoodText.ValidationMessage     = Validation.GoodTextMessage
   ```
   Repeat for Medium and Bad. Setting `Valid = False` gives the standard OutSystems UI invalid style, with the message under the input, so the editor matches your other forms.

The bar is bound to `RulesJSON`, so step 1 also redraws it: no extra call is needed.

**How often it runs:** if your platform version fires OnChange on every keystroke, this runs as the user types. It takes well under a millisecond, so no debounce is needed. If OnChange fires only when the field loses focus, everything still works; it just updates on blur.

### Using it on a screen

```
ThresholdEditor
  InitialRulesJSON = <JSON of the parameter's saved rules>
  DataType         = Attribute.DataTypeCode
  Unit             = Unit.Symbol
  IsGoNoGo         = CriterionType.IsGoNoGo
  ShowAllErrors    = SaveClicked
  Changed          -> store RulesJSON and IsValid in screen variables
```

**On Save:**
1. Set `SaveClicked = True`. The block then shows every error.
2. If `IsValid` is False, stop.
3. Otherwise, deserialize RulesJSON and call your server action that saves the rules.

Convert the values with `TextToDecimal(Replace(Value, ",", "."))`.

Keep the checks in the server action or database as well. Browser validation helps the user, but it can be bypassed. The `set_rule` function and the publish checks in the data model already do this.

---

## 6. Messages and translation

Every text lives in `MESSAGES` at the top of `tcp-thresholds.js`. To translate them, call this once at startup, for example in the app's **OnApplicationReady** client event:

```js
TcpThresholds.setMessages({
  ratingGOOD: 'Bom', ratingMEDIUM: 'Médio', ratingBAD: 'Mau',
  valueRequired: 'Introduza um valor.',
  valueNumber: 'Introduza um número, por exemplo 10 ou 0,5.',
  gapBetween: 'Resultados entre {a} e {b} não têm classificação.'
  // ...any other key
});
```

You can also pass `messages: {...}` in the options of a single call.

## 7. What is checked

| Check | Where it shows | Blocks saving |
| --- | --- | --- |
| Required rating missing (Bad in Go/No-Go, or `requireRatings`) | Operator dropdown | Yes |
| Condition doesn't fit the attribute type | Operator dropdown | Yes |
| Value empty or not a number | Value input | Yes |
| Value outside `min` / `max` | Value or ValueTo input | Yes |
| Upper value empty, or lower than the first value | ValueTo input | Yes |
| Text empty for a text condition | Text input | Yes |
| Results no rule covers (below, above, between two values, or one exact value) | Warnings list, plus hatched on the bar | No |
| A rating that can never apply because an earlier one covers all its values | Warnings list | No |
| Two ratings overlap over a range (the earlier one wins there) | Warnings list | No |
| Two text rules match the same text | Warnings list | No |
| Present or absent result not rated | Warnings list | No |

Warnings don't block saving, because a scientist may leave a range unrated on purpose. To make them blocking too, check `Validation.HasWarnings` in your Save logic.
