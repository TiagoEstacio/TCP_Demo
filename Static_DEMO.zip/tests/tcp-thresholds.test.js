// Run: node tests/tcp-thresholds.test.js
const assert = require('assert');
const T = require('../tcp-thresholds.js');

const R = (rating, op, v = '', to = '', text = '') => ({ Rating: rating, Operator: op, Value: v, ValueTo: to, Text: text });
let n = 0;
const test = (name, fn) => { fn(); n++; console.log('ok  ', name); };
const msgs = (res) => res.warnings.map((w) => w.message);

test('complete numeric set is valid with no warnings', () => {
  const res = T.validate([R('GOOD', 'LT', '10'), R('MEDIUM', 'BETWEEN', '10', '100'), R('BAD', 'GT', '100')], 'NUMERIC');
  assert.strictEqual(res.isValid, true);
  assert.deepStrictEqual(msgs(res), []);
  assert.strictEqual(res.summary, 'Good < 10, Medium 10 – 100, Bad > 100');
});

test('gap between ranges is reported', () => {
  const res = T.validate([R('GOOD', 'GT', '40'), R('MEDIUM', 'BETWEEN', '10', '30'), R('BAD', 'LT', '10')]);
  assert.deepStrictEqual(msgs(res), ['Results between 30 and 40 are not rated.']);
});

test('single boundary value left out is reported', () => {
  const res = T.validate([R('GOOD', 'GT', '30'), R('BAD', 'LT', '30')]);
  assert.deepStrictEqual(msgs(res), ['A result of exactly 30 is not rated.']);
});

test('open ends are reported', () => {
  const res = T.validate([R('MEDIUM', 'BETWEEN', '10', '20')]);
  assert.deepStrictEqual(msgs(res), ['Results below 10 are not rated.', 'Results above 20 are not rated.']);
});

test('empty, non-numeric and reversed values are field errors', () => {
  const res = T.validate([R('GOOD', 'LT', ''), R('MEDIUM', 'BETWEEN', '50', '10'), R('BAD', 'GT', 'abc')]);
  assert.strictEqual(res.isValid, false);
  assert.strictEqual(res.fields.GOOD.Value, 'Enter a value.');
  assert.strictEqual(res.fields.MEDIUM.ValueTo, 'Enter a value of at least 50.');
  assert.strictEqual(res.fields.BAD.Value, 'Enter a number, for example 10 or 0.5.');
});

test('missing upper value of a range', () => {
  const res = T.validate([R('MEDIUM', 'BETWEEN', '5', '')]);
  assert.strictEqual(res.fields.MEDIUM.ValueTo, 'Enter the upper value.');
});

test('decimal comma is accepted', () => {
  const res = T.validate([R('GOOD', 'GTE', '0,5'), R('BAD', 'LT', '0,5')]);
  assert.strictEqual(res.isValid, true);
  assert.strictEqual(res.complete.GOOD.value, 0.5);
  assert.deepStrictEqual(msgs(res), []);
});

test('min and max limits', () => {
  const res = T.validate([R('GOOD', 'GTE', '120'), R('BAD', 'LT', '-1')], 'NUMERIC', { min: 0, max: 100 });
  assert.strictEqual(res.fields.GOOD.Value, 'Enter 100 or less.');
  assert.strictEqual(res.fields.BAD.Value, 'Enter 0 or more.');
});

test('operator that does not fit the data type', () => {
  const res = T.validate([R('GOOD', 'EXISTS')], 'NUMERIC');
  assert.strictEqual(res.fields.GOOD.Operator, 'This condition can’t be used for numeric attributes.');
});

test('Go/No-Go requires a Bad rule', () => {
  const res = T.validate([R('GOOD', 'LT', '10')], 'NUMERIC', { isGoNoGo: true });
  assert.strictEqual(res.isValid, false);
  assert.strictEqual(res.fields.BAD.Operator, 'Set a Bad condition.');
});

test('a rating that can never apply', () => {
  const res = T.validate([R('GOOD', 'LT', '50'), R('MEDIUM', 'BETWEEN', '10', '40'), R('BAD', 'GTE', '50')]);
  assert.ok(msgs(res).includes('Medium never applies: Good and Bad already cover all of its values.') === false);
  assert.ok(msgs(res).includes('Medium never applies: Good already covers all of its values.'), msgs(res).join(' | '));
});

test('overlapping ranges are explained', () => {
  const res = T.validate([R('GOOD', 'LT', '50'), R('MEDIUM', 'BETWEEN', '10', '100'), R('BAD', 'GT', '100')]);
  assert.deepStrictEqual(msgs(res), ['Good and Medium overlap from 10 to 50. Good takes priority there.']);
});

test('presence rules: gap and complete', () => {
  assert.deepStrictEqual(msgs(T.validate([R('GOOD', 'NOT_EXISTS')], 'PRESENCE')), ['A present result is not rated.']);
  assert.deepStrictEqual(msgs(T.validate([R('GOOD', 'NOT_EXISTS'), R('BAD', 'EXISTS')], 'PRESENCE')), []);
});

test('text rules: required text and duplicates', () => {
  const a = T.validate([R('GOOD', 'EQ', '', '', '  ')], 'TEXT');
  assert.strictEqual(a.fields.GOOD.Text, 'Enter the text to match.');
  const b = T.validate([R('GOOD', 'EQ', '', '', 'low'), R('MEDIUM', 'EQ', '', '', 'Low')], 'TEXT');
  assert.deepStrictEqual(msgs(b), ['Good and Medium both match “Low”. Good takes priority.']);
});

test('OutSystems result is flat and JSON', () => {
  const json = T.validateForOutSystems(JSON.stringify([R('GOOD', 'LT', ''), R('BAD', 'GT', '10')]), 'NUMERIC', '{"isGoNoGo":true}');
  const o = JSON.parse(json);
  assert.strictEqual(o.IsValid, false);
  assert.strictEqual(o.GoodValueMessage, 'Enter a value.');
  assert.strictEqual(o.BadOperatorMessage, '');
  assert.strictEqual(typeof o.MediumValueToMessage, 'string');
  assert.ok(Array.isArray(o.Warnings));
});

test('range warnings wait until rules are complete', () => {
  const half = T.validate([R('GOOD', 'GT', '4'), R('MEDIUM', 'BETWEEN', '10', ''), R('BAD', 'LT', '10')]);
  assert.deepStrictEqual(msgs(half), []);
  const forced = T.validate([R('GOOD', 'GT', '40'), R('MEDIUM', 'BETWEEN', '10', ''), R('BAD', 'LT', '10')], 'NUMERIC', { warnWhileIncomplete: true });
  assert.deepStrictEqual(msgs(forced), ['Results between 10 and 40 are not rated.']);
});

test('camelCase input and object keyed by rating', () => {
  const res = T.validate({ GOOD: { operator: 'LT', value: 10 }, BAD: { operator: 'GTE', value: 10 } });
  assert.strictEqual(res.isValid, true);
  assert.deepStrictEqual(msgs(res), []);
});

test('custom messages (translation)', () => {
  const res = T.validate([R('GOOD', 'LT', '')], 'NUMERIC', { messages: { valueRequired: 'Introduza um valor.' } });
  assert.strictEqual(res.fields.GOOD.Value, 'Introduza um valor.');
});

test('operators per data type', () => {
  assert.deepStrictEqual(T.operatorsFor('PRESENCE').map((o) => o.Value), ['EXISTS', 'NOT_EXISTS']);
  assert.strictEqual(T.operatorsFor('TEXT').length, 3);
  assert.strictEqual(T.valueCount('BETWEEN'), 2);
});

console.log(`\n${n} tests passed`);
