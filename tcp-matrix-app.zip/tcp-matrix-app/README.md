# TCP Matrix

A small web app for the TCP parameters matrix (schema v2, PostgreSQL). Use it to:

- set pillars, weights, key design principles and criteria for a Target Candidate Profile;
- define each attribute's Good / Medium / Bad thresholds, with operators matched to the attribute type;
- start, check, submit, publish or discard versions;
- compare any two versions field by field, and see the history of a single pillar or attribute.

The app writes only through the database functions in the `tcp` schema (`add_item`, `update_item`,
`set_rule`, `publish_version`, …), so the versioning rules live in one place.

## What you need

- Node.js 18 or later (`node -v`)
- PostgreSQL 13 or later, with the database you can reach from pgAdmin

## Set it up

1. Unzip the folder, open a terminal in it and install the dependencies:

   ```
   npm install
   ```

2. Copy `.env.example` to `.env` and put your PostgreSQL password and database name in `DATABASE_URL`:

   ```
   DATABASE_URL=postgres://postgres:YOUR_PASSWORD@localhost:5432/tcp_matrix_v2
   ```

3. Install the schema. This creates the database if it doesn't exist:

   ```
   npm run db:demo     # schema plus the sample profile "KX-1 lead profile"
   # or
   npm run db:init     # schema only, empty
   ```

   If you already ran `tcp_matrix_v2_postgres.sql` in pgAdmin, point `DATABASE_URL` at that database
   and skip this step. If that database still holds the first (v1) script, use a new database name,
   or run `npm run db:init -- --reset` to replace it. `--reset` deletes the data in the `tcp` schema.

4. Start the app and open http://localhost:3000:

   ```
   npm start
   ```

## How to use it

- **Parameters** shows the selected version. Published and superseded versions are read-only.
  Click **Start new version**, give a reason, then edit. Every field saves when you leave it.
  Rows and pillars changed in the draft get an indigo marker.
- In a threshold cell, choose the condition (`<`, `≥`, `between`, `exists`, …), then type the value.
  A dashed outline means the cell still needs a value and hasn't been saved.
- **Check** runs every publish rule without publishing. **Publish** makes the draft the current version,
  writes the change log and stores a SHA-256 fingerprint of the version.
- **Compare versions** lists what changed between any two versions. The draft count on the tab shows
  how many items the open draft changes. Click a version on the timeline to choose the "To" version.
- **History** lists every version with its stage, reason and logged changes. The ⟲ button on a pillar or
  attribute shows that item's published history.

## Good to know

- There is no login yet. Changes are recorded as user `APP_USER_ID` from `.env` (default 1), or the
  `x-user-id` request header. Put the app behind your company sign-on before sharing it.
- Fonts load from Google Fonts when online. Without internet access the app uses system fonts.
- Lists such as stages, modalities and expected completion come from the demo seed. Edit them in the
  database (`tcp.tcp_stage`, `tcp.modality`, …). Pillars and attributes can also be added in the app.

## Troubleshooting

| Message | What to do |
| --- | --- |
| `connect ECONNREFUSED` or a timeout | PostgreSQL isn't running, or the host/port in `DATABASE_URL` is wrong. Check that pgAdmin can connect with the same settings. |
| `password authentication failed` | Fix the password in `DATABASE_URL`. Special characters in the password must be URL-encoded (`@` → `%40`). |
| `The TCP schema is not installed` | Run `npm run db:init`. |
| `A "tcp" schema from an older script exists` | Use a new database name, or `npm run db:init -- --reset`. |

## Files

```
server.js              Express server (API under /api, front end from /public)
lib/db.js              connection pool, reads .env
lib/routes.js          API routes; changes go through the tcp.* functions
scripts/db-init.js     creates the database and installs the schema
db/                    tcp_matrix_v2_postgres.sql and tcp_matrix_v2_demo.sql
public/                index.html, app.css, app.js (no build step)
```
