/* =============================================================================
   TCP Parameters Matrix - schema v2 for PostgreSQL
   -----------------------------------------------------------------------------
   Target    : PostgreSQL 13+ (tested on 16). Needs the btree_gist extension,
               which ships with every standard install (EDB, Postgres.app,
               Homebrew, the official Docker image).
   Run       : pgAdmin 4 Query Tool on an empty database -> Open File -> F5,
               or  psql -d tcp_matrix -f tcp_matrix_v2_postgres.sql
               One transaction: it creates everything or nothing.
               To re-run:  DROP SCHEMA tcp CASCADE;

   HOW VERSIONING WORKS (row ranges, no full copies)
   -----------------------------------------------------------------------------
   * Each matrix item has a stable ANCHOR row (tcp_pillar, tcp_criterion,
     tcp_parameter) and one or more REVISION rows (..._rev) holding its values.
   * A revision is valid for a range of TCP version numbers:
         from_version .. to_version   (to_version NULL = still current)
     The item as it was in version N is the revision whose range contains N.
   * Editing in the open Draft (version D):
       - item unchanged so far -> its current revision is closed at D-1 and a
         new revision starting at D is created (only that row is copied);
       - item already changed in D -> its D revision is updated in place;
       - removing an item -> its revision is closed at D-1 (or deleted if it
         was created in D). Nothing is physically deleted from history.
   * Publishing is a status change plus a change log write - no copying.
     Discarding a draft deletes the D revisions and reopens what D closed.
   * Storage grows with the number of CHANGES, not versions x matrix size.
   * Any two versions compare by joining their items on the anchor id;
     items whose revision id is the same in both are unchanged and skipped.
   * Adding a field = ALTER TABLE ... ADD COLUMN on a *_rev table. Copying,
     editing (update_item) and comparing pick it up automatically; only a new
     lookup (foreign key) column needs one line in label_of() for display.

   Sections  : 1 Static lookups   2 Reference data   3 Target and TCP
               4 Versioned matrix 5 Experiments      6 Indexes
               7 Helper functions 8 Editing API      9 Lifecycle API
               10 Read and compare 11 Scoring        12 Views
   ============================================================================= */

BEGIN;

CREATE EXTENSION IF NOT EXISTS btree_gist;   -- lets one GiST index mix "=" and range overlap
CREATE SCHEMA tcp;
SET LOCAL search_path = tcp, public;

/* =============================================================================
   1. STATIC LOOKUPS - fixed ids, logic refers to their codes
      (OutSystems: Static Entities)
   ============================================================================= */

CREATE TABLE attribute_data_type (
    id smallint PRIMARY KEY, code varchar(20) NOT NULL UNIQUE, label varchar(50) NOT NULL,
    sort_order int NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO attribute_data_type VALUES
    (1, 'NUMERIC',  'Numeric',           1, true),
    (2, 'TEXT',     'Text',              2, true),
    (3, 'PRESENCE', 'Presence (exists)', 3, true);

CREATE TABLE comparison_operator (
    id smallint PRIMARY KEY, code varchar(20) NOT NULL UNIQUE, label varchar(50) NOT NULL,
    symbol varchar(10) NOT NULL,
    value_count smallint NOT NULL CHECK (value_count BETWEEN 0 AND 2),   -- inputs the UI shows
    for_numeric boolean NOT NULL, for_text boolean NOT NULL, for_presence boolean NOT NULL,
    sort_order int NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO comparison_operator VALUES
    ( 1, 'LT',         'Lower than',          '<',     1, true,  false, false,  1, true),
    ( 2, 'LTE',        'Lower or equal',      '<=',    1, true,  false, false,  2, true),
    ( 3, 'GT',         'Greater than',        '>',     1, true,  false, false,  3, true),
    ( 4, 'GTE',        'Greater or equal',    '>=',    1, true,  false, false,  4, true),
    ( 5, 'EQ',         'Equal to',            '=',     1, true,  true,  false,  5, true),
    ( 6, 'NEQ',        'Not equal to',        '<>',    1, true,  true,  false,  6, true),
    ( 7, 'BETWEEN',    'Between (inclusive)', '[a,b]', 2, true,  false, false,  7, true),
    ( 8, 'OUTSIDE',    'Outside range',       ']a,b[', 2, true,  false, false,  8, true),
    ( 9, 'CONTAINS',   'Contains text',       '~',     1, false, true,  false,  9, true),
    (10, 'EXISTS',     'Exists',              'yes',   0, false, false, true,  10, true),
    (11, 'NOT_EXISTS', 'Does not exist',      'no',    0, false, false, true,  11, true);

CREATE TABLE rating_level (
    id smallint PRIMARY KEY, code varchar(20) NOT NULL UNIQUE, label varchar(50) NOT NULL,
    score_factor numeric(5,4) NOT NULL CHECK (score_factor BETWEEN 0 AND 1),
    evaluation_order int NOT NULL,          -- rules are tried Good -> Medium -> Bad
    color_token varchar(30) NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO rating_level VALUES
    (1, 'GOOD',   'Good',   1.0, 1, 'status-good',     true),
    (2, 'MEDIUM', 'Medium', 0.5, 2, 'status-warning',  true),
    (3, 'BAD',    'Bad',    0.0, 3, 'status-critical', true);

-- "Impact" in the current model = criticality of an attribute
CREATE TABLE impact_level (
    id smallint PRIMARY KEY, code varchar(20) NOT NULL UNIQUE, label varchar(50) NOT NULL,
    default_weight numeric(9,4) NOT NULL CHECK (default_weight >= 0),
    sort_order int NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO impact_level VALUES
    (1, 'LOW', 'Low', 1, 1, true), (2, 'MEDIUM', 'Medium', 2, 2, true), (3, 'HIGH', 'High', 3, 3, true);

CREATE TABLE criterion_type (
    id smallint PRIMARY KEY, code varchar(30) NOT NULL UNIQUE, label varchar(100) NOT NULL,
    allows_parameters boolean NOT NULL,     -- can hold attribute rows with Good/Medium/Bad rules
    is_go_no_go boolean NOT NULL,           -- a Bad rating here gates the outcome
    sort_order int NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO criterion_type VALUES
    (1, 'QUANT_CANDIDATE',  'Key Quantitative (Candidate) Criteria', true,  false, 1, true),
    (2, 'KEY_COMPETITOR',   'Key Competitor Parameters',             true,  false, 2, true),
    (3, 'QUANT_GO_NO_GO',   'Quantitative Go/No-Go Criteria',        true,  true,  3, true),
    (4, 'RATIONALE',        'Design Principle Rationale',            false, false, 4, true);

CREATE TABLE version_status (
    id smallint PRIMARY KEY, code varchar(20) NOT NULL UNIQUE, label varchar(50) NOT NULL,
    is_editable boolean NOT NULL, sort_order int NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO version_status VALUES
    (1, 'DRAFT', 'Draft', true, 1, true), (2, 'IN_REVIEW', 'In Review', false, 2, true),
    (3, 'PUBLISHED', 'Published', false, 3, true), (4, 'SUPERSEDED', 'Superseded', false, 4, true),
    (5, 'ARCHIVED', 'Archived', false, 5, true);

CREATE TABLE tcp_status (                 -- lifecycle of the TCP itself
    id smallint PRIMARY KEY, code varchar(20) NOT NULL UNIQUE, label varchar(50) NOT NULL,
    sort_order int NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO tcp_status VALUES
    (1, 'ACTIVE', 'Active', 1, true), (2, 'ON_HOLD', 'On hold', 2, true), (3, 'CLOSED', 'Closed', 3, true);

CREATE TABLE edit_type (                  -- "Type" of a change in the current audit model
    id smallint PRIMARY KEY, code varchar(30) NOT NULL UNIQUE, label varchar(100) NOT NULL,
    sort_order int NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO edit_type VALUES
    (1, 'INITIAL', 'Initial version', 1, true), (2, 'SCIENTIFIC_UPDATE', 'Scientific update', 2, true),
    (3, 'STAGE_CHANGE', 'Stage change', 3, true), (4, 'CORRECTION', 'Correction', 4, true);

CREATE TABLE item_type (                  -- what a change-log row is about
    id smallint PRIMARY KEY, code varchar(20) NOT NULL UNIQUE, label varchar(50) NOT NULL,
    sort_order int NOT NULL
);
INSERT INTO item_type VALUES
    (1, 'HEADER', 'TCP header', 1), (2, 'IMPACT_WEIGHT', 'Impact weight', 2),
    (3, 'TR_NUMBER', 'TR number', 3), (4, 'PILLAR', 'Pillar', 4),
    (5, 'CRITERION', 'Criterion', 5), (6, 'PARAMETER', 'Parameter', 6);

CREATE TABLE change_type (
    id smallint PRIMARY KEY, code varchar(20) NOT NULL UNIQUE, label varchar(50) NOT NULL, sort_order int NOT NULL
);
INSERT INTO change_type VALUES (1, 'ADDED', 'Added', 1), (2, 'REMOVED', 'Removed', 2), (3, 'MODIFIED', 'Modified', 3);

CREATE TABLE experiment_outcome (
    id smallint PRIMARY KEY, code varchar(20) NOT NULL UNIQUE, label varchar(50) NOT NULL, sort_order int NOT NULL
);
INSERT INTO experiment_outcome VALUES (1, 'GO', 'Go', 1), (2, 'NO_GO', 'No-Go', 2), (3, 'INCOMPLETE', 'Incomplete', 3);

/* =============================================================================
   2. REFERENCE DATA - users / admins can add values (not static)
      Seeded values are EXAMPLES: replace them with your own lists.
   ============================================================================= */

CREATE TABLE modality (
    id int GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name varchar(100) NOT NULL UNIQUE,
    sort_order int NOT NULL DEFAULT 100, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO modality (name, sort_order) VALUES
    ('Small molecule', 1), ('Monoclonal antibody', 2), ('Peptide', 3), ('Oligonucleotide', 4), ('Cell therapy', 5);

CREATE TABLE therapeutic_area (
    id int GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name varchar(100) NOT NULL UNIQUE,
    sort_order int NOT NULL DEFAULT 100, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO therapeutic_area (name, sort_order) VALUES
    ('Oncology', 1), ('Immunology', 2), ('Neuroscience', 3), ('Cardiometabolic', 4), ('Infectious disease', 5);

CREATE TABLE tcp_stage (
    id int GENERATED ALWAYS AS IDENTITY PRIMARY KEY, code varchar(30) NOT NULL UNIQUE,
    name varchar(100) NOT NULL, sort_order int NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO tcp_stage (code, name, sort_order) VALUES
    ('TARGET_ID', 'Target identification', 1), ('HIT_TO_LEAD', 'Hit to lead', 2),
    ('LEAD_OPT', 'Lead optimisation', 3), ('PRE_PS', 'Pre-PS', 4), ('CANDIDATE', 'Candidate selection', 5);

CREATE TABLE expected_completion (
    id int GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name varchar(100) NOT NULL UNIQUE,
    sort_order int NOT NULL DEFAULT 100, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO expected_completion (name, sort_order) VALUES
    ('Before lead series nomination', 1), ('Before candidate selection', 2), ('Before first-in-human', 3);

CREATE TABLE pillar (
    id int GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name varchar(100) NOT NULL UNIQUE,
    description varchar(1000), is_system boolean NOT NULL DEFAULT false,   -- false = custom pillar
    sort_order int NOT NULL DEFAULT 100, is_active boolean NOT NULL DEFAULT true,
    created_by int, created_on timestamptz NOT NULL DEFAULT now()
);
INSERT INTO pillar (name, is_system, sort_order) VALUES
    ('Safety', true, 1), ('Potency', true, 2), ('Selectivity', true, 3),
    ('PK/ADME', true, 4), ('Developability', true, 5), ('Efficacy', true, 6);

CREATE TABLE unit (
    id int GENERATED ALWAYS AS IDENTITY PRIMARY KEY, symbol varchar(20) NOT NULL UNIQUE,
    name varchar(100) NOT NULL, is_active boolean NOT NULL DEFAULT true
);
INSERT INTO unit (symbol, name) VALUES
    ('nM', 'Nanomolar'), ('µM', 'Micromolar'), ('%', 'Percent'), ('h', 'Hours'),
    ('mg/kg', 'Milligram per kilogram'), ('mL/min/kg', 'Clearance'), ('fold', 'Fold ratio');

CREATE TABLE attribute (
    id int GENERATED ALWAYS AS IDENTITY PRIMARY KEY, name varchar(200) NOT NULL,
    description varchar(1000),
    data_type_id smallint NOT NULL REFERENCES attribute_data_type (id),
    default_unit_id int REFERENCES unit (id),
    is_system boolean NOT NULL DEFAULT false, is_active boolean NOT NULL DEFAULT true,
    created_by int, created_on timestamptz NOT NULL DEFAULT now(), updated_by int, updated_on timestamptz
);
CREATE UNIQUE INDEX ux_attribute_name_unit ON attribute (name, COALESCE(default_unit_id, 0));

/* =============================================================================
   3. TARGET AND TCP
   ============================================================================= */

-- Master list of research targets (current model: Master\TargetResearch).
-- Existing programs come with codes; a new program is a row with a name only.
CREATE TABLE target_research (
    id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    name                varchar(200)  NOT NULL,
    pfr_code            varchar(30),
    pfc_code            varchar(30),
    external_id         varchar(50),               -- id in the portfolio system
    is_existing_program boolean       NOT NULL,     -- false = new program, no code yet
    modality_id         int           REFERENCES modality (id),
    therapeutic_area_id int           REFERENCES therapeutic_area (id),
    moa                 varchar(500),               -- mechanism of action
    is_tcp_pre_ps       boolean       NOT NULL DEFAULT false,
    is_active           boolean       NOT NULL DEFAULT true,
    created_by          int           NOT NULL,
    created_on          timestamptz   NOT NULL DEFAULT now(),
    updated_by          int,
    updated_on          timestamptz,
    CONSTRAINT ck_target_research_existing_has_code
        CHECK (NOT is_existing_program OR COALESCE(pfr_code, pfc_code, external_id) IS NOT NULL)
);
CREATE UNIQUE INDEX ux_target_research_external_id ON target_research (external_id) WHERE external_id IS NOT NULL;
CREATE UNIQUE INDEX ux_target_research_new_name    ON target_research (name)
    WHERE pfr_code IS NULL AND pfc_code IS NULL AND external_id IS NULL;

-- The TCP (current model: TargetCriteria\TargetDetail). Not versioned itself;
-- its content lives in tcp_version (header) and the versioned matrix below.
CREATE TABLE tcp (
    id                           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    target_research_id           bigint        NOT NULL REFERENCES target_research (id),
    name                         varchar(200)  NOT NULL,
    status_id                    smallint      NOT NULL DEFAULT 1 REFERENCES tcp_status (id),
    current_published_version_no int,          -- maintained by publish_version()
    is_active                    boolean       NOT NULL DEFAULT true,
    created_by                   int           NOT NULL,
    created_on                   timestamptz   NOT NULL DEFAULT now(),
    updated_by                   int,
    updated_on                   timestamptz,
    CONSTRAINT uq_tcp_target_name UNIQUE (target_research_id, name)
);

-- One row per version. Holds the versioned TCP header (modality, TA, MOA,
-- stage) and why the version exists. Previous stage = stage of the previous
-- version (see v_tcp_version_history), so it is not stored twice.
CREATE TABLE tcp_version (
    id                  bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_id              bigint        NOT NULL REFERENCES tcp (id),
    version_no          int           NOT NULL CHECK (version_no > 0),
    status_id           smallint      NOT NULL REFERENCES version_status (id),
    -- versioned header (defaults from target_research when the TCP is created)
    modality_id         int           REFERENCES modality (id),
    therapeutic_area_id int           REFERENCES therapeutic_area (id),
    moa                 varchar(500),
    stage_id            int           REFERENCES tcp_stage (id),
    -- why this version exists (not compared between versions)
    edit_type_id        smallint      REFERENCES edit_type (id),
    reason_for_edit     varchar(2000),
    comments            varchar(4000),
    -- frozen copy written on publish (audit evidence)
    snapshot            jsonb,
    snapshot_hash       bytea,
    created_by          int           NOT NULL,
    created_on          timestamptz   NOT NULL DEFAULT now(),
    submitted_by        int,
    submitted_on        timestamptz,
    published_by        int,
    published_on        timestamptz,
    CONSTRAINT uq_tcp_version_no UNIQUE (tcp_id, version_no)
);
CREATE UNIQUE INDEX ux_tcp_version_one_open      ON tcp_version (tcp_id) WHERE status_id IN (1, 2);
CREATE UNIQUE INDEX ux_tcp_version_one_published ON tcp_version (tcp_id) WHERE status_id = 3;

/* =============================================================================
   4. VERSIONED MATRIX
   Pattern on every *_rev table:
     from_version int NOT NULL, to_version int NULL,
     valid_range  = [from_version, to_version]  (generated, indexed)
     EXCLUDE ... no two revisions of one item overlap
     UNIQUE ... WHERE to_version IS NULL: at most one current revision
   ============================================================================= */

-- Impact (criticality) weights used for scoring, per TCP and version
CREATE TABLE tcp_impact_weight (
    id              bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_id          bigint       NOT NULL REFERENCES tcp (id),
    impact_level_id smallint     NOT NULL REFERENCES impact_level (id),
    weight          numeric(9,4) NOT NULL CHECK (weight >= 0),
    from_version    int          NOT NULL,
    to_version      int,
    valid_range     int4range    GENERATED ALWAYS AS (int4range(from_version, to_version, '[]')) STORED,
    created_by      int,
    created_on      timestamptz  NOT NULL DEFAULT now(),
    CONSTRAINT ck_tiw_range CHECK (to_version IS NULL OR to_version >= from_version),
    CONSTRAINT ex_tiw_overlap EXCLUDE USING gist (tcp_id WITH =, impact_level_id WITH =, valid_range WITH &&)
);

-- TR numbers linked to the TCP (current model: TRNumberList, now one row each)
CREATE TABLE tcp_tr_number (
    id           bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_id       bigint       NOT NULL REFERENCES tcp (id),
    tr_number    varchar(50)  NOT NULL,
    from_version int          NOT NULL,
    to_version   int,
    valid_range  int4range    GENERATED ALWAYS AS (int4range(from_version, to_version, '[]')) STORED,
    created_by   int,
    created_on   timestamptz  NOT NULL DEFAULT now(),
    CONSTRAINT ck_ttn_range CHECK (to_version IS NULL OR to_version >= from_version),
    CONSTRAINT ex_ttn_overlap EXCLUDE USING gist (tcp_id WITH =, tr_number WITH =, valid_range WITH &&)
);

-- PILLAR (current model: TargetConfiguration)
CREATE TABLE tcp_pillar (
    id                 bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_id             bigint      NOT NULL REFERENCES tcp (id),
    created_in_version int         NOT NULL,
    created_by         int,
    created_on         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE tcp_pillar_rev (
    id                        bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_pillar_id             bigint        NOT NULL REFERENCES tcp_pillar (id) ON DELETE CASCADE,
    from_version              int           NOT NULL,
    to_version                int,
    valid_range               int4range     GENERATED ALWAYS AS (int4range(from_version, to_version, '[]')) STORED,
    -- versioned values
    pillar_id                 int           NOT NULL REFERENCES pillar (id),
    weight                    numeric(9,4)  NOT NULL CHECK (weight >= 0),
    design_principle_category varchar(200),
    key_design_principle      varchar(2000) NOT NULL,   -- the question this pillar parametrizes
    expected_completion_id    int           REFERENCES expected_completion (id),
    sequence                  int           NOT NULL DEFAULT 0,
    send_to_control_tower     boolean       NOT NULL DEFAULT false,
    comments                  varchar(4000),
    created_by                int,
    created_on                timestamptz   NOT NULL DEFAULT now(),
    CONSTRAINT ck_tpr_range CHECK (to_version IS NULL OR to_version >= from_version),
    CONSTRAINT ex_tpr_overlap EXCLUDE USING gist (tcp_pillar_id WITH =, valid_range WITH &&)
);

-- CRITERION section of a pillar (current model: TargetConfigurationCriteria,
-- now attached to the pillar). One anchor per pillar and criterion type.
CREATE TABLE tcp_criterion (
    id                 bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_id             bigint      NOT NULL REFERENCES tcp (id),
    tcp_pillar_id      bigint      NOT NULL REFERENCES tcp_pillar (id) ON DELETE CASCADE,
    criterion_type_id  smallint    NOT NULL REFERENCES criterion_type (id),
    created_in_version int         NOT NULL,
    created_by         int,
    created_on         timestamptz NOT NULL DEFAULT now(),
    CONSTRAINT uq_tcp_criterion_pillar_type UNIQUE (tcp_pillar_id, criterion_type_id)
);

CREATE TABLE tcp_criterion_rev (
    id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_criterion_id bigint        NOT NULL REFERENCES tcp_criterion (id) ON DELETE CASCADE,
    from_version     int           NOT NULL,
    to_version       int,
    valid_range      int4range     GENERATED ALWAYS AS (int4range(from_version, to_version, '[]')) STORED,
    main_text        varchar(4000),                    -- rationale text or section note
    created_by       int,
    created_on       timestamptz   NOT NULL DEFAULT now(),
    CONSTRAINT ck_tcr_range CHECK (to_version IS NULL OR to_version >= from_version),
    CONSTRAINT ex_tcr_overlap EXCLUDE USING gist (tcp_criterion_id WITH =, valid_range WITH &&)
);

-- PARAMETER: one attribute row of a criterion grid
-- (current model: TargetConfigurationParameter + the values in CriteriaColumnJSON)
CREATE TABLE tcp_parameter (
    id                 bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_id             bigint      NOT NULL REFERENCES tcp (id),
    tcp_criterion_id   bigint      NOT NULL REFERENCES tcp_criterion (id) ON DELETE CASCADE,
    created_in_version int         NOT NULL,
    created_by         int,
    created_on         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE tcp_parameter_rev (
    id               bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_parameter_id bigint        NOT NULL REFERENCES tcp_parameter (id) ON DELETE CASCADE,
    from_version     int           NOT NULL,
    to_version       int,
    valid_range      int4range     GENERATED ALWAYS AS (int4range(from_version, to_version, '[]')) STORED,
    attribute_id     int           NOT NULL REFERENCES attribute (id),
    unit_id          int           REFERENCES unit (id),
    impact_level_id  smallint      NOT NULL REFERENCES impact_level (id),
    sequence         int           NOT NULL DEFAULT 0,
    notes            varchar(2000),
    created_by       int,
    created_on       timestamptz   NOT NULL DEFAULT now(),
    CONSTRAINT ck_tqr_range CHECK (to_version IS NULL OR to_version >= from_version),
    CONSTRAINT ex_tqr_overlap EXCLUDE USING gist (tcp_parameter_id WITH =, valid_range WITH &&)
);

-- Good / Medium / Bad rules of one parameter revision. They are copied with
-- the revision (3 small rows), so a parameter and its thresholds version as one unit.
CREATE TABLE tcp_parameter_rule (
    id                   bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_parameter_rev_id bigint        NOT NULL REFERENCES tcp_parameter_rev (id) ON DELETE CASCADE,
    rating_level_id      smallint      NOT NULL REFERENCES rating_level (id),
    operator_id          smallint      NOT NULL REFERENCES comparison_operator (id),
    numeric_value        numeric(28,8),
    numeric_value_to     numeric(28,8),                -- BETWEEN / OUTSIDE upper bound
    text_value           varchar(500),                 -- EQ / NEQ / CONTAINS on text
    comment              varchar(1000),
    CONSTRAINT uq_tqrule_rev_rating UNIQUE (tcp_parameter_rev_id, rating_level_id),
    CONSTRAINT ck_tqrule_bounds CHECK (numeric_value_to IS NULL OR numeric_value IS NULL OR numeric_value_to >= numeric_value)
);

-- Change log written on publish (replaces TargetDetailsConfigurationAudits /
-- TargetDetailsChangeLog). Items are identified by item_key (anchor id), never
-- by row position, so reordering or deleting rows cannot misalign history.
CREATE TABLE tcp_change_log (
    id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_version_id bigint       NOT NULL REFERENCES tcp_version (id),
    item_type_id   smallint     NOT NULL REFERENCES item_type (id),
    item_key       varchar(100) NOT NULL,
    item_path      varchar(500) NOT NULL,
    field_name     varchar(100) NOT NULL,
    old_value      text,
    new_value      text,
    change_type_id smallint     NOT NULL REFERENCES change_type (id),
    comment        varchar(1000),                 -- reviewers can annotate a change
    created_on     timestamptz  NOT NULL DEFAULT now()
);

/* =============================================================================
   5. EXPERIMENTS AND SCORES - pinned to one published version
   ============================================================================= */

CREATE TABLE experiment (
    id             bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    tcp_version_id bigint        NOT NULL REFERENCES tcp_version (id),
    name           varchar(200)  NOT NULL,
    external_ref   varchar(100),                 -- ELN / LIMS id
    compound_ref   varchar(100),
    run_date       date,
    notes          varchar(4000),
    total_score    numeric(9,4),                 -- 0..100
    coverage       numeric(5,4),                 -- rated / total parameters
    outcome_id     smallint      REFERENCES experiment_outcome (id),
    scored_on      timestamptz,
    created_by     int           NOT NULL,
    created_on     timestamptz   NOT NULL DEFAULT now(),
    updated_by     int,
    updated_on     timestamptz
);

CREATE TABLE experiment_measurement (
    id                   bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    experiment_id        bigint        NOT NULL REFERENCES experiment (id) ON DELETE CASCADE,
    tcp_parameter_id     bigint        NOT NULL REFERENCES tcp_parameter (id),
    numeric_value        numeric(28,8),
    text_value           varchar(500),
    is_present           boolean,
    tcp_parameter_rev_id bigint        REFERENCES tcp_parameter_rev (id),   -- set by scoring
    rating_level_id      smallint      REFERENCES rating_level (id),        -- set by scoring
    comment              varchar(1000),
    CONSTRAINT uq_em_experiment_parameter UNIQUE (experiment_id, tcp_parameter_id)
);

CREATE TABLE experiment_pillar_score (
    id            bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    experiment_id bigint       NOT NULL REFERENCES experiment (id) ON DELETE CASCADE,
    tcp_pillar_id bigint       NOT NULL REFERENCES tcp_pillar (id),
    score         numeric(9,4),                  -- 0..1, NULL when nothing rated
    rated_count   int          NOT NULL,
    total_count   int          NOT NULL,
    CONSTRAINT uq_eps_experiment_pillar UNIQUE (experiment_id, tcp_pillar_id)
);

/* =============================================================================
   6. INDEXES
   The EXCLUDE constraints already index (item, valid_range). The partial
   unique indexes guarantee one current revision and make "current" lookups fast.
   ============================================================================= */
CREATE UNIQUE INDEX ux_tiw_current ON tcp_impact_weight (tcp_id, impact_level_id) WHERE to_version IS NULL;
CREATE UNIQUE INDEX ux_ttn_current ON tcp_tr_number     (tcp_id, tr_number)       WHERE to_version IS NULL;
CREATE UNIQUE INDEX ux_tpr_current ON tcp_pillar_rev    (tcp_pillar_id)           WHERE to_version IS NULL;
CREATE UNIQUE INDEX ux_tcr_current ON tcp_criterion_rev (tcp_criterion_id)        WHERE to_version IS NULL;
CREATE UNIQUE INDEX ux_tqr_current ON tcp_parameter_rev (tcp_parameter_id)        WHERE to_version IS NULL;

CREATE INDEX ix_tcp_target            ON tcp (target_research_id);
CREATE INDEX ix_tcp_pillar_tcp        ON tcp_pillar (tcp_id);
CREATE INDEX ix_tcp_criterion_tcp     ON tcp_criterion (tcp_id);
CREATE INDEX ix_tcp_parameter_tcp     ON tcp_parameter (tcp_id);
CREATE INDEX ix_tcp_parameter_crit    ON tcp_parameter (tcp_criterion_id);
CREATE INDEX ix_tqr_attribute         ON tcp_parameter_rev (attribute_id);
CREATE INDEX ix_change_log_version    ON tcp_change_log (tcp_version_id);
CREATE INDEX ix_change_log_item       ON tcp_change_log (item_type_id, item_key);
CREATE INDEX ix_experiment_version    ON experiment (tcp_version_id);
CREATE INDEX ix_em_parameter          ON experiment_measurement (tcp_parameter_id);

/* =============================================================================
   7. HELPER FUNCTIONS (internal, prefixed with _)
   ============================================================================= */

-- maps an item level to its tables
CREATE FUNCTION _level(p_level text, OUT anchor_table text, OUT rev_table text, OUT fk_col text)
LANGUAGE plpgsql IMMUTABLE AS $$
BEGIN
    CASE upper(p_level)
        WHEN 'PILLAR'    THEN anchor_table := 'tcp_pillar';    rev_table := 'tcp_pillar_rev';    fk_col := 'tcp_pillar_id';
        WHEN 'CRITERION' THEN anchor_table := 'tcp_criterion'; rev_table := 'tcp_criterion_rev'; fk_col := 'tcp_criterion_id';
        WHEN 'PARAMETER' THEN anchor_table := 'tcp_parameter'; rev_table := 'tcp_parameter_rev'; fk_col := 'tcp_parameter_id';
        ELSE RAISE EXCEPTION 'Unknown item level "%" (use PILLAR, CRITERION or PARAMETER)', p_level;
    END CASE;
END;
$$;

-- the value columns of a table: everything except keys, range and audit columns
CREATE FUNCTION _value_cols(p_table text, p_fk text)
RETURNS text[] LANGUAGE sql STABLE
SET search_path = tcp, public AS $$
    SELECT array_agg(a.attname::text ORDER BY a.attnum)
    FROM   pg_attribute a
    WHERE  a.attrelid = ('tcp.' || p_table)::regclass
      AND  a.attnum > 0 AND NOT a.attisdropped
      AND  a.attgenerated = '' AND a.attidentity = ''
      AND  a.attname NOT IN (p_fk, 'from_version', 'to_version', 'created_by', 'created_on');
$$;

-- strips technical keys from a revision row turned into jsonb
CREATE FUNCTION _doc(p_row jsonb)
RETURNS jsonb LANGUAGE sql IMMUTABLE AS $$
    SELECT p_row - ARRAY['id', 'tcp_pillar_id', 'tcp_criterion_id', 'tcp_parameter_id',
                         'from_version', 'to_version', 'valid_range', 'created_by', 'created_on'];
$$;

-- version number of the open Draft (raises if there is none)
CREATE FUNCTION draft_version_no(p_tcp_id bigint)
RETURNS int LANGUAGE plpgsql STABLE
SET search_path = tcp, public AS $$
DECLARE v int;
BEGIN
    SELECT version_no INTO v FROM tcp_version WHERE tcp_id = p_tcp_id AND status_id = 1;
    IF v IS NULL THEN
        RAISE EXCEPTION 'TCP % has no open Draft. Call start_new_version() first.', p_tcp_id;
    END IF;
    RETURN v;
END;
$$;

-- readable text of one rule, e.g. "< 10", "Between (inclusive) 10 and 100", "= ""allosteric"""
CREATE FUNCTION rule_condition(p_rule tcp_parameter_rule)
RETURNS text LANGUAGE sql STABLE
SET search_path = tcp, public AS $$
    SELECT CASE op.value_count
             WHEN 0 THEN op.label
             WHEN 2 THEN op.label || ' ' || trim_scale(p_rule.numeric_value) || ' and ' || trim_scale(p_rule.numeric_value_to)
             ELSE op.symbol || ' ' || COALESCE(trim_scale(p_rule.numeric_value)::text, '"' || p_rule.text_value || '"')
           END
    FROM   comparison_operator op
    WHERE  op.id = p_rule.operator_id;
$$;

-- display text for a stored value: lookup ids become names, numbers lose trailing zeros.
-- Add one line here when you add a new lookup column to a *_rev table.
CREATE FUNCTION label_of(p_key text, p_val text)
RETURNS text LANGUAGE sql STABLE
SET search_path = tcp, public AS $$
    SELECT CASE
        WHEN p_val IS NULL                     THEN NULL
        WHEN p_key = 'pillar_id'               THEN (SELECT name   FROM pillar              WHERE id = p_val::int)
        WHEN p_key = 'attribute_id'            THEN (SELECT name   FROM attribute           WHERE id = p_val::int)
        WHEN p_key = 'unit_id'                 THEN (SELECT symbol FROM unit                WHERE id = p_val::int)
        WHEN p_key = 'impact_level_id'         THEN (SELECT label  FROM impact_level        WHERE id = p_val::int)
        WHEN p_key = 'expected_completion_id'  THEN (SELECT name   FROM expected_completion WHERE id = p_val::int)
        WHEN p_key = 'modality_id'             THEN (SELECT name   FROM modality            WHERE id = p_val::int)
        WHEN p_key = 'therapeutic_area_id'     THEN (SELECT name   FROM therapeutic_area    WHERE id = p_val::int)
        WHEN p_key = 'stage_id'                THEN (SELECT name   FROM tcp_stage           WHERE id = p_val::int)
        WHEN p_val ~ '^-?[0-9]+\.[0-9]+$'      THEN trim_scale(p_val::numeric)::text
        ELSE p_val
    END;
$$;

/* =============================================================================
   8. EDITING API - the only way the app changes matrix content.
      Every function works on the open Draft of the TCP.
   ============================================================================= */

-- Returns the item's revision for the Draft, copying the current one forward if needed.
CREATE FUNCTION ensure_draft_rev(p_level text, p_item_id bigint, p_user int)
RETURNS bigint LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    L       record;
    v_tcp   bigint;
    v_d     int;
    v_rev   bigint;
    v_from  int;
    v_cols  text;
    v_new   bigint;
    v_rcols text;
BEGIN
    SELECT * INTO L FROM _level(p_level);
    EXECUTE format('SELECT tcp_id FROM %I WHERE id = $1', L.anchor_table) INTO v_tcp USING p_item_id;
    IF v_tcp IS NULL THEN
        RAISE EXCEPTION '% % does not exist', initcap(p_level), p_item_id;
    END IF;
    v_d := draft_version_no(v_tcp);

    EXECUTE format('SELECT id, from_version FROM %I WHERE %I = $1 AND to_version IS NULL', L.rev_table, L.fk_col)
       INTO v_rev, v_from USING p_item_id;
    IF v_rev IS NULL THEN
        RAISE EXCEPTION '% % is not part of the draft (it was removed)', initcap(p_level), p_item_id;
    END IF;
    IF v_from = v_d THEN
        RETURN v_rev;                                     -- already changed in this draft
    END IF;

    SELECT string_agg(quote_ident(c), ', ') INTO v_cols FROM unnest(_value_cols(L.rev_table, L.fk_col)) c;

    -- close the current revision at D-1, then copy it forward from D
    EXECUTE format('UPDATE %I SET to_version = $1 WHERE id = $2', L.rev_table) USING v_d - 1, v_rev;
    EXECUTE format('INSERT INTO %1$I (%2$I, from_version, created_by, %3$s)
                    SELECT %2$I, $1, $2, %3$s FROM %1$I WHERE id = $3 RETURNING id',
                   L.rev_table, L.fk_col, v_cols)
       INTO v_new USING v_d, p_user, v_rev;

    IF L.rev_table = 'tcp_parameter_rev' THEN             -- rules travel with the revision
        SELECT string_agg(quote_ident(c), ', ') INTO v_rcols
        FROM unnest(_value_cols('tcp_parameter_rule', 'tcp_parameter_rev_id')) c;
        EXECUTE format('INSERT INTO tcp_parameter_rule (tcp_parameter_rev_id, %1$s)
                        SELECT $1, %1$s FROM tcp_parameter_rule WHERE tcp_parameter_rev_id = $2', v_rcols)
           USING v_new, v_rev;
    END IF;
    RETURN v_new;
END;
$$;

-- Adds a pillar (parent = tcp id) or a parameter (parent = tcp_criterion id).
-- p_values: jsonb with the *_rev columns, e.g. {"pillar_id":2,"weight":40,"key_design_principle":"..."}
CREATE FUNCTION add_item(p_level text, p_parent_id bigint, p_values jsonb, p_user int)
RETURNS bigint LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    L      record;
    v_tcp  bigint;
    v_d    int;
    v_id   bigint;
    v_bad  text;
    v_list text;
BEGIN
    SELECT * INTO L FROM _level(p_level);
    IF p_values IS NULL OR p_values = '{}'::jsonb THEN
        RAISE EXCEPTION 'add_item needs values';
    END IF;
    SELECT string_agg(k, ', ') INTO v_bad
    FROM jsonb_object_keys(p_values) k WHERE k <> ALL (_value_cols(L.rev_table, L.fk_col));
    IF v_bad IS NOT NULL THEN
        RAISE EXCEPTION 'Unknown field(s) for %: %', p_level, v_bad;
    END IF;

    CASE upper(p_level)
        WHEN 'PILLAR' THEN
            v_tcp := p_parent_id;
            v_d   := draft_version_no(v_tcp);
            INSERT INTO tcp_pillar (tcp_id, created_in_version, created_by)
            VALUES (v_tcp, v_d, p_user) RETURNING id INTO v_id;
        WHEN 'PARAMETER' THEN
            SELECT c.tcp_id INTO v_tcp
            FROM   tcp_criterion c
            JOIN   criterion_type ct ON ct.id = c.criterion_type_id AND ct.allows_parameters
            JOIN   tcp_criterion_rev r ON r.tcp_criterion_id = c.id AND r.to_version IS NULL
            WHERE  c.id = p_parent_id;
            IF v_tcp IS NULL THEN
                RAISE EXCEPTION 'Criterion % is not in the draft or does not take parameters', p_parent_id;
            END IF;
            v_d := draft_version_no(v_tcp);
            INSERT INTO tcp_parameter (tcp_id, tcp_criterion_id, created_in_version, created_by)
            VALUES (v_tcp, p_parent_id, v_d, p_user) RETURNING id INTO v_id;
        ELSE
            RAISE EXCEPTION 'Use save_criterion() for criteria';
    END CASE;

    SELECT string_agg(quote_ident(k), ', ') INTO v_list FROM jsonb_object_keys(p_values) k;
    EXECUTE format('INSERT INTO %1$I (%2$I, from_version, created_by, %3$s)
                    SELECT $1, $2, $3, %3$s FROM jsonb_populate_record(NULL::%1$I, $4)',
                   L.rev_table, L.fk_col, v_list)
       USING v_id, v_d, p_user, p_values;
    RETURN v_id;
END;
$$;

-- Changes fields of a pillar, criterion or parameter in the Draft.
-- A call that changes nothing creates no revision.
CREATE FUNCTION update_item(p_level text, p_item_id bigint, p_values jsonb, p_user int)
RETURNS bigint LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    L     record;
    v_bad text;
    v_cur jsonb;
    v_new jsonb;
    v_rev bigint;
    v_set text;
BEGIN
    SELECT * INTO L FROM _level(p_level);
    SELECT string_agg(k, ', ') INTO v_bad
    FROM jsonb_object_keys(p_values) k WHERE k <> ALL (_value_cols(L.rev_table, L.fk_col));
    IF v_bad IS NOT NULL THEN
        RAISE EXCEPTION 'Field(s) % cannot be edited on %', v_bad, p_level;
    END IF;

    EXECUTE format('SELECT to_jsonb(r) FROM %I r WHERE %I = $1 AND to_version IS NULL', L.rev_table, L.fk_col)
       INTO v_cur USING p_item_id;
    IF v_cur IS NULL THEN
        RAISE EXCEPTION '% % is not part of the draft', initcap(p_level), p_item_id;
    END IF;

    -- no-op when the new values equal the current ones (after type conversion)
    EXECUTE format('SELECT to_jsonb(jsonb_populate_record(NULL::%I, $1))', L.rev_table)
       INTO v_new USING v_cur || p_values;
    IF v_new = v_cur THEN
        RETURN (v_cur ->> 'id')::bigint;
    END IF;

    v_rev := ensure_draft_rev(p_level, p_item_id, p_user);
    SELECT string_agg(quote_ident(k), ', ') INTO v_set FROM jsonb_object_keys(p_values) k;
    EXECUTE format('UPDATE %1$I t SET (%2$s) = (SELECT %2$s FROM jsonb_populate_record(t, $1)) WHERE t.id = $2',
                   L.rev_table, v_set)
       USING p_values, v_rev;
    RETURN v_rev;
END;
$$;

-- Creates or edits the text of a criterion section (one per pillar and type).
CREATE FUNCTION save_criterion(p_tcp_pillar_id bigint, p_type_code text, p_main_text text, p_user int)
RETURNS bigint LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    v_tcp  bigint;
    v_d    int;
    v_type smallint;
    v_id   bigint;
BEGIN
    SELECT a.tcp_id INTO v_tcp
    FROM   tcp_pillar a JOIN tcp_pillar_rev r ON r.tcp_pillar_id = a.id AND r.to_version IS NULL
    WHERE  a.id = p_tcp_pillar_id;
    IF v_tcp IS NULL THEN
        RAISE EXCEPTION 'Pillar % is not in the draft', p_tcp_pillar_id;
    END IF;
    v_d := draft_version_no(v_tcp);

    SELECT id INTO v_type FROM criterion_type WHERE code = upper(p_type_code);
    IF v_type IS NULL THEN
        RAISE EXCEPTION 'Unknown criterion type %', p_type_code;
    END IF;

    SELECT id INTO v_id FROM tcp_criterion WHERE tcp_pillar_id = p_tcp_pillar_id AND criterion_type_id = v_type;
    IF v_id IS NULL THEN
        INSERT INTO tcp_criterion (tcp_id, tcp_pillar_id, criterion_type_id, created_in_version, created_by)
        VALUES (v_tcp, p_tcp_pillar_id, v_type, v_d, p_user) RETURNING id INTO v_id;
    END IF;

    IF EXISTS (SELECT 1 FROM tcp_criterion_rev WHERE tcp_criterion_id = v_id AND to_version IS NULL) THEN
        PERFORM update_item('CRITERION', v_id, jsonb_build_object('main_text', p_main_text), p_user);
    ELSE
        INSERT INTO tcp_criterion_rev (tcp_criterion_id, from_version, main_text, created_by)
        VALUES (v_id, v_d, p_main_text, p_user);
    END IF;
    RETURN v_id;
END;
$$;

-- Sets the Good / Medium / Bad rule of a parameter.
CREATE FUNCTION set_rule(p_parameter_id bigint, p_rating_code text, p_operator_code text,
                         p_value numeric DEFAULT NULL, p_value_to numeric DEFAULT NULL,
                         p_text varchar DEFAULT NULL, p_comment varchar DEFAULT NULL, p_user int DEFAULT NULL)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    v_rating smallint;
    v_op     comparison_operator;
    v_dtype  smallint;
    v_cur    bigint;
    v_rev    bigint;
BEGIN
    SELECT id INTO v_rating FROM rating_level WHERE code = upper(p_rating_code);
    SELECT * INTO v_op FROM comparison_operator WHERE code = upper(p_operator_code);
    IF v_rating IS NULL OR v_op.id IS NULL THEN
        RAISE EXCEPTION 'Unknown rating % or operator %', p_rating_code, p_operator_code;
    END IF;

    SELECT r.id, a.data_type_id INTO v_cur, v_dtype
    FROM   tcp_parameter_rev r JOIN attribute a ON a.id = r.attribute_id
    WHERE  r.tcp_parameter_id = p_parameter_id AND r.to_version IS NULL;
    IF v_cur IS NULL THEN
        RAISE EXCEPTION 'Parameter % is not in the draft', p_parameter_id;
    END IF;

    -- early validation (repeated on publish)
    IF (v_dtype = 1 AND NOT v_op.for_numeric) OR (v_dtype = 2 AND NOT v_op.for_text)
       OR (v_dtype = 3 AND NOT v_op.for_presence) THEN
        RAISE EXCEPTION 'Operator % does not apply to this attribute''s data type', v_op.code;
    END IF;
    IF (v_op.value_count >= 1 AND p_value IS NULL AND p_text IS NULL)
       OR (v_op.value_count = 2 AND p_value_to IS NULL) THEN
        RAISE EXCEPTION 'Operator % needs % value(s)', v_op.code, v_op.value_count;
    END IF;

    -- unchanged rule -> nothing to do
    IF EXISTS (SELECT 1 FROM tcp_parameter_rule
               WHERE tcp_parameter_rev_id = v_cur AND rating_level_id = v_rating AND operator_id = v_op.id
                 AND numeric_value IS NOT DISTINCT FROM p_value AND numeric_value_to IS NOT DISTINCT FROM p_value_to
                 AND text_value IS NOT DISTINCT FROM p_text AND comment IS NOT DISTINCT FROM p_comment) THEN
        RETURN;
    END IF;

    v_rev := ensure_draft_rev('PARAMETER', p_parameter_id, p_user);
    INSERT INTO tcp_parameter_rule (tcp_parameter_rev_id, rating_level_id, operator_id,
                                    numeric_value, numeric_value_to, text_value, comment)
    VALUES (v_rev, v_rating, v_op.id, p_value, p_value_to, p_text, p_comment)
    ON CONFLICT (tcp_parameter_rev_id, rating_level_id) DO UPDATE
       SET operator_id = EXCLUDED.operator_id, numeric_value = EXCLUDED.numeric_value,
           numeric_value_to = EXCLUDED.numeric_value_to, text_value = EXCLUDED.text_value,
           comment = EXCLUDED.comment;
END;
$$;

CREATE FUNCTION clear_rule(p_parameter_id bigint, p_rating_code text, p_user int)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE v_rev bigint;
BEGIN
    IF NOT EXISTS (SELECT 1 FROM tcp_parameter_rev r
                   JOIN tcp_parameter_rule ru ON ru.tcp_parameter_rev_id = r.id
                   JOIN rating_level rl ON rl.id = ru.rating_level_id AND rl.code = upper(p_rating_code)
                   WHERE r.tcp_parameter_id = p_parameter_id AND r.to_version IS NULL) THEN
        RETURN;
    END IF;
    v_rev := ensure_draft_rev('PARAMETER', p_parameter_id, p_user);
    DELETE FROM tcp_parameter_rule ru USING rating_level rl
    WHERE  ru.tcp_parameter_rev_id = v_rev AND rl.id = ru.rating_level_id AND rl.code = upper(p_rating_code);
END;
$$;

-- Removes a pillar (with its criteria and parameters), a criterion (with its
-- parameters) or a parameter from the Draft. History is kept.
CREATE FUNCTION remove_item(p_level text, p_item_id bigint, p_user int)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    v_tcp     bigint;
    v_d       int;
    v_pillars bigint[] := '{}';
    v_crits   bigint[] := '{}';
    v_params  bigint[] := '{}';
BEGIN
    CASE upper(p_level)
        WHEN 'PILLAR' THEN
            SELECT tcp_id INTO v_tcp FROM tcp_pillar WHERE id = p_item_id;
            v_pillars := ARRAY[p_item_id];
            SELECT COALESCE(array_agg(id), '{}') INTO v_crits FROM tcp_criterion WHERE tcp_pillar_id = p_item_id;
        WHEN 'CRITERION' THEN
            SELECT tcp_id INTO v_tcp FROM tcp_criterion WHERE id = p_item_id;
            v_crits := ARRAY[p_item_id];
        WHEN 'PARAMETER' THEN
            SELECT tcp_id INTO v_tcp FROM tcp_parameter WHERE id = p_item_id;
            v_params := ARRAY[p_item_id];
        ELSE
            RAISE EXCEPTION 'Unknown item level %', p_level;
    END CASE;
    IF v_tcp IS NULL THEN
        RAISE EXCEPTION '% % does not exist', initcap(p_level), p_item_id;
    END IF;
    v_d := draft_version_no(v_tcp);

    IF upper(p_level) <> 'PARAMETER' THEN
        SELECT COALESCE(array_agg(id), '{}') INTO v_params FROM tcp_parameter WHERE tcp_criterion_id = ANY (v_crits);
    END IF;

    -- revisions created in this draft disappear; older ones are closed at D-1
    DELETE FROM tcp_parameter_rev WHERE tcp_parameter_id = ANY (v_params) AND to_version IS NULL AND from_version = v_d;
    UPDATE tcp_parameter_rev SET to_version = v_d - 1 WHERE tcp_parameter_id = ANY (v_params) AND to_version IS NULL;
    DELETE FROM tcp_criterion_rev WHERE tcp_criterion_id = ANY (v_crits) AND to_version IS NULL AND from_version = v_d;
    UPDATE tcp_criterion_rev SET to_version = v_d - 1 WHERE tcp_criterion_id = ANY (v_crits) AND to_version IS NULL;
    DELETE FROM tcp_pillar_rev WHERE tcp_pillar_id = ANY (v_pillars) AND to_version IS NULL AND from_version = v_d;
    UPDATE tcp_pillar_rev SET to_version = v_d - 1 WHERE tcp_pillar_id = ANY (v_pillars) AND to_version IS NULL;

    -- anchors born in this draft with no revision left are dropped
    DELETE FROM tcp_parameter a WHERE a.id = ANY (v_params) AND a.created_in_version = v_d
       AND NOT EXISTS (SELECT 1 FROM tcp_parameter_rev r WHERE r.tcp_parameter_id = a.id);
    DELETE FROM tcp_criterion a WHERE a.id = ANY (v_crits) AND a.created_in_version = v_d
       AND NOT EXISTS (SELECT 1 FROM tcp_criterion_rev r WHERE r.tcp_criterion_id = a.id);
    DELETE FROM tcp_pillar a WHERE a.id = ANY (v_pillars) AND a.created_in_version = v_d
       AND NOT EXISTS (SELECT 1 FROM tcp_pillar_rev r WHERE r.tcp_pillar_id = a.id);
END;
$$;

CREATE FUNCTION set_impact_weight(p_tcp_id bigint, p_impact_code text, p_weight numeric, p_user int)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    v_d    int := draft_version_no(p_tcp_id);
    v_lvl  smallint;
    v_id   bigint;
    v_from int;
    v_w    numeric;
BEGIN
    SELECT id INTO v_lvl FROM impact_level WHERE code = upper(p_impact_code);
    IF v_lvl IS NULL THEN
        RAISE EXCEPTION 'Unknown impact level %', p_impact_code;
    END IF;
    SELECT id, from_version, weight INTO v_id, v_from, v_w
    FROM   tcp_impact_weight WHERE tcp_id = p_tcp_id AND impact_level_id = v_lvl AND to_version IS NULL;
    IF v_id IS NOT NULL AND v_w = p_weight THEN
        RETURN;
    ELSIF v_id IS NOT NULL AND v_from = v_d THEN
        UPDATE tcp_impact_weight SET weight = p_weight WHERE id = v_id;
        RETURN;
    ELSIF v_id IS NOT NULL THEN
        UPDATE tcp_impact_weight SET to_version = v_d - 1 WHERE id = v_id;
    END IF;
    INSERT INTO tcp_impact_weight (tcp_id, impact_level_id, weight, from_version, created_by)
    VALUES (p_tcp_id, v_lvl, p_weight, v_d, p_user);
END;
$$;

CREATE FUNCTION add_tr_number(p_tcp_id bigint, p_tr_number varchar, p_user int)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE v_d int := draft_version_no(p_tcp_id);
BEGIN
    IF NOT EXISTS (SELECT 1 FROM tcp_tr_number WHERE tcp_id = p_tcp_id AND tr_number = p_tr_number AND to_version IS NULL) THEN
        INSERT INTO tcp_tr_number (tcp_id, tr_number, from_version, created_by) VALUES (p_tcp_id, p_tr_number, v_d, p_user);
    END IF;
END;
$$;

CREATE FUNCTION remove_tr_number(p_tcp_id bigint, p_tr_number varchar, p_user int)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE v_d int := draft_version_no(p_tcp_id);
BEGIN
    DELETE FROM tcp_tr_number WHERE tcp_id = p_tcp_id AND tr_number = p_tr_number AND to_version IS NULL AND from_version = v_d;
    UPDATE tcp_tr_number SET to_version = v_d - 1 WHERE tcp_id = p_tcp_id AND tr_number = p_tr_number AND to_version IS NULL;
END;
$$;

-- Edits the Draft's header and reason fields, e.g. {"stage_id": 4, "reason_for_edit": "..."}
CREATE FUNCTION update_header(p_tcp_id bigint, p_values jsonb, p_user int)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    v_allowed text[] := ARRAY['modality_id', 'therapeutic_area_id', 'moa', 'stage_id',
                              'edit_type_id', 'reason_for_edit', 'comments'];
    v_bad text;
    v_set text;
BEGIN
    PERFORM draft_version_no(p_tcp_id);
    SELECT string_agg(k, ', ') INTO v_bad FROM jsonb_object_keys(p_values) k WHERE k <> ALL (v_allowed);
    IF v_bad IS NOT NULL THEN
        RAISE EXCEPTION 'Field(s) % cannot be edited on the header', v_bad;
    END IF;
    SELECT string_agg(quote_ident(k), ', ') INTO v_set FROM jsonb_object_keys(p_values) k;
    EXECUTE format('UPDATE tcp_version t SET (%1$s) = (SELECT %1$s FROM jsonb_populate_record(t, $1))
                    WHERE t.tcp_id = $2 AND t.status_id = 1', v_set)
       USING p_values, p_tcp_id;
END;
$$;

/* =============================================================================
   9. LIFECYCLE API
   ============================================================================= */

-- New TCP for a target: creates version 1 as a Draft with default impact weights.
CREATE FUNCTION create_tcp(p_target_research_id bigint, p_name varchar, p_user int, p_stage_id int DEFAULT NULL)
RETURNS bigint LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE v_tcp bigint;
BEGIN
    INSERT INTO tcp (target_research_id, name, created_by)
    VALUES (p_target_research_id, p_name, p_user) RETURNING id INTO v_tcp;

    INSERT INTO tcp_version (tcp_id, version_no, status_id, modality_id, therapeutic_area_id, moa,
                             stage_id, edit_type_id, created_by)
    SELECT v_tcp, 1, 1, tr.modality_id, tr.therapeutic_area_id, tr.moa, p_stage_id, 1, p_user
    FROM   target_research tr WHERE tr.id = p_target_research_id;

    INSERT INTO tcp_impact_weight (tcp_id, impact_level_id, weight, from_version, created_by)
    SELECT v_tcp, id, default_weight, 1, p_user FROM impact_level WHERE is_active;
    RETURN v_tcp;
END;
$$;

-- Opens the next version as a Draft. Nothing is copied: the draft sees every
-- current revision until something is edited.
CREATE FUNCTION start_new_version(p_tcp_id bigint, p_user int,
                                  p_edit_type_code text DEFAULT 'SCIENTIFIC_UPDATE',
                                  p_reason varchar DEFAULT NULL)
RETURNS int LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE v_last tcp_version; v_next int;
BEGIN
    IF EXISTS (SELECT 1 FROM tcp_version WHERE tcp_id = p_tcp_id AND status_id IN (1, 2)) THEN
        RAISE EXCEPTION 'TCP % already has a Draft or In Review version', p_tcp_id;
    END IF;
    SELECT * INTO v_last FROM tcp_version WHERE tcp_id = p_tcp_id ORDER BY version_no DESC LIMIT 1;
    IF v_last.id IS NULL THEN
        RAISE EXCEPTION 'TCP % has no versions', p_tcp_id;
    END IF;
    v_next := v_last.version_no + 1;

    INSERT INTO tcp_version (tcp_id, version_no, status_id, modality_id, therapeutic_area_id, moa, stage_id,
                             edit_type_id, reason_for_edit, created_by)
    VALUES (p_tcp_id, v_next, 1, v_last.modality_id, v_last.therapeutic_area_id, v_last.moa, v_last.stage_id,
            (SELECT id FROM edit_type WHERE code = upper(p_edit_type_code)), p_reason, p_user);
    RETURN v_next;
END;
$$;

-- Throws away the open Draft and everything changed in it.
CREATE FUNCTION discard_draft(p_tcp_id bigint)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE v_d int := draft_version_no(p_tcp_id);
BEGIN
    DELETE FROM tcp_parameter_rev r USING tcp_parameter a
    WHERE  a.id = r.tcp_parameter_id AND a.tcp_id = p_tcp_id AND r.from_version = v_d;
    UPDATE tcp_parameter_rev r SET to_version = NULL FROM tcp_parameter a
    WHERE  a.id = r.tcp_parameter_id AND a.tcp_id = p_tcp_id AND r.to_version = v_d - 1;

    DELETE FROM tcp_criterion_rev r USING tcp_criterion a
    WHERE  a.id = r.tcp_criterion_id AND a.tcp_id = p_tcp_id AND r.from_version = v_d;
    UPDATE tcp_criterion_rev r SET to_version = NULL FROM tcp_criterion a
    WHERE  a.id = r.tcp_criterion_id AND a.tcp_id = p_tcp_id AND r.to_version = v_d - 1;

    DELETE FROM tcp_pillar_rev r USING tcp_pillar a
    WHERE  a.id = r.tcp_pillar_id AND a.tcp_id = p_tcp_id AND r.from_version = v_d;
    UPDATE tcp_pillar_rev r SET to_version = NULL FROM tcp_pillar a
    WHERE  a.id = r.tcp_pillar_id AND a.tcp_id = p_tcp_id AND r.to_version = v_d - 1;

    DELETE FROM tcp_impact_weight WHERE tcp_id = p_tcp_id AND from_version = v_d;
    UPDATE tcp_impact_weight SET to_version = NULL WHERE tcp_id = p_tcp_id AND to_version = v_d - 1;
    DELETE FROM tcp_tr_number WHERE tcp_id = p_tcp_id AND from_version = v_d;
    UPDATE tcp_tr_number SET to_version = NULL WHERE tcp_id = p_tcp_id AND to_version = v_d - 1;

    DELETE FROM tcp_parameter WHERE tcp_id = p_tcp_id AND created_in_version = v_d;
    DELETE FROM tcp_criterion WHERE tcp_id = p_tcp_id AND created_in_version = v_d;
    DELETE FROM tcp_pillar    WHERE tcp_id = p_tcp_id AND created_in_version = v_d;
    DELETE FROM tcp_version   WHERE tcp_id = p_tcp_id AND version_no = v_d;
END;
$$;

CREATE FUNCTION submit_version(p_tcp_id bigint, p_user int)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
BEGIN
    UPDATE tcp_version SET status_id = 2, submitted_by = p_user, submitted_on = now()
    WHERE  tcp_id = p_tcp_id AND status_id = 1;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'TCP % has no Draft to submit', p_tcp_id;
    END IF;
END;
$$;

CREATE FUNCTION reject_version(p_tcp_id bigint, p_user int, p_comment varchar DEFAULT NULL)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
BEGIN
    UPDATE tcp_version
    SET    status_id = 1, submitted_by = NULL, submitted_on = NULL,
           comments = CONCAT_WS(E'\n', comments, 'Rejected: ' || p_comment)
    WHERE  tcp_id = p_tcp_id AND status_id = 2;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'TCP % has no version In Review', p_tcp_id;
    END IF;
END;
$$;

/* =============================================================================
   10. READ AND COMPARE
   ============================================================================= */

-- Every item of a TCP as it was in one version, with a comparable jsonb document.
CREATE FUNCTION items_at(p_tcp_id bigint, p_version_no int)
RETURNS TABLE (item_type text, item_key text, rev_id bigint, sort_key text, item_path text, doc jsonb)
LANGUAGE sql STABLE
SET search_path = tcp, public AS $$
    -- header: all tcp_version columns except identity, workflow and reason fields
    SELECT 'HEADER', v.tcp_id::text, v.id, '0', 'TCP header',
           to_jsonb(v) - ARRAY['id', 'tcp_id', 'version_no', 'status_id', 'edit_type_id', 'reason_for_edit',
                               'comments', 'snapshot', 'snapshot_hash', 'created_by', 'created_on',
                               'submitted_by', 'submitted_on', 'published_by', 'published_on']
    FROM   tcp_version v
    WHERE  v.tcp_id = p_tcp_id AND v.version_no = p_version_no

    UNION ALL
    SELECT 'IMPACT_WEIGHT', il.code, w.id, '1|' || il.sort_order, 'Impact weight / ' || il.label,
           jsonb_build_object('weight', w.weight)
    FROM   tcp_impact_weight w JOIN impact_level il ON il.id = w.impact_level_id
    WHERE  w.tcp_id = p_tcp_id AND w.valid_range @> p_version_no

    UNION ALL
    SELECT 'TR_NUMBER', t.tr_number, t.id, '2|' || t.tr_number, 'TR number / ' || t.tr_number,
           jsonb_build_object('tr_number', t.tr_number)
    FROM   tcp_tr_number t
    WHERE  t.tcp_id = p_tcp_id AND t.valid_range @> p_version_no

    UNION ALL
    SELECT 'PILLAR', a.id::text, r.id, format('3|%s|%s', lpad(r.sequence::text, 6, '0'), a.id), p.name,
           _doc(to_jsonb(r))
    FROM   tcp_pillar a
    JOIN   tcp_pillar_rev r ON r.tcp_pillar_id = a.id AND r.valid_range @> p_version_no
    JOIN   pillar p ON p.id = r.pillar_id
    WHERE  a.tcp_id = p_tcp_id

    UNION ALL
    SELECT 'CRITERION', c.id::text, cr.id,
           format('3|%s|%s|%s', lpad(pr.sequence::text, 6, '0'), pa.id, ct.sort_order),
           p.name || ' / ' || ct.label,
           _doc(to_jsonb(cr))
    FROM   tcp_criterion c
    JOIN   tcp_criterion_rev cr ON cr.tcp_criterion_id = c.id AND cr.valid_range @> p_version_no
    JOIN   criterion_type ct ON ct.id = c.criterion_type_id
    JOIN   tcp_pillar pa ON pa.id = c.tcp_pillar_id
    LEFT JOIN tcp_pillar_rev pr ON pr.tcp_pillar_id = pa.id AND pr.valid_range @> p_version_no
    LEFT JOIN pillar p ON p.id = pr.pillar_id
    WHERE  c.tcp_id = p_tcp_id

    UNION ALL
    SELECT 'PARAMETER', q.id::text, qr.id,
           format('3|%s|%s|%s|%s|%s', lpad(pr.sequence::text, 6, '0'), pa.id, ct.sort_order,
                  lpad(qr.sequence::text, 6, '0'), q.id),
           p.name || ' / ' || ct.label || ' / ' || at.name,
           _doc(to_jsonb(qr)) || COALESCE(ru.rules, '{}'::jsonb)
    FROM   tcp_parameter q
    JOIN   tcp_parameter_rev qr ON qr.tcp_parameter_id = q.id AND qr.valid_range @> p_version_no
    JOIN   attribute at ON at.id = qr.attribute_id
    JOIN   tcp_criterion c ON c.id = q.tcp_criterion_id
    JOIN   criterion_type ct ON ct.id = c.criterion_type_id
    JOIN   tcp_pillar pa ON pa.id = c.tcp_pillar_id
    LEFT JOIN tcp_pillar_rev pr ON pr.tcp_pillar_id = pa.id AND pr.valid_range @> p_version_no
    LEFT JOIN pillar p ON p.id = pr.pillar_id
    LEFT JOIN LATERAL (
        SELECT jsonb_object_agg('rule_' || lower(rl.code), rule_condition(x))
               || COALESCE(jsonb_object_agg('rule_' || lower(rl.code) || '_comment', x.comment)
                           FILTER (WHERE x.comment IS NOT NULL), '{}'::jsonb) AS rules
        FROM   tcp_parameter_rule x JOIN rating_level rl ON rl.id = x.rating_level_id
        WHERE  x.tcp_parameter_rev_id = qr.id
    ) ru ON true
    WHERE  q.tcp_id = p_tcp_id;
$$;

-- Field-level differences between any two versions of a TCP.
-- Use p_from_version = 0 to list everything in p_to_version as Added.
CREATE FUNCTION compare_versions(p_tcp_id bigint, p_from_version int, p_to_version int)
RETURNS TABLE (item_type text, item_key text, item_path text, field_name text,
               old_value text, new_value text, change_type text)
LANGUAGE sql STABLE
SET search_path = tcp, public AS $$
    WITH a AS (SELECT * FROM items_at(p_tcp_id, p_from_version)),
         b AS (SELECT * FROM items_at(p_tcp_id, p_to_version)),
         j AS (
            SELECT COALESCE(b.item_type, a.item_type) AS item_type,
                   COALESCE(b.item_key,  a.item_key)  AS item_key,
                   COALESCE(b.item_path, a.item_path) AS item_path,
                   COALESCE(b.sort_key,  a.sort_key)  AS sort_key,
                   a.doc AS old_doc, b.doc AS new_doc,
                   CASE WHEN a.item_key IS NULL THEN 'ADDED'
                        WHEN b.item_key IS NULL THEN 'REMOVED'
                        ELSE 'MODIFIED' END AS change_type
            FROM   a FULL JOIN b ON b.item_type = a.item_type AND b.item_key = a.item_key
            WHERE  a.rev_id IS DISTINCT FROM b.rev_id          -- same revision = unchanged, skipped
         )
    SELECT j.item_type, j.item_key, j.item_path,
           regexp_replace(k.key, '_id$', '')       AS field_name,
           label_of(k.key, j.old_doc ->> k.key)    AS old_value,
           label_of(k.key, j.new_doc ->> k.key)    AS new_value,
           j.change_type
    FROM   j
    CROSS JOIN LATERAL jsonb_object_keys(COALESCE(j.old_doc, '{}'::jsonb) || COALESCE(j.new_doc, '{}'::jsonb)) AS k(key)
    WHERE  (j.old_doc ->> k.key) IS DISTINCT FROM (j.new_doc ->> k.key)
    ORDER BY j.sort_key, j.item_type, k.key;
$$;

-- The matrix of one version as the form shows it: one row per parameter
-- (criteria without parameters and pillars without criteria appear once).
CREATE FUNCTION matrix_at(p_tcp_id bigint, p_version_no int)
RETURNS TABLE (pillar text, weight numeric, design_principle_category text, key_design_principle text,
               expected_completion text, send_to_control_tower boolean, criterion_type text, criterion_text text,
               attribute text, unit text, impact text, good text, medium text, bad text,
               tcp_pillar_id bigint, tcp_criterion_id bigint, tcp_parameter_id bigint)
LANGUAGE sql STABLE
SET search_path = tcp, public AS $$
    SELECT p.name, trim_scale(pr.weight), pr.design_principle_category, pr.key_design_principle,
           ec.name, pr.send_to_control_tower, crit.type_label, crit.main_text,
           par.attribute, par.unit, par.impact, par.good, par.medium, par.bad,
           pa.id, crit.id, par.id
    FROM   tcp_pillar pa
    JOIN   tcp_pillar_rev pr ON pr.tcp_pillar_id = pa.id AND pr.valid_range @> p_version_no
    JOIN   pillar p ON p.id = pr.pillar_id
    LEFT JOIN expected_completion ec ON ec.id = pr.expected_completion_id
    LEFT JOIN LATERAL (
        SELECT c.id, ct.label AS type_label, ct.sort_order, cr.main_text
        FROM   tcp_criterion c
        JOIN   tcp_criterion_rev cr ON cr.tcp_criterion_id = c.id AND cr.valid_range @> p_version_no
        JOIN   criterion_type ct ON ct.id = c.criterion_type_id
        WHERE  c.tcp_pillar_id = pa.id
    ) crit ON true
    LEFT JOIN LATERAL (
        SELECT q.id, at.name AS attribute, u.symbol AS unit, il.label AS impact, qr.sequence,
               max(rule_condition(x)) FILTER (WHERE rl.code = 'GOOD')   AS good,
               max(rule_condition(x)) FILTER (WHERE rl.code = 'MEDIUM') AS medium,
               max(rule_condition(x)) FILTER (WHERE rl.code = 'BAD')    AS bad
        FROM   tcp_parameter q
        JOIN   tcp_parameter_rev qr ON qr.tcp_parameter_id = q.id AND qr.valid_range @> p_version_no
        JOIN   attribute at ON at.id = qr.attribute_id
        JOIN   impact_level il ON il.id = qr.impact_level_id
        LEFT JOIN unit u ON u.id = qr.unit_id
        LEFT JOIN tcp_parameter_rule x ON x.tcp_parameter_rev_id = qr.id
        LEFT JOIN rating_level rl ON rl.id = x.rating_level_id
        WHERE  q.tcp_criterion_id = crit.id
        GROUP BY q.id, at.name, u.symbol, il.label, qr.sequence
    ) par ON true
    WHERE  pa.tcp_id = p_tcp_id
    ORDER BY pr.sequence, pa.id, crit.sort_order, par.sequence, par.id;
$$;

-- Validates and publishes the open version, then writes its change log and snapshot.
CREATE FUNCTION publish_version(p_tcp_id bigint, p_user int)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    v_id    bigint;
    v_d     int;
    v_prev  int;
    v_total numeric;
    v_msg   text;
BEGIN
    SELECT id, version_no INTO v_id, v_d FROM tcp_version WHERE tcp_id = p_tcp_id AND status_id IN (1, 2);
    IF v_id IS NULL THEN
        RAISE EXCEPTION 'TCP % has no Draft or In Review version to publish', p_tcp_id;
    END IF;

    -- 1. pillar weights total 100
    SELECT sum(r.weight) INTO v_total
    FROM   tcp_pillar a JOIN tcp_pillar_rev r ON r.tcp_pillar_id = a.id AND r.valid_range @> v_d
    WHERE  a.tcp_id = p_tcp_id;
    IF COALESCE(v_total, 0) <> 100 THEN
        RAISE EXCEPTION 'Pillar weights must total 100 (currently %)', COALESCE(trim_scale(v_total), 0);
    END IF;

    -- 2. a pillar appears once
    SELECT string_agg(DISTINCT p.name, ', ') INTO v_msg
    FROM   (SELECT r.pillar_id FROM tcp_pillar a
            JOIN tcp_pillar_rev r ON r.tcp_pillar_id = a.id AND r.valid_range @> v_d
            WHERE a.tcp_id = p_tcp_id GROUP BY r.pillar_id HAVING count(*) > 1) d
    JOIN   pillar p ON p.id = d.pillar_id;
    IF v_msg IS NOT NULL THEN
        RAISE EXCEPTION 'Pillar(s) used more than once: %', v_msg;
    END IF;

    -- 3. an attribute appears once per criterion section
    SELECT string_agg(DISTINCT at.name, ', ') INTO v_msg
    FROM   (SELECT q.tcp_criterion_id, r.attribute_id FROM tcp_parameter q
            JOIN tcp_parameter_rev r ON r.tcp_parameter_id = q.id AND r.valid_range @> v_d
            WHERE q.tcp_id = p_tcp_id GROUP BY 1, 2 HAVING count(*) > 1) d
    JOIN   attribute at ON at.id = d.attribute_id;
    IF v_msg IS NOT NULL THEN
        RAISE EXCEPTION 'Attribute(s) repeated in one section: %', v_msg;
    END IF;

    -- 4. every Go/No-Go parameter has a Bad rule
    SELECT string_agg(at.name, ', ') INTO v_msg
    FROM   tcp_parameter q
    JOIN   tcp_parameter_rev r ON r.tcp_parameter_id = q.id AND r.valid_range @> v_d
    JOIN   attribute at ON at.id = r.attribute_id
    JOIN   tcp_criterion c ON c.id = q.tcp_criterion_id
    JOIN   criterion_type ct ON ct.id = c.criterion_type_id AND ct.is_go_no_go
    WHERE  q.tcp_id = p_tcp_id
      AND  NOT EXISTS (SELECT 1 FROM tcp_parameter_rule x WHERE x.tcp_parameter_rev_id = r.id AND x.rating_level_id = 3);
    IF v_msg IS NOT NULL THEN
        RAISE EXCEPTION 'Go/No-Go parameter(s) without a Bad rule: %', v_msg;
    END IF;

    -- 5. operators fit the attribute data type
    SELECT string_agg(DISTINCT at.name, ', ') INTO v_msg
    FROM   tcp_parameter q
    JOIN   tcp_parameter_rev r ON r.tcp_parameter_id = q.id AND r.valid_range @> v_d
    JOIN   attribute at ON at.id = r.attribute_id
    JOIN   tcp_parameter_rule x ON x.tcp_parameter_rev_id = r.id
    JOIN   comparison_operator op ON op.id = x.operator_id
    WHERE  q.tcp_id = p_tcp_id
      AND  ((at.data_type_id = 1 AND NOT op.for_numeric) OR (at.data_type_id = 2 AND NOT op.for_text)
            OR (at.data_type_id = 3 AND NOT op.for_presence));
    IF v_msg IS NOT NULL THEN
        RAISE EXCEPTION 'Operator does not fit the data type of: %', v_msg;
    END IF;

    -- status changes
    SELECT version_no INTO v_prev FROM tcp_version WHERE tcp_id = p_tcp_id AND status_id = 3;
    UPDATE tcp_version SET status_id = 4 WHERE tcp_id = p_tcp_id AND status_id = 3;
    UPDATE tcp_version SET status_id = 3, published_by = p_user, published_on = now() WHERE id = v_id;
    UPDATE tcp SET current_published_version_no = v_d, updated_by = p_user, updated_on = now() WHERE id = p_tcp_id;

    -- change log against the previously published version (0 = first publish)
    INSERT INTO tcp_change_log (tcp_version_id, item_type_id, item_key, item_path, field_name,
                                old_value, new_value, change_type_id)
    SELECT v_id, it.id, c.item_key, c.item_path, c.field_name, c.old_value, c.new_value, ch.id
    FROM   compare_versions(p_tcp_id, COALESCE(v_prev, 0), v_d) c
    JOIN   item_type it ON it.code = c.item_type
    JOIN   change_type ch ON ch.code = c.change_type;

    -- frozen snapshot + hash
    UPDATE tcp_version
    SET    snapshot = (SELECT jsonb_agg(jsonb_build_object('type', i.item_type, 'key', i.item_key,
                                                           'path', i.item_path, 'values', i.doc)
                                        ORDER BY i.sort_key, i.item_type)
                       FROM items_at(p_tcp_id, v_d) i)
    WHERE  id = v_id;
    UPDATE tcp_version SET snapshot_hash = sha256(convert_to(snapshot::text, 'UTF8')) WHERE id = v_id;
END;
$$;

/* =============================================================================
   11. SCORING
   rating   : first matching rule, Good -> Medium -> Bad
   pillar   : sum(impact weight x rating factor) / sum(impact weight), rated only
   total    : 100 x sum(pillar weight x pillar score) / sum(pillar weight), rated pillars
   outcome  : No-Go if a Go/No-Go parameter is Bad; Incomplete if one is unrated; else Go
   ============================================================================= */
CREATE FUNCTION score_experiment(p_experiment_id bigint)
RETURNS void LANGUAGE plpgsql
SET search_path = tcp, public AS $$
DECLARE
    v_tcp    bigint;
    v_ver    int;
    v_status smallint;
BEGIN
    SELECT v.tcp_id, v.version_no, v.status_id INTO v_tcp, v_ver, v_status
    FROM   experiment e JOIN tcp_version v ON v.id = e.tcp_version_id
    WHERE  e.id = p_experiment_id;
    IF v_status IS NULL OR v_status NOT IN (3, 4) THEN
        RAISE EXCEPTION 'Experiments are scored against Published or Superseded versions only';
    END IF;
    IF EXISTS (SELECT 1 FROM experiment_measurement m
               WHERE m.experiment_id = p_experiment_id
                 AND NOT EXISTS (SELECT 1 FROM tcp_parameter q
                                 JOIN tcp_parameter_rev r ON r.tcp_parameter_id = q.id AND r.valid_range @> v_ver
                                 WHERE q.id = m.tcp_parameter_id AND q.tcp_id = v_tcp)) THEN
        RAISE EXCEPTION 'A measurement refers to a parameter that is not in version % of this TCP', v_ver;
    END IF;

    /* 1. rate each measurement against the revision valid in the pinned version */
    UPDATE experiment_measurement m
    SET    tcp_parameter_rev_id = r.id,
           rating_level_id = (
               SELECT x.rating_level_id
               FROM   tcp_parameter_rule x
               JOIN   comparison_operator op ON op.id = x.operator_id
               JOIN   rating_level rl ON rl.id = x.rating_level_id
               WHERE  x.tcp_parameter_rev_id = r.id
                 AND  COALESCE(CASE op.code
                        WHEN 'LT'         THEN m.numeric_value <  x.numeric_value
                        WHEN 'LTE'        THEN m.numeric_value <= x.numeric_value
                        WHEN 'GT'         THEN m.numeric_value >  x.numeric_value
                        WHEN 'GTE'        THEN m.numeric_value >= x.numeric_value
                        WHEN 'EQ'         THEN CASE WHEN at.data_type_id = 2 THEN m.text_value = x.text_value
                                                    ELSE m.numeric_value = x.numeric_value END
                        WHEN 'NEQ'        THEN CASE WHEN at.data_type_id = 2 THEN m.text_value <> x.text_value
                                                    ELSE m.numeric_value <> x.numeric_value END
                        WHEN 'BETWEEN'    THEN m.numeric_value BETWEEN x.numeric_value AND x.numeric_value_to
                        WHEN 'OUTSIDE'    THEN m.numeric_value < x.numeric_value OR m.numeric_value > x.numeric_value_to
                        WHEN 'CONTAINS'   THEN strpos(m.text_value, x.text_value) > 0
                        WHEN 'EXISTS'     THEN m.is_present
                        WHEN 'NOT_EXISTS' THEN NOT m.is_present
                      END, false)
               ORDER BY rl.evaluation_order
               LIMIT 1)
    FROM   tcp_parameter_rev r
    JOIN   attribute at ON at.id = r.attribute_id
    WHERE  m.experiment_id = p_experiment_id
      AND  r.tcp_parameter_id = m.tcp_parameter_id
      AND  r.valid_range @> v_ver;

    /* 2. pillar scores */
    DELETE FROM experiment_pillar_score WHERE experiment_id = p_experiment_id;
    INSERT INTO experiment_pillar_score (experiment_id, tcp_pillar_id, score, rated_count, total_count)
    SELECT p_experiment_id, pa.id,
           sum(w.weight * rl.score_factor) FILTER (WHERE m.rating_level_id IS NOT NULL)
             / NULLIF(sum(w.weight) FILTER (WHERE m.rating_level_id IS NOT NULL), 0),
           count(m.rating_level_id),
           count(q.id)
    FROM   tcp_pillar pa
    JOIN   tcp_pillar_rev    pr ON pr.tcp_pillar_id = pa.id AND pr.valid_range @> v_ver
    JOIN   tcp_criterion     c  ON c.tcp_pillar_id = pa.id
    JOIN   tcp_criterion_rev cr ON cr.tcp_criterion_id = c.id AND cr.valid_range @> v_ver
    JOIN   tcp_parameter     q  ON q.tcp_criterion_id = c.id
    JOIN   tcp_parameter_rev qr ON qr.tcp_parameter_id = q.id AND qr.valid_range @> v_ver
    JOIN   tcp_impact_weight w  ON w.tcp_id = v_tcp AND w.impact_level_id = qr.impact_level_id AND w.valid_range @> v_ver
    LEFT JOIN experiment_measurement m ON m.experiment_id = p_experiment_id AND m.tcp_parameter_id = q.id
    LEFT JOIN rating_level rl ON rl.id = m.rating_level_id
    WHERE  pa.tcp_id = v_tcp
    GROUP BY pa.id;

    /* 3 + 4. total, coverage, outcome */
    UPDATE experiment e
    SET    total_score = s.total_score,
           coverage    = s.coverage,
           outcome_id  = CASE WHEN g.bad > 0 THEN 2 WHEN g.unrated > 0 THEN 3 ELSE 1 END,
           scored_on   = now()
    FROM (
        SELECT 100 * sum(pr.weight * ps.score)
                   / NULLIF(sum(pr.weight) FILTER (WHERE ps.score IS NOT NULL), 0) AS total_score,
               sum(ps.rated_count)::numeric / NULLIF(sum(ps.total_count), 0)      AS coverage
        FROM   experiment_pillar_score ps
        JOIN   tcp_pillar_rev pr ON pr.tcp_pillar_id = ps.tcp_pillar_id AND pr.valid_range @> v_ver
        WHERE  ps.experiment_id = p_experiment_id
    ) s,
    (
        SELECT count(*) FILTER (WHERE m.rating_level_id = 3)  AS bad,
               count(*) FILTER (WHERE m.rating_level_id IS NULL) AS unrated
        FROM   tcp_parameter q
        JOIN   tcp_parameter_rev qr ON qr.tcp_parameter_id = q.id AND qr.valid_range @> v_ver
        JOIN   tcp_criterion c ON c.id = q.tcp_criterion_id
        JOIN   tcp_criterion_rev cr ON cr.tcp_criterion_id = c.id AND cr.valid_range @> v_ver
        JOIN   criterion_type ct ON ct.id = c.criterion_type_id AND ct.is_go_no_go
        LEFT JOIN experiment_measurement m ON m.experiment_id = p_experiment_id AND m.tcp_parameter_id = q.id
        WHERE  q.tcp_id = v_tcp
    ) g
    WHERE  e.id = p_experiment_id;
END;
$$;

/* =============================================================================
   12. VIEWS
   ============================================================================= */

-- Version list with previous stage and number of logged changes
CREATE VIEW v_tcp_version_history AS
SELECT t.id                    AS tcp_id,
       t.name                  AS tcp_name,
       v.version_no,
       vs.label                AS status,
       st.name                 AS stage,
       lag(st.name) OVER (PARTITION BY v.tcp_id ORDER BY v.version_no) AS previous_stage,
       et.label                AS edit_type,
       v.reason_for_edit,
       v.created_on,
       v.published_on,
       (SELECT count(*) FROM tcp_change_log cl WHERE cl.tcp_version_id = v.id) AS logged_changes,
       encode(v.snapshot_hash, 'hex') AS snapshot_sha256
FROM   tcp_version v
JOIN   tcp t ON t.id = v.tcp_id
JOIN   version_status vs ON vs.id = v.status_id
LEFT JOIN tcp_stage st ON st.id = v.stage_id
LEFT JOIN edit_type et ON et.id = v.edit_type_id;

-- Readable change log, newest first
CREATE VIEW v_tcp_change_log AS
SELECT t.id AS tcp_id, t.name AS tcp_name, v.version_no, v.published_on,
       it.label AS item_type, cl.item_key, cl.item_path, cl.field_name,
       cl.old_value, cl.new_value, ct.label AS change_type, cl.comment
FROM   tcp_change_log cl
JOIN   tcp_version v  ON v.id = cl.tcp_version_id
JOIN   tcp t          ON t.id = v.tcp_id
JOIN   item_type it   ON it.id = cl.item_type_id
JOIN   change_type ct ON ct.id = cl.change_type_id;

COMMIT;

/* Quick check after running:
   SELECT count(*) FROM information_schema.tables WHERE table_schema = 'tcp';   -- 36 (34 tables + 2 views)
*/
