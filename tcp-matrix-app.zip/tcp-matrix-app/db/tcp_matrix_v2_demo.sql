/* =============================================================================
   TCP Parameters Matrix v2 - demo walk-through (PostgreSQL)
   -----------------------------------------------------------------------------
   Run AFTER tcp_matrix_v2_postgres.sql, one step at a time: in pgAdmin 4,
   select a step's statements and press F5 (the Data Output pane shows the
   last result of each run).
   Start over:  DROP SCHEMA tcp CASCADE;  then run both scripts again.
   ============================================================================= */
SET search_path = tcp, public;

/* ---- Step 1. A new program (name only, no code) and the attributes used ---- */
INSERT INTO target_research (name, is_existing_program, modality_id, therapeutic_area_id, moa, created_by)
VALUES ('KX-1 inhibitor', false,
        (SELECT id FROM modality WHERE name = 'Small molecule'),
        (SELECT id FROM therapeutic_area WHERE name = 'Oncology'),
        'ATP-competitive kinase inhibitor', 1);

INSERT INTO attribute (name, data_type_id, default_unit_id, is_system) VALUES
    ('Biochemical IC50',          1, (SELECT id FROM unit WHERE symbol = 'nM'),   true),
    ('Selectivity vs off-target', 1, (SELECT id FROM unit WHERE symbol = 'fold'), true),
    ('hERG IC50',                 1, (SELECT id FROM unit WHERE symbol = 'µM'),   true),
    ('Ames mutagenicity signal',  3, NULL,                                         true);

/* ---- Step 2. Create the TCP: version 1 opens as a Draft -------------------- */
SELECT create_tcp((SELECT id FROM target_research WHERE name = 'KX-1 inhibitor'),
                  'KX-1 lead profile', 1,
                  (SELECT id FROM tcp_stage WHERE code = 'LEAD_OPT')) AS tcp_id;

/* ---- Step 3. Fill version 1 through the editing API ------------------------ */
DO $$
DECLARE
    t     bigint := (SELECT id FROM tcp WHERE name = 'KX-1 lead profile');
    pot   bigint;  saf bigint;  crit bigint;  par bigint;
BEGIN
    PERFORM add_tr_number(t, 'TR-2026-014', 1);

    pot := add_item('PILLAR', t, jsonb_build_object(
              'pillar_id', (SELECT id FROM pillar WHERE name = 'Potency'),
              'weight', 40, 'sequence', 1,
              'design_principle_category', 'Target engagement',
              'key_design_principle', 'Does the compound engage KX-1 at therapeutic concentrations?',
              'expected_completion_id', (SELECT id FROM expected_completion WHERE name = 'Before candidate selection')), 1);

    saf := add_item('PILLAR', t, jsonb_build_object(
              'pillar_id', (SELECT id FROM pillar WHERE name = 'Safety'),
              'weight', 60, 'sequence', 2, 'send_to_control_tower', true,
              'design_principle_category', 'Cardiac and genetic safety',
              'key_design_principle', 'Is there an acceptable cardiac and genotoxic safety margin?'), 1);

    -- Potency: key quantitative criteria with two parameters, plus a rationale
    crit := save_criterion(pot, 'QUANT_CANDIDATE', NULL, 1);

    par := add_item('PARAMETER', crit, jsonb_build_object(
              'attribute_id', (SELECT id FROM attribute WHERE name = 'Biochemical IC50'),
              'unit_id', (SELECT id FROM unit WHERE symbol = 'nM'),
              'impact_level_id', (SELECT id FROM impact_level WHERE code = 'HIGH'), 'sequence', 1), 1);
    PERFORM set_rule(par, 'GOOD',   'LT',      10,  NULL, p_user => 1);
    PERFORM set_rule(par, 'MEDIUM', 'BETWEEN', 10,  100,  p_user => 1);
    PERFORM set_rule(par, 'BAD',    'GT',      100, NULL, p_user => 1);

    par := add_item('PARAMETER', crit, jsonb_build_object(
              'attribute_id', (SELECT id FROM attribute WHERE name = 'Selectivity vs off-target'),
              'unit_id', (SELECT id FROM unit WHERE symbol = 'fold'),
              'impact_level_id', (SELECT id FROM impact_level WHERE code = 'MEDIUM'), 'sequence', 2), 1);
    PERFORM set_rule(par, 'GOOD',   'GTE',     100, NULL, p_user => 1);
    PERFORM set_rule(par, 'MEDIUM', 'BETWEEN', 30,  100,  p_user => 1);
    PERFORM set_rule(par, 'BAD',    'LT',      30,  NULL, p_user => 1);

    PERFORM save_criterion(pot, 'RATIONALE',
              'Sub-10 nM potency is needed to reach target coverage at the projected dose.', 1);

    -- Safety: quantitative Go/No-Go
    crit := save_criterion(saf, 'QUANT_GO_NO_GO', NULL, 1);
    par := add_item('PARAMETER', crit, jsonb_build_object(
              'attribute_id', (SELECT id FROM attribute WHERE name = 'hERG IC50'),
              'unit_id', (SELECT id FROM unit WHERE symbol = 'µM'),
              'impact_level_id', (SELECT id FROM impact_level WHERE code = 'HIGH'), 'sequence', 1), 1);
    PERFORM set_rule(par, 'GOOD',   'GT',      30, NULL, p_user => 1);
    PERFORM set_rule(par, 'MEDIUM', 'BETWEEN', 10, 30,   p_user => 1);
    PERFORM set_rule(par, 'BAD',    'LT',      10, NULL, p_user => 1);
END $$;

-- the matrix as the form shows it
SELECT pillar, weight, criterion_type, criterion_text, attribute, unit, impact, good, medium, bad
FROM   matrix_at((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 1);

/* ---- Step 4. Publish version 1 -------------------------------------------- */
SELECT publish_version((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 1);

/* ---- Step 5. Version 2: open a draft (nothing is copied) and edit it ------ */
SELECT start_new_version((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 1,
                         'SCIENTIFIC_UPDATE', 'hERG margin tightened after cardiac review') AS v2;

DO $$
DECLARE
    t    bigint := (SELECT id FROM tcp WHERE name = 'KX-1 lead profile');
    herg bigint;  sel bigint;  crit bigint;  ames bigint;
BEGIN
    SELECT tcp_parameter_id, tcp_criterion_id INTO herg, crit FROM matrix_at(t, 2) WHERE attribute = 'hERG IC50';
    SELECT tcp_parameter_id INTO sel FROM matrix_at(t, 2) WHERE attribute = 'Selectivity vs off-target';

    -- (a) rebalance weights 40/60 -> 50/50
    PERFORM update_item('PILLAR', tcp_pillar_id, '{"weight": 50}', 1)
    FROM (SELECT DISTINCT tcp_pillar_id FROM matrix_at(t, 2)) x;

    -- (b) hERG Good threshold > 30 -> > 40, Medium band widened to 10-40 (no gap)
    PERFORM set_rule(herg, 'GOOD',   'GT',      40, p_user => 1);
    PERFORM set_rule(herg, 'MEDIUM', 'BETWEEN', 10, 40, p_user => 1);

    -- (c) new Go/No-Go presence check
    ames := add_item('PARAMETER', crit, jsonb_build_object(
              'attribute_id', (SELECT id FROM attribute WHERE name = 'Ames mutagenicity signal'),
              'impact_level_id', (SELECT id FROM impact_level WHERE code = 'HIGH'), 'sequence', 2), 1);
    PERFORM set_rule(ames, 'GOOD', 'NOT_EXISTS', p_user => 1);
    PERFORM set_rule(ames, 'BAD',  'EXISTS',     p_user => 1);

    -- (d) drop selectivity
    PERFORM remove_item('PARAMETER', sel, 1);

    -- (e) header: stage moves on, one more TR number
    PERFORM update_header(t, jsonb_build_object('stage_id', (SELECT id FROM tcp_stage WHERE code = 'PRE_PS')), 1);
    PERFORM add_tr_number(t, 'TR-2026-031', 1);

    -- an edit that changes nothing creates no revision
    PERFORM update_item('PILLAR', tcp_pillar_id, '{"weight": 50}', 1)
    FROM (SELECT DISTINCT tcp_pillar_id FROM matrix_at(t, 2)) x;
END $$;

/* ---- Step 6. Compare v1 with v2 (works for any two versions) -------------- */
SELECT item_type, item_path, field_name, old_value, new_value, change_type
FROM   compare_versions((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 1, 2);

/* ---- Step 7. Publish v2 and read the stored change log -------------------- */
SELECT publish_version((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 1);

SELECT version_no, status, stage, previous_stage, edit_type, reason_for_edit, logged_changes
FROM   v_tcp_version_history ORDER BY version_no;

SELECT version_no, item_path, field_name, old_value, new_value, change_type
FROM   v_tcp_change_log WHERE version_no = 2;

/* ---- Step 8. Storage: only changed items got a new revision --------------- */
SELECT 'pillar'    AS item, count(DISTINCT tcp_pillar_id)    AS items, count(*) AS revisions FROM tcp_pillar_rev
UNION ALL
SELECT 'criterion', count(DISTINCT tcp_criterion_id), count(*) FROM tcp_criterion_rev
UNION ALL
SELECT 'parameter', count(DISTINCT tcp_parameter_id), count(*) FROM tcp_parameter_rev;

/* ---- Step 9. A draft that is thrown away ---------------------------------- */
SELECT start_new_version((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 1, 'CORRECTION', 'Trial edit');

SELECT update_item('PILLAR', tcp_pillar_id, '{"weight": 10}', 1)
FROM  (SELECT DISTINCT tcp_pillar_id FROM matrix_at((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 3)
       WHERE pillar = 'Safety') x;

SELECT discard_draft((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'));

-- back to: versions 1 and 2 only, Safety weight 50 still current
SELECT version_no, status FROM v_tcp_version_history ORDER BY version_no;
SELECT DISTINCT pillar, weight FROM matrix_at((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 2);

/* ---- Step 10. Publishing checks ------------------------------------------- */
DO $$
DECLARE t bigint := (SELECT id FROM tcp WHERE name = 'KX-1 lead profile');
BEGIN
    PERFORM start_new_version(t, 1);
    PERFORM update_item('PILLAR', tcp_pillar_id, '{"weight": 70}', 1)
    FROM (SELECT DISTINCT tcp_pillar_id FROM matrix_at(t, 3) WHERE pillar = 'Safety') x;
    BEGIN
        PERFORM publish_version(t, 1);
    EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'Publish refused as expected: %', SQLERRM;   -- see the Messages tab
    END;
    PERFORM discard_draft(t);
END $$;

/* ---- Step 11. Score an experiment pinned to v1 ----------------------------- */
INSERT INTO experiment (tcp_version_id, name, compound_ref, run_date, created_by)
SELECT v.id, 'Batch 12 profiling', 'KX-1-0042', DATE '2026-10-01', 1
FROM   tcp_version v JOIN tcp t ON t.id = v.tcp_id
WHERE  t.name = 'KX-1 lead profile' AND v.version_no = 1;

INSERT INTO experiment_measurement (experiment_id, tcp_parameter_id, numeric_value)
SELECT e.id, m.tcp_parameter_id, x.val
FROM   experiment e
JOIN   matrix_at((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 1) m ON true
JOIN   (VALUES ('Biochemical IC50', 5), ('Selectivity vs off-target', 50), ('hERG IC50', 3)) AS x (attr, val)
       ON x.attr = m.attribute
WHERE  e.name = 'Batch 12 profiling';

SELECT score_experiment((SELECT id FROM experiment WHERE name = 'Batch 12 profiling'));

-- expected: total 32, coverage 1, outcome No-Go (hERG is Bad)
SELECT e.name, trim_scale(e.total_score) AS total_score, trim_scale(e.coverage) AS coverage, o.label AS outcome
FROM   experiment e JOIN experiment_outcome o ON o.id = e.outcome_id;

/* ---- Step 12. History of one item across all versions ---------------------- */
SELECT version_no, field_name, old_value, new_value, change_type
FROM   v_tcp_change_log
WHERE  item_type = 'Parameter'
  AND  item_key = (SELECT tcp_parameter_id::text
                   FROM matrix_at((SELECT id FROM tcp WHERE name = 'KX-1 lead profile'), 2)
                   WHERE attribute = 'hERG IC50')
ORDER BY version_no, field_name;
