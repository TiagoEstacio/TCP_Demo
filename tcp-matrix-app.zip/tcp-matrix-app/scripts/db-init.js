// Creates the database (if missing) and installs the TCP schema.
//   npm run db:init            install the schema
//   npm run db:init -- --demo  install the schema and the demo profile
//   npm run db:init -- --reset drop an existing "tcp" schema first (deletes its data)
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');
const { DATABASE_URL, describeTarget } = require('../lib/db');

const args = process.argv.slice(2);
const withDemo = args.includes('--demo');
const reset = args.includes('--reset');

async function ensureDatabase() {
  const url = new URL(DATABASE_URL);
  const dbName = decodeURIComponent(url.pathname.replace('/', ''));
  url.pathname = '/postgres';
  const admin = new Client({ connectionString: url.toString() });
  await admin.connect();
  const found = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [dbName]);
  if (!found.rowCount) {
    await admin.query(`CREATE DATABASE "${dbName.replace(/"/g, '""')}"`);
    console.log(`Created database ${dbName}.`);
  }
  await admin.end();
}

async function main() {
  console.log(`Database: ${describeTarget()}`);
  await ensureDatabase();

  const client = new Client({ connectionString: DATABASE_URL });
  await client.connect();
  try {
    const { rows } = await client.query(`
      SELECT EXISTS (SELECT 1 FROM information_schema.schemata WHERE schema_name = 'tcp') AS has_schema,
             to_regclass('tcp.tcp_pillar_rev') IS NOT NULL AS is_v2`);
    const { has_schema, is_v2 } = rows[0];

    if (has_schema && !reset) {
      console.log(is_v2
        ? 'The TCP schema is already installed. Nothing to do. (Use --reset to reinstall; this deletes its data.)'
        : 'A "tcp" schema from an older script exists in this database. Run again with --reset to replace it (this deletes its data), or point DATABASE_URL at a new database.');
      process.exitCode = is_v2 ? 0 : 1;
      return;
    }
    if (has_schema && reset) {
      await client.query('DROP SCHEMA tcp CASCADE');
      console.log('Dropped the existing tcp schema.');
    }

    await client.query(fs.readFileSync(path.join(__dirname, '..', 'db', 'tcp_matrix_v2_postgres.sql'), 'utf8'));
    console.log('Installed the TCP schema.');

    if (withDemo) {
      await client.query(fs.readFileSync(path.join(__dirname, '..', 'db', 'tcp_matrix_v2_demo.sql'), 'utf8'));
      console.log('Loaded the demo profile "KX-1 lead profile".');
    }
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error(`Setup failed: ${err.message}`);
  process.exit(1);
});
