const path = require('path');
const express = require('express');
const routes = require('./lib/routes');
const { describeTarget } = require('./lib/db');

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use('/api', routes);
app.use(express.static(path.join(__dirname, 'public')));

const port = Number(process.env.PORT) || 3000;
app.listen(port, () => {
  console.log(`TCP Matrix is running at http://localhost:${port}`);
  console.log(`Database: ${describeTarget()}`);
});
