/* TCP Matrix - front end v2 (no build step, no dependencies).
   Same API and features as v1; new layout: profile sidebar, version track,
   pillar weight strip, pillar outline + detail, threshold bands. */
'use strict';

const $app = document.getElementById('app');
const S = {
  health: null,
  L: null,                  // lookups
  tcps: [],
  tcp: null,                // profile with versions
  viewNo: null,
  matrix: null,
  tab: 'matrix',
  pillarId: null,           // selected pillar (tcp_pillar_id)
  expanded: new Set(),      // parameter rows open for editing
  sheet: false,             // profile details sheet
  search: '',
  draftDiff: null,          // published -> open draft changes
  cmp: { from: null, to: null, rows: null, filter: 'ALL' },
  pending: {},              // rule editors waiting for a value
  loading: true,
};

/* ================================================================ helpers */
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value' || k === 'checked' || k === 'selected' || k === 'disabled') el[k] = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid === null || kid === undefined || kid === false) continue;
    el.append(kid instanceof Node ? kid : document.createTextNode(String(kid)));
  }
  return el;
}

const ICONS = {
  history: ['M3 12a9 9 0 1 0 3-6.7L3 8', 'M3 3v5h5', 'M12 7v5l3 2'],
  up: ['M6 15l6-6 6 6'],
  down: ['M6 9l6 6 6-6'],
  trash: ['M4 7h16', 'M9 7V4h6v3', 'M6 7l1 13h10l1-13'],
  edit: ['M4 20h4L19 9l-4-4L4 16z', 'M13 7l4 4'],
  close: ['M6 6l12 12', 'M18 6L6 18'],
  warn: ['M12 3l10 18H2z', 'M12 10v4', 'M12 17.5v.5'],
  gate: ['M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z', 'M9 12l2 2 4-4'],
  swap: ['M7 7h13', 'M17 4l3 3-3 3', 'M17 17H4', 'M7 14l-3 3 3 3'],
  plus: ['M12 5v14', 'M5 12h14'],
  search: ['M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14z', 'M20 20l-4-4'],
  details: ['M4 6h16', 'M4 12h16', 'M4 18h10'],
  tower: ['M12 21V11', 'M8.5 7.5a5 5 0 0 1 7 0', 'M5.5 4.5a9 9 0 0 1 13 0', 'M12 11a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z'],
  check: ['M5 12l5 5 9-10'],
};
function icon(name) {
  const NS = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(NS, 'svg');
  s.setAttribute('viewBox', '0 0 24 24');
  s.setAttribute('class', 'i');
  s.setAttribute('aria-hidden', 'true');
  for (const d of ICONS[name]) {
    const p = document.createElementNS(NS, 'path');
    p.setAttribute('d', d);
    s.append(p);
  }
  return s;
}

async function api(method, url, body) {
  const res = await fetch('/api' + url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function toast(message, kind = '') {
  const el = h('div', { class: `toast ${kind}` }, message);
  const box = document.getElementById('toasts');
  box.append(el);
  while (box.children.length > 3) box.firstElementChild.remove();
  setTimeout(() => el.remove(), kind === 'error' ? 7000 : 4000);
}

const fmtNum = (v) => (v === null || v === undefined || v === '' ? '' : String(Number(v)));
const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '');
const byId = (list, id) => list.find((x) => String(x.id) === String(id));
const numOrNull = (v) => (v === '' || v === null || v === undefined ? null : Number(v));
const editable = () => S.matrix && S.matrix.header.status_code === 'DRAFT';
const openVersion = () => S.tcp && S.tcp.versions.find((v) => v.status_code === 'DRAFT' || v.status_code === 'IN_REVIEW');
const publishedNo = () => S.tcp && S.tcp.current_published_version_no;
const changedHere = (fromVersion) => S.viewNo > 1 && fromVersion === S.viewNo;

const PILLAR_HUES = ['#2C6E8F', '#6B55C2', '#9A4C8C', '#3F7F86', '#5A6E7C', '#8C6A3C', '#3E5BA9', '#7A5C52'];
const pillarHue = (pillarId) => PILLAR_HUES[Math.abs(Number(pillarId)) % PILLAR_HUES.length];

const OP_SHORT = { LT: '<', LTE: '≤', GT: '>', GTE: '≥', EQ: '=', NEQ: '≠', BETWEEN: 'between',
                   OUTSIDE: 'outside', CONTAINS: 'contains', EXISTS: 'exists', NOT_EXISTS: 'absent' };
const FIELD_LABELS = {
  pillar: 'Pillar', weight: 'Weight', design_principle_category: 'Category',
  key_design_principle: 'Key design principle', expected_completion: 'Expected completion',
  sequence: 'Order', send_to_control_tower: 'Send to Control Tower', comments: 'Comments',
  main_text: 'Text', attribute: 'Attribute', unit: 'Unit', impact_level: 'Impact', notes: 'Notes',
  rule_good: 'Good', rule_medium: 'Medium', rule_bad: 'Bad',
  rule_good_comment: 'Good comment', rule_medium_comment: 'Medium comment', rule_bad_comment: 'Bad comment',
  tr_number: 'TR number', stage: 'Stage', modality: 'Modality', therapeutic_area: 'Therapeutic area',
  moa: 'Mechanism of action',
};
const FIELD_ORDER = ['pillar', 'weight', 'key_design_principle', 'design_principle_category', 'expected_completion',
  'send_to_control_tower', 'comments', 'main_text', 'attribute', 'unit', 'impact_level', 'rule_good', 'rule_good_comment',
  'rule_medium', 'rule_medium_comment', 'rule_bad', 'rule_bad_comment', 'notes', 'sequence',
  'stage', 'modality', 'therapeutic_area', 'moa', 'tr_number'];
const fieldRank = (f) => { const i = FIELD_ORDER.indexOf(f); return i < 0 ? 999 : i; };
const byField = (a, b) => fieldRank(a.field_name) - fieldRank(b.field_name);
const fieldLabel = (f) => FIELD_LABELS[f] || f.replace(/_/g, ' ').replace(/^./, (c) => c.toUpperCase());

function fmtRule(r) {
  if (!r) return null;
  const v = fmtNum(r.value), t = fmtNum(r.value_to);
  switch (r.operator) {
    case 'BETWEEN': return `${v} – ${t}`;
    case 'OUTSIDE': return `outside ${v} – ${t}`;
    case 'EXISTS': return 'present';
    case 'NOT_EXISTS': return 'absent';
    case 'CONTAINS': return `contains “${r.text}”`;
    default: return `${OP_SHORT[r.operator]} ${r.text != null && r.value == null ? `“${r.text}”` : v}`;
  }
}

/* ================================================================ threshold analysis
   Rules are tried Good -> Medium -> Bad, as in scoring. Ratings can only change at
   a threshold value, so testing each threshold and one point in each interval gives
   the exact picture: coloured ranges plus any gaps no rule covers. */
const RATING_ORDER = ['GOOD', 'MEDIUM', 'BAD'];
const RATING_LABEL = { GOOD: 'Good', MEDIUM: 'Medium', BAD: 'Bad' };

function matches(r, v) {
  const a = r.value, b = r.value_to;
  switch (r.operator) {
    case 'LT': return v < a;
    case 'LTE': return v <= a;
    case 'GT': return v > a;
    case 'GTE': return v >= a;
    case 'EQ': return v === a;
    case 'NEQ': return v !== a;
    case 'BETWEEN': return v >= a && v <= b;
    case 'OUTSIDE': return v < a || v > b;
    default: return false;
  }
}
function rateAt(rules, v) {
  for (const code of RATING_ORDER) {
    const r = rules[code];
    if (r && r.value != null && matches(r, v)) return code;
  }
  return null;
}

function analyse(param, attr) {
  const rules = param.rules || {};
  const set = RATING_ORDER.filter((c) => rules[c]);
  const type = attr ? attr.data_type : 'NUMERIC';
  if (!set.length) return { type, empty: true, issues: ['No Good, Medium or Bad rule yet'] };

  if (type === 'PRESENCE') {
    const rate = (present) => RATING_ORDER.find((c) => rules[c] &&
      ((rules[c].operator === 'EXISTS' && present) || (rules[c].operator === 'NOT_EXISTS' && !present))) || null;
    const cats = [true, false].map((present) => {
      const r = rate(present);
      return { label: `${present ? 'Present' : 'Absent'}${r ? `: ${RATING_LABEL[r]}` : ''}`, r };
    });
    return { type, cats, issues: cats.filter((c) => !c.r).map((c) => `“${c.label}” is not rated`) };
  }
  if (type === 'TEXT') {
    return { type, cats: set.map((c) => ({ label: `${RATING_LABEL[c]}: ${fmtRule(rules[c])}`, r: c })), issues: [] };
  }

  const pts = [...new Set(set.flatMap((c) => [rules[c].value, rules[c].value_to])
    .filter((v) => v !== null && v !== undefined && isFinite(v)).map(Number))].sort((a, b) => a - b);
  if (!pts.length) return { type, empty: true, issues: [] };
  const lo = pts[0], hi = pts.at(-1);
  const step = Math.max(Math.abs(hi - lo), Math.abs(hi), 1);
  const pieces = [{ a: -Infinity, b: lo, r: rateAt(rules, lo - step) }];
  pts.forEach((p, i) => {
    pieces.push({ a: p, b: p, point: true, r: rateAt(rules, p) });
    if (i < pts.length - 1) pieces.push({ a: p, b: pts[i + 1], r: rateAt(rules, (p + pts[i + 1]) / 2) });
  });
  pieces.push({ a: hi, b: Infinity, r: rateAt(rules, hi + step) });

  const issues = [];
  pieces.forEach((s, i) => {
    if (s.r) return;
    if (s.point) {
      if (pieces[i - 1] && pieces[i - 1].r && pieces[i + 1] && pieces[i + 1].r) issues.push(`Exactly ${fmtNum(s.a)} is not rated`);
    } else if (s.a === -Infinity) issues.push(`Values below ${fmtNum(s.b)} are not rated`);
    else if (s.b === Infinity) issues.push(`Values above ${fmtNum(s.a)} are not rated`);
    else issues.push(`Values between ${fmtNum(s.a)} and ${fmtNum(s.b)} are not rated`);
  });

  // display domain
  const log = lo > 0 && hi / lo >= 50;
  let dlo, dhi;
  if (log) { dlo = lo / 2.5; dhi = hi * 2.5; }
  else if (lo === hi) { const d = Math.max(Math.abs(lo) * 0.5, 1); dlo = lo - d; dhi = hi + d; }
  else { const pad = (hi - lo) * 0.25; dlo = lo - pad; dhi = hi + pad; if (lo >= 0 && dlo < 0) dlo = 0; }
  const f = (v) => (log ? Math.log10(v) : v);
  const pos = (v) => Math.max(0, Math.min(100, ((f(v) - f(dlo)) / (f(dhi) - f(dlo))) * 100));
  return { type, pieces, pts, pos, log, issues };
}

function band(param, attr) {
  const A = analyse(param, attr);
  if (A.empty) return h('div', { class: 'band band-empty' }, 'No thresholds yet');
  if (A.cats) {
    return h('div', { class: 'band band-cat' },
      A.cats.map((c) => h('span', { class: c.r || 'GAP' }, c.label, c.r ? '' : ': not rated')));
  }
  const bar = h('div', { class: 'band-bar', role: 'img',
    'aria-label': A.pieces.filter((s) => !s.point).map((s) => `${s.r ? s.r.toLowerCase() : 'not rated'} ${s.a === -Infinity ? 'below ' + fmtNum(s.b) : s.b === Infinity ? 'above ' + fmtNum(s.a) : fmtNum(s.a) + ' to ' + fmtNum(s.b)}`).join(', ') });
  A.pieces.forEach((s, i) => {
    if (s.point) {
      const prev = A.pieces[i - 1], next = A.pieces[i + 1];
      if (s.r !== (prev && prev.r) && s.r !== (next && next.r)) {
        bar.append(h('span', { class: `pt ${s.r || 'GAP'}`, style: { left: A.pos(s.a) + '%' } }));
      }
      return;
    }
    const l = s.a === -Infinity ? 0 : A.pos(s.a);
    const r = s.b === Infinity ? 100 : A.pos(s.b);
    if (r - l <= 0) return;
    bar.append(h('span', { class: s.r || 'GAP', style: { left: l + '%', width: (r - l) + '%' } }));
  });
  const ticks = h('div', { class: 'band-ticks', 'aria-hidden': 'true' });
  let lastPos = -100;
  A.pts.forEach((p, i) => {
    const x = A.pos(p);
    if (x - lastPos < 9 && i !== A.pts.length - 1) return;
    if (x - lastPos < 9) ticks.lastChild && ticks.lastChild.remove();
    lastPos = x;
    ticks.append(h('span', { class: x < 4 ? 'first' : x > 96 ? 'last' : '', style: { left: x + '%' } }, fmtNum(p)));
  });
  return h('div', { class: 'band', title: A.log ? 'Log scale' : null }, bar, ticks);
}

/* ================================================================ routing */
function readHash() {
  const p = new URLSearchParams(location.hash.slice(1));
  return { tcp: p.get('tcp'), v: p.get('v'), tab: p.get('tab'), from: p.get('from'), to: p.get('to'), p: p.get('p') };
}
function hashOf(params) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== null && v !== undefined && v !== '') p.set(k, v);
  return '#' + p.toString();
}
function go(params) {
  const hash = hashOf({ ...readHash(), ...params });
  if (hash === location.hash) route(); else location.hash = hash;
}
function selectPillar(id) {
  S.pillarId = String(id);
  history.replaceState(null, '', hashOf({ ...readHash(), p: id }));
  render();
  const top = document.querySelector('.pdetail');
  if (top && top.getBoundingClientRect().top < 0) top.scrollIntoView({ block: 'start' });
}

async function route() {
  const r = readHash();
  try {
    if (!r.tcp && S.tcps.length) return go({ tcp: S.tcps[0].id });
    if (!r.tcp) { S.tcp = null; S.loading = false; return render(); }
    if (!S.tcp || String(S.tcp.id) !== String(r.tcp)) {
      S.pending = {};
      S.expanded = new Set();
      S.tcp = await api('GET', `/tcps/${r.tcp}`);
    }
    const versions = S.tcp.versions;
    const defaultNo = (openVersion() || {}).version_no || publishedNo() || (versions.at(-1) || {}).version_no;
    const wanted = Number(r.v);
    S.viewNo = versions.some((v) => v.version_no === wanted) ? wanted : defaultNo;
    S.tab = ['matrix', 'compare', 'history'].includes(r.tab) ? r.tab : 'matrix';
    S.pillarId = r.p;

    await loadMatrix();
    if (S.tab === 'compare') {
      const nos = versions.map((v) => v.version_no);
      let to = Number(r.to), from = Number(r.from);
      if (!nos.includes(to)) to = S.viewNo;
      if (!nos.includes(from)) from = defaultFrom(to);
      S.cmp.from = from; S.cmp.to = to;
      S.cmp.rows = from && to ? await api('GET', `/tcps/${S.tcp.id}/compare?from=${from}&to=${to}`) : [];
    }
  } catch (err) {
    toast(err.message, 'error');
  }
  S.loading = false;
  render();
}

function defaultFrom(to) {
  const pub = publishedNo();
  if (pub && pub !== to) return pub < to ? pub : Math.max(1, to - 1);
  return to > 1 ? to - 1 : to;
}

async function loadMatrix() {
  if (!S.tcp || !S.viewNo) { S.matrix = null; return; }
  S.matrix = await api('GET', `/tcps/${S.tcp.id}/versions/${S.viewNo}`);
  const ids = S.matrix.pillars.map((p) => String(p.tcp_pillar_id));
  if (!ids.includes(String(S.pillarId))) S.pillarId = ids[0] || null;
  const open = openVersion();
  S.draftDiff = open && publishedNo()
    ? await api('GET', `/tcps/${S.tcp.id}/compare?from=${publishedNo()}&to=${open.version_no}`)
    : null;
}

async function reloadTcp() {
  S.tcp = await api('GET', `/tcps/${S.tcp.id}`);
  S.tcps = await api('GET', '/tcps');
}

async function save(fn, okMessage) {
  try {
    await fn();
    if (okMessage) toast(okMessage);
  } catch (err) {
    toast(err.message, 'error');
  }
  try { await loadMatrix(); } catch (err) { toast(err.message, 'error'); }
  render();
}

/* ================================================================ render, keeping focus */
function render() {
  const a = document.activeElement;
  const key = a && a.dataset ? a.dataset.key : null;
  let val, s0, s1;
  if (key && (a.tagName === 'INPUT' || a.tagName === 'TEXTAREA') && a.type !== 'checkbox') {
    val = a.value;
    try { s0 = a.selectionStart; s1 = a.selectionEnd; } catch { /* number inputs */ }
  }
  const y = window.scrollY;
  const sheetScroll = document.querySelector('.sheet-body') ? document.querySelector('.sheet-body').scrollTop : 0;
  $app.replaceChildren(...[view()].flat(Infinity).filter(Boolean));
  const sb = document.querySelector('.sheet-body');
  if (sb) sb.scrollTop = sheetScroll;
  if (key) {
    const el = $app.querySelector(`[data-key="${CSS.escape(key)}"]`);
    if (el) {
      if (val !== undefined) el.value = val;
      el.focus({ preventScroll: true });
      try { if (s0 != null) el.setSelectionRange(s0, s1); } catch { /* not supported */ }
    }
  }
  window.scrollTo(0, y);
}

function view() {
  if (S.health && !S.health.ok) {
    return h('div', { class: 'center setup' }, h('div', { class: 'emptycard' },
      h('h2', null, 'TCP Matrix can’t start yet'),
      h('p', null, S.health.message),
      h('p', { class: 'muted' }, 'Database: ', h('code', null, S.health.database)),
      h('p', { class: 'muted' }, 'After fixing it, reload this page.')));
  }
  if (S.loading) return h('div', { class: 'center muted' }, 'Loading…');
  return h('div', { class: 'shell' }, sidebar(), h('main', { class: 'main' },
    S.tcp ? [profileHeader(), h('div', { class: 'content' }, tabBody())]
          : h('div', { class: 'center' }, h('div', { class: 'emptycard' },
              h('h2', null, 'No target candidate profiles yet'),
              h('p', { class: 'muted' }, 'Create a profile for a target to set its pillars, parameters and thresholds.'),
              h('button', { class: 'btn primary', onclick: newProfileModal }, icon('plus'), 'New profile')))),
    S.sheet && S.tcp && S.matrix ? profileSheet() : null);
}

function tabBody() {
  if (S.tab === 'compare') return compareView();
  if (S.tab === 'history') return historyView();
  return matrixView();
}

/* ================================================================ sidebar */
function sidebar() {
  const q = S.search.trim().toLowerCase();
  const list = S.tcps.filter((t) => !q || `${t.name} ${t.target_name} ${t.target_code || ''}`.toLowerCase().includes(q));
  const groups = new Map();
  for (const t of list) {
    if (!groups.has(t.target_name)) groups.set(t.target_name, { code: t.target_code, items: [] });
    groups.get(t.target_name).items.push(t);
  }
  const state = (t) => t.open_version_no
    ? [h('i', { class: 'open' }), `Draft v${t.open_version_no} open`]
    : t.current_published_version_no ? [h('i'), `v${t.current_published_version_no} published`] : [h('i', { class: 'open' }), 'Not published'];

  return h('aside', { class: 'side' },
    h('div', { class: 'side-top' },
      h('div', { class: 'brand' }, h('span', { class: 'brand-mark', 'aria-hidden': 'true' }, h('span'), h('span'), h('span')), 'TCP Matrix'),
      h('button', { class: 'btn new', onclick: newProfileModal }, icon('plus'), 'New profile'),
      h('label', { class: 'search' }, icon('search'), h('span', { class: 'sr' }, 'Search profiles'),
        h('input', { type: 'search', placeholder: 'Search targets and profiles', 'data-key': 'search', value: S.search,
          oninput: (e) => { S.search = e.target.value; render(); } })),
      S.tcps.length ? h('select', { class: 'mobile-switch', 'aria-label': 'Profile',
        onchange: (e) => go({ tcp: e.target.value, v: null, from: null, to: null, p: null, tab: 'matrix' }) },
        S.tcps.map((t) => h('option', { value: t.id, selected: S.tcp && String(S.tcp.id) === String(t.id) }, `${t.target_name}: ${t.name}`))) : null),
    h('nav', { 'aria-label': 'Profiles' },
      groups.size ? [...groups.entries()].map(([target, g]) => h('div', { class: 'tgroup' },
        h('h3', null, h('span', null, target), g.code ? h('span', null, g.code) : null),
        g.items.map((t) => h('button', {
          class: 'pbtn', 'aria-current': S.tcp && String(S.tcp.id) === String(t.id) ? 'page' : null,
          onclick: () => go({ tcp: t.id, v: null, from: null, to: null, p: null, tab: 'matrix' }),
        }, h('span', { class: 'pname' }, t.name), h('span', { class: 'pstate' }, state(t))))))
        : h('p', { class: 'empty-list' }, q ? 'No profile matches that search.' : 'No profiles yet.')));
}

/* ================================================================ profile header */
function profileHeader() {
  const t = S.tcp, m = S.matrix, L = S.L;
  const code = t.pfr_code || t.pfc_code || t.external_id;
  const hdr = m ? m.header : null;
  let state = null;
  if (hdr) {
    if (hdr.status_code === 'DRAFT') state = h('span', { class: 'state edit' }, `Editing draft v${hdr.version_no}`);
    else if (hdr.status_code === 'IN_REVIEW') state = h('span', { class: 'state edit' }, `v${hdr.version_no} in review`);
    else if (hdr.status_code === 'PUBLISHED') state = h('span', { class: 'state live' }, `Published v${hdr.version_no}`);
    else state = h('span', { class: 'state' }, `v${hdr.version_no} ${hdr.status.toLowerCase()}, read-only`);
  }
  const meta = (label, value) => h('span', { class: 'm' }, h('b', null, label), value || '—');
  const n = S.draftDiff ? countItems(S.draftDiff) : 0;
  const tab = (id, label, extra) => h('button', { role: 'tab', 'aria-selected': S.tab === id ? 'true' : 'false',
    onclick: () => go({ tab: id }) }, label, extra);

  return h('header', { class: 'phead' },
    h('div', { class: 'crumb' }, t.target_name, code ? h('span', { class: 'code' }, code) : h('span', { class: 'dim' }, 'new program')),
    h('div', { class: 'titlerow' },
      h('h1', null, t.name), state, h('span', { class: 'spacer' }),
      h('div', { class: 'actions' }, versionActions())),
    hdr ? h('div', { class: 'metarow' },
      meta('Stage', (byId(L.stages, hdr.stage_id) || {}).name),
      meta('Modality', (byId(L.modalities, hdr.modality_id) || {}).name),
      meta('Area', (byId(L.therapeuticAreas, hdr.therapeutic_area_id) || {}).name),
      hdr.moa ? meta('MOA', hdr.moa) : null,
      h('button', { class: 'btn ghost sm', onclick: () => { S.sheet = true; render(); } }, icon('details'),
        editable() ? 'Edit profile details' : 'Profile details')) : null,
    h('div', { class: 'trackrow' },
      versionTrack(),
      h('div', { class: 'seg tabs', role: 'tablist' },
        tab('matrix', 'Matrix'),
        tab('compare', 'Compare', n ? h('span', { class: 'count', title: `${n} items changed in the draft` }, n) : null),
        tab('history', 'History'))));
}

function versionTrack() {
  return h('nav', { class: 'track', 'aria-label': 'Versions' }, S.tcp.versions.map((v) => {
    const date = v.published_on || v.submitted_on || v.created_on;
    const inCmp = S.tab === 'compare' && (v.version_no === S.cmp.from || v.version_no === S.cmp.to);
    const current = S.tab === 'compare' ? v.version_no === S.cmp.to : v.version_no === S.viewNo;
    return h('button', {
      class: `s-${v.status_code}`, 'aria-current': current ? 'true' : 'false',
      title: [v.edit_type, v.reason_for_edit, fmtDate(date)].filter(Boolean).join('\n'),
      onclick: () => (S.tab === 'compare' ? go({ to: v.version_no, v: v.version_no }) : go({ v: v.version_no })),
    },
      h('span', { class: 'node', 'aria-hidden': 'true' }),
      h('span', { class: 'v' }, `v${v.version_no}`),
      inCmp ? h('span', { class: 'mark' }, v.version_no === S.cmp.from ? 'From' : 'To') : h('span', { class: 'st' }, v.status));
  }));
}

function versionActions() {
  const open = openVersion();
  const tcpId = S.tcp.id;
  if (!open) return [h('button', { class: 'btn primary', onclick: startVersionModal }, icon('plus'), 'Start new version')];
  const vno = open.version_no;
  const out = [];
  if (S.viewNo !== vno) {
    out.push(h('button', { class: 'btn', onclick: () => go({ v: vno, tab: 'matrix' }) },
      `Open ${open.status_code === 'DRAFT' ? 'draft' : 'review'} v${vno}`));
  }
  if (open.status_code === 'DRAFT') {
    out.push(
      h('button', { class: 'btn ghost', onclick: checkDraft }, icon('check'), 'Check'),
      h('button', { class: 'btn danger', onclick: () => discardModal(vno) }, 'Discard'),
      h('button', { class: 'btn', onclick: () => lifecycle('submit', `Submitted v${vno} for review`) }, 'Submit for review'),
      h('button', { class: 'btn draft', onclick: () => publishModal(vno) }, `Publish v${vno}`));
  } else {
    out.push(
      h('button', { class: 'btn', onclick: () => rejectModal(vno) }, 'Return to draft'),
      h('button', { class: 'btn draft', onclick: () => publishModal(vno) }, `Publish v${vno}`));
  }
  return out;

  async function checkDraft() {
    try {
      const r = await api('POST', `/tcps/${tcpId}/check`);
      r.ok ? toast(`v${vno} is ready to publish.`) : toast(r.message, 'warn');
    } catch (err) { toast(err.message, 'error'); }
  }
}

async function lifecycle(action, okMessage, body) {
  try {
    await api('POST', `/tcps/${S.tcp.id}/${action}`, body);
    await reloadTcp();
    toast(okMessage);
  } catch (err) { toast(err.message, 'error'); }
  route();
}

/* ================================================================ matrix */
function matrixView() {
  const m = S.matrix;
  if (!m) return h('div', { class: 'emptycard' }, h('h2', null, 'This profile has no versions yet.'));
  const ed = editable();
  if (!m.pillars.length) {
    return h('div', { class: 'emptycard' },
      h('h2', null, 'No pillars yet'),
      h('p', { class: 'muted' }, ed ? 'Add the first pillar, such as Safety or Potency, then set its parameters.' : 'This version has no pillars.'),
      ed ? h('button', { class: 'btn primary', onclick: addPillarModal }, icon('plus'), 'Add pillar') : null);
  }
  const p = m.pillars.find((x) => String(x.tcp_pillar_id) === String(S.pillarId)) || m.pillars[0];
  return [weightStrip(), h('div', { class: 'mgrid' }, outline(), pillarDetail(p))];
}

function pillarStats(p) {
  let params = 0, issues = 0, gate = 0;
  for (const c of Object.values(p.criteria)) {
    const ct = S.L.criterionTypes.find((x) => x.code === c.type_code);
    for (const q of c.parameters) {
      params++;
      if (ct && ct.is_go_no_go) gate++;
      if (analyse(q, byId(S.L.attributes, q.attribute_id)).issues.length) issues++;
    }
  }
  const changed = changedHere(p.from_version) || Object.values(p.criteria).some((c) => changedHere(c.from_version) || c.parameters.some((q) => changedHere(q.from_version)));
  return { params, issues, gate, changed };
}

function weightStrip() {
  const pillars = S.matrix.pillars;
  const total = pillars.reduce((s, p) => s + Number(p.weight || 0), 0);
  const ok = Math.abs(total - 100) < 1e-9;
  const scale = Math.max(total, 100);
  return h('section', { class: 'wstrip', 'aria-label': 'Pillar weights' },
    h('div', { class: 'wstrip-head' },
      h('h2', null, 'Pillar weights'),
      h('span', { class: `wtotal ${ok ? 'ok' : 'off'}` }, ok ? 'Total 100' : `Total ${fmtNum(total)}: must be 100 to publish`)),
    h('div', { class: 'wbar' },
      pillars.map((p) => h('button', {
        class: 'wseg', 'aria-current': String(p.tcp_pillar_id) === String(S.pillarId) ? 'true' : 'false',
        style: { flex: `${Math.max(Number(p.weight), 0.5)} 1 0`, background: pillarHue(p.pillar_id) },
        title: `${p.pillar_name}: ${fmtNum(p.weight)}`, onclick: () => selectPillar(p.tcp_pillar_id),
      }, h('span', null, p.pillar_name), h('b', null, fmtNum(p.weight)))),
      total < 100 ? h('div', { class: 'wseg rest', style: { flex: `${scale - total} 1 0` }, title: `${fmtNum(100 - total)} not assigned` },
        h('span', null, 'Not assigned'), h('b', null, fmtNum(100 - total))) : null));
}

function outline() {
  const ed = editable();
  return h('nav', { class: 'outline', 'aria-label': 'Pillars' },
    h('ol', null, S.matrix.pillars.map((p) => {
      const st = pillarStats(p);
      return h('li', null, h('button', {
        class: 'pitem', 'aria-current': String(p.tcp_pillar_id) === String(S.pillarId) ? 'true' : 'false',
        onclick: () => selectPillar(p.tcp_pillar_id),
      },
        h('span', { class: 'dot', style: { background: pillarHue(p.pillar_id) } }),
        h('span', { class: 'nm' }, p.pillar_name),
        h('span', { class: 'wt' }, fmtNum(p.weight)),
        h('span', { class: 'sub' },
          h('span', { class: 'cnt' }, `${st.params} parameter${st.params === 1 ? '' : 's'}`),
          st.gate ? h('span', { class: 'gate', title: `${st.gate} Go/No-Go parameter(s)` }, icon('gate'), st.gate) : null,
          st.issues ? h('span', { class: 'warn', title: `${st.issues} parameter(s) need attention` }, icon('warn'), st.issues) : null,
          st.changed ? h('span', { class: 'chg' }, 'changed') : null)));
    })),
    ed ? h('button', { class: 'btn ghost sm add', onclick: addPillarModal }, icon('plus'), 'Add pillar') : null);
}

function pillarDetail(p) {
  const ed = editable(), L = S.L;
  const pid = p.tcp_pillar_id;
  const patch = (values) => save(() => api('PATCH', `/items/pillar/${pid}`, values));
  const pillars = S.matrix.pillars;
  const index = pillars.indexOf(p);
  const used = new Set(pillars.map((x) => String(x.pillar_id)));
  const ec = byId(L.expectedCompletions, p.expected_completion_id);

  const head = h('div', { class: 'pd-head' },
    h('span', { class: 'dot', style: { background: pillarHue(p.pillar_id) } }),
    ed ? h('select', { class: 'pname', 'data-key': `p-${pid}-pillar`, 'aria-label': 'Pillar',
           onchange: (e) => patch({ pillar_id: Number(e.target.value) }) },
           L.pillars.filter((x) => String(x.id) === String(p.pillar_id) || !used.has(String(x.id)))
             .map((x) => h('option', { value: x.id, selected: String(x.id) === String(p.pillar_id) }, x.name)))
       : h('h2', null, p.pillar_name),
    h('span', { class: 'weight' }, 'Weight',
      ed ? h('input', { type: 'number', min: 0, max: 100, step: 'any', 'data-key': `p-${pid}-weight`, 'aria-label': 'Weight',
             value: fmtNum(p.weight), onchange: (e) => patch({ weight: Number(e.target.value || 0) }) })
         : h('b', null, fmtNum(p.weight))),
    h('span', { class: 'spacer' }),
    h('span', { class: 'pd-actions' },
    h('button', { class: 'iconbtn', title: 'History', 'aria-label': `History of ${p.pillar_name}`,
      onclick: () => itemHistory('PILLAR', pid, p.pillar_name) }, icon('history')),
    ed ? [
      h('button', { class: 'iconbtn', title: 'Move up', 'aria-label': 'Move pillar up', disabled: index === 0, onclick: () => movePillar(index, -1) }, icon('up')),
      h('button', { class: 'iconbtn', title: 'Move down', 'aria-label': 'Move pillar down', disabled: index === pillars.length - 1, onclick: () => movePillar(index, 1) }, icon('down')),
      h('button', { class: 'iconbtn danger', title: 'Remove pillar', 'aria-label': `Remove ${p.pillar_name}`,
        onclick: () => confirmModal({
          title: `Remove ${p.pillar_name}?`,
          message: 'The pillar, its criteria and parameters leave this draft. Earlier versions keep them.',
          action: 'Remove pillar', danger: true,
          run: () => api('DELETE', `/items/pillar/${pid}`), done: `Removed ${p.pillar_name}`,
        }) }, icon('trash')),
    ] : null));

  const kdp = h('div', { class: 'kdp' },
    h('div', { class: 'kdp-label' }, 'Key design principle',
      changedHere(p.from_version) ? h('span', { class: 'tag-chg' }, 'Pillar changed in this version') : null),
    ed ? h('textarea', { 'data-key': `p-${pid}-kdp`, rows: 2, value: p.key_design_principle || '', 'aria-label': 'Key design principle',
           onchange: (e) => e.target.value.trim() ? patch({ key_design_principle: e.target.value }) : toast('The key design principle can’t be empty.', 'error') })
       : h('p', null, p.key_design_principle));

  const meta = h('div', { class: 'pd-meta' },
    h('label', { class: 'field' }, h('span', null, 'Category'),
      ed ? h('input', { type: 'text', 'data-key': `p-${pid}-cat`, value: p.design_principle_category || '',
             onchange: (e) => patch({ design_principle_category: e.target.value || null }) })
         : h('span', { class: 'ro' }, p.design_principle_category || '—')),
    h('label', { class: 'field' }, h('span', null, 'Expected completion'),
      ed ? h('select', { 'data-key': `p-${pid}-ec`, onchange: (e) => patch({ expected_completion_id: numOrNull(e.target.value) }) },
             h('option', { value: '' }, '—'),
             L.expectedCompletions.map((o) => h('option', { value: o.id, selected: String(o.id) === String(p.expected_completion_id) }, o.name)))
         : h('span', { class: 'ro' }, ec ? ec.name : '—')),
    h('div', { class: 'field' }, h('span', null, 'Control Tower'),
      ed ? h('label', { class: 'toggle' }, h('input', { type: 'checkbox', checked: !!p.send_to_control_tower, 'data-key': `p-${pid}-ct`,
             onchange: (e) => patch({ send_to_control_tower: e.target.checked }) }), p.send_to_control_tower ? 'Results are sent' : 'Not sent')
         : h('span', { class: 'ro' }, p.send_to_control_tower ? 'Results are sent' : 'Not sent')));

  const sections = L.criterionTypes.map((ct) => (ct.allows_parameters ? paramSection(p, ct) : rationaleSection(p, ct)));
  return h('article', { class: `pdetail ${changedHere(p.from_version) ? 'changed' : ''}` }, head, kdp, meta, sections);
}

async function movePillar(index, dir) {
  const list = S.matrix.pillars;
  if (!list[index + dir]) return;
  const order = list.map((p, i) => ({ id: p.tcp_pillar_id, seq: (i + 1) * 10, cur: p.sequence }));
  order[index].seq = (index + dir + 1) * 10;
  order[index + dir].seq = (index + 1) * 10;
  await save(async () => {
    for (const o of order) if (o.seq !== o.cur) await api('PATCH', `/items/pillar/${o.id}`, { sequence: o.seq });
  });
}

function rationaleSection(p, ct) {
  const c = p.criteria[ct.code];
  const ed = editable();
  if (!ed && !(c && c.main_text)) return null;
  return h('section', { class: 'psec rationale' },
    h('div', { class: 'psec-head' }, h('h3', null, ct.label),
      c && changedHere(c.from_version) ? h('span', { class: 'tag-chg' }, 'Changed') : null),
    ed ? h('textarea', { 'data-key': `c-${p.tcp_pillar_id}-${ct.code}`, rows: 3, value: (c && c.main_text) || '',
           'aria-label': ct.label, placeholder: 'Why these criteria matter for this pillar',
           onchange: (e) => save(() => api('PUT', `/pillars/${p.tcp_pillar_id}/criteria/${ct.code}`, { main_text: e.target.value || null })) })
       : h('p', null, c.main_text));
}

function paramSection(p, ct) {
  const c = p.criteria[ct.code];
  const params = c ? c.parameters : [];
  const ed = editable(), L = S.L;
  if (!ed && !params.length) return null;

  const used = new Set(params.map((x) => String(x.attribute_id)));
  const addSel = ed ? h('select', {
    class: 'addsel', 'aria-label': `Add an attribute to ${ct.label}`,
    onchange: (e) => {
      const v = e.target.value;
      e.target.value = '';
      if (v === '__new') return newAttributeModal(p, ct);
      if (v) addParameter(p, ct, Number(v));
    },
  }, h('option', { value: '' }, '+ Add attribute…'),
     L.attributes.filter((a) => !used.has(String(a.id))).map((a) => h('option', { value: a.id }, a.name)),
     h('option', { value: '__new' }, 'New attribute…')) : null;

  const gate = ct.is_go_no_go ? h('span', { class: 'gatebadge' }, icon('gate'), 'Gate: a Bad result means No-Go') : null;
  if (!params.length) {
    return h('section', { class: 'psec compact' },
      h('div', { class: 'psec-head' }, h('h3', null, ct.label), gate, h('span', { class: 'none' }, 'No attributes yet'), addSel));
  }
  return h('section', { class: 'psec' },
    h('div', { class: 'psec-head' }, h('h3', null, ct.label), h('span', { class: 'n' }, params.length), gate),
    h('div', { class: 'plist' }, params.map(paramRow)),
    addSel);
}

async function addParameter(p, ct, attributeId) {
  const attr = byId(S.L.attributes, attributeId);
  const crit = p.criteria[ct.code];
  const maxSeq = crit ? Math.max(0, ...crit.parameters.map((x) => x.sequence || 0)) : 0;
  const medium = S.L.impactLevels.find((i) => i.code === 'MEDIUM') || S.L.impactLevels[0];
  await save(async () => {
    const r = await api('POST', `/pillars/${p.tcp_pillar_id}/criteria/${ct.code}/parameters`, {
      attribute_id: attributeId, unit_id: attr ? attr.default_unit_id : null,
      impact_level_id: medium.id, sequence: maxSeq + 1,
    });
    S.expanded.add(String(r.id));
  });
}

function paramRow(x) {
  const ed = editable(), L = S.L;
  const qid = String(x.tcp_parameter_id);
  const attr = byId(L.attributes, x.attribute_id);
  const unit = byId(L.units, x.unit_id);
  const impact = byId(L.impactLevels, x.impact_level_id);
  const A = analyse(x, attr);
  const open = ed && S.expanded.has(qid);
  const changed = changedHere(x.from_version);
  const typeLabel = attr ? (attr.data_type === 'NUMERIC' ? 'Numeric' : attr.data_type === 'TEXT' ? 'Text match' : 'Present / absent') : '';
  const toggle = () => { S.expanded.has(qid) ? S.expanded.delete(qid) : S.expanded.add(qid); render(); };

  const main = h('div', { class: 'prow-main' },
    h('div', { class: 'pattr' },
      h('span', { class: 'an', title: attr ? attr.name : '' }, attr ? attr.name : '?'),
      h('span', { class: 'ad' }, [unit ? unit.symbol : null, typeLabel].filter(Boolean).join(', ')),
      x.notes && !open ? h('span', { class: 'note' }, x.notes) : null),
    h('span', { class: `impact ${impact ? impact.code : ''}`, title: 'Impact on the score' }, impact ? impact.label : ''),
    band(x, attr),
    h('div', { class: 'rchips' }, L.ratingLevels.filter((r) => !A.cats || !x.rules[r.code]).map((r) => x.rules[r.code]
      ? h('span', { class: `rchip ${r.code}`, title: `${r.label}: ${x.rules[r.code].condition}${x.rules[r.code].comment ? ` (${x.rules[r.code].comment})` : ''}` },
          h('i'), fmtRule(x.rules[r.code]))
      : h('span', { class: 'rchip unset', title: `${r.label} not set` }, `${r.label} not set`))),
    h('div', { class: 'pact' },
      A.issues.length ? h('span', { class: 'warnicon', title: A.issues.join('\n'), role: 'img', 'aria-label': A.issues.join('. ') }, icon('warn')) : null,
      h('button', { class: 'iconbtn', title: 'History', 'aria-label': `History of ${attr ? attr.name : 'parameter'}`,
        onclick: () => itemHistory('PARAMETER', qid, attr ? attr.name : 'Parameter') }, icon('history')),
      ed ? h('button', { class: 'iconbtn', title: open ? 'Close editor' : 'Edit', 'aria-expanded': open ? 'true' : 'false',
        'aria-label': `Edit ${attr ? attr.name : 'parameter'}`, onclick: toggle }, icon('edit')) : null,
      ed ? h('button', { class: 'iconbtn danger', title: 'Remove', 'aria-label': `Remove ${attr ? attr.name : 'parameter'}`,
        onclick: () => save(() => api('DELETE', `/items/parameter/${qid}`), `Removed ${attr ? attr.name : 'parameter'}`) }, icon('trash')) : null));

  return h('div', { class: `prow ${changed ? 'changed' : ''} ${open ? 'open' : ''}`, 'data-attribute': attr ? attr.name : null,
    title: changed ? 'Changed in this version' : null },
    main, open ? paramEditor(x, attr, A) : null);
}

function paramEditor(x, attr, A) {
  const L = S.L;
  const qid = x.tcp_parameter_id;
  const patch = (values) => save(() => api('PATCH', `/items/parameter/${qid}`, values));
  return h('div', { class: 'peditor' },
    h('div', { class: 'ped-row' },
      h('label', { class: 'field' }, h('span', null, 'Attribute'),
        h('select', { 'data-key': `q-${qid}-attr`, onchange: (e) => {
          const a = byId(L.attributes, e.target.value);
          const values = { attribute_id: Number(e.target.value) };
          if (a && a.default_unit_id && !x.unit_id) values.unit_id = a.default_unit_id;
          patch(values);
        } }, L.attributes.map((a) => h('option', { value: a.id, selected: String(a.id) === String(x.attribute_id) }, a.name)))),
      h('label', { class: 'field' }, h('span', null, 'Unit'),
        h('select', { 'data-key': `q-${qid}-unit`, onchange: (e) => patch({ unit_id: numOrNull(e.target.value) }) },
          h('option', { value: '' }, '—'), L.units.map((u) => h('option', { value: u.id, selected: String(u.id) === String(x.unit_id) }, u.symbol)))),
      h('div', { class: 'field' }, h('span', null, 'Impact on the score'),
        h('div', { class: 'seg impact-seg', role: 'group', 'aria-label': 'Impact' },
          L.impactLevels.map((i) => h('button', { type: 'button', 'aria-pressed': String(i.id) === String(x.impact_level_id) ? 'true' : 'false',
            'data-key': `q-${qid}-imp-${i.code}`, onclick: () => patch({ impact_level_id: Number(i.id) }) }, i.label)))),
      h('label', { class: 'field' }, h('span', null, 'Notes'),
        h('input', { type: 'text', 'data-key': `q-${qid}-notes`, value: x.notes || '', placeholder: 'Assay, conditions, source',
          onchange: (e) => patch({ notes: e.target.value || null }) }))),
    h('div', { class: 'ped-rules' }, L.ratingLevels.map((r) => ruleEditor(x, r, attr))),
    A.issues.length ? h('div', { class: 'gapnote' }, icon('warn'), h('span', null, A.issues.join('. ') + '. Results there will count as unrated.')) : null);
}

function ruleEditor(x, rating, attr) {
  const qid = x.tcp_parameter_id;
  const key = `r-${qid}-${rating.code}`;
  const saved = x.rules[rating.code];
  const cur = S.pending[key] || (saved
    ? { operator: saved.operator, value: fmtNum(saved.value), value_to: fmtNum(saved.value_to), text: saved.text || '' }
    : { operator: '', value: '', value_to: '', text: '' });
  const dtype = attr ? attr.data_type : 'NUMERIC';
  const ops = S.L.operators.filter((o) => (dtype === 'TEXT' ? o.for_text : dtype === 'PRESENCE' ? o.for_presence : o.for_numeric));
  const op = S.L.operators.find((o) => o.code === cur.operator);
  const isText = dtype === 'TEXT';

  const complete = (c) => {
    const o = S.L.operators.find((q) => q.code === c.operator);
    if (!o) return false;
    if (o.value_count === 0) return true;
    if (isText) return !!(c.text && c.text.trim());
    if (c.value === '' || isNaN(Number(c.value))) return false;
    return o.value_count === 1 || (c.value_to !== '' && !isNaN(Number(c.value_to)));
  };
  const commit = (next) => {
    if (!next.operator) {
      delete S.pending[key];
      if (saved) save(() => api('DELETE', `/parameters/${qid}/rules/${rating.code}`));
      else render();
      return;
    }
    if (!complete(next)) { S.pending[key] = next; render(); return; }
    delete S.pending[key];
    const o = S.L.operators.find((q) => q.code === next.operator);
    save(() => api('PUT', `/parameters/${qid}/rules/${rating.code}`, {
      operator: next.operator,
      value: isText || o.value_count === 0 ? null : next.value,
      value_to: o.value_count === 2 ? next.value_to : null,
      text: isText && o.value_count > 0 ? next.text : null,
      comment: saved ? saved.comment : null,
    }));
  };

  const inputs = [];
  if (op && op.value_count >= 1) {
    if (isText) {
      inputs.push(h('input', { type: 'text', 'data-key': `${key}-t`, value: cur.text, 'aria-label': `${rating.label} text`,
        placeholder: 'text', onchange: (e) => commit({ ...cur, text: e.target.value }) }));
    } else {
      inputs.push(h('input', { type: 'number', step: 'any', 'data-key': `${key}-v`, value: cur.value,
        'aria-label': `${rating.label} value`, onchange: (e) => commit({ ...cur, value: e.target.value }) }));
      if (op.value_count === 2) {
        inputs.push(h('span', { class: 'to' }, 'to'),
          h('input', { type: 'number', step: 'any', 'data-key': `${key}-v2`, value: cur.value_to,
            'aria-label': `${rating.label} upper value`, onchange: (e) => commit({ ...cur, value_to: e.target.value }) }));
      }
    }
  }
  const pending = !!S.pending[key];
  return h('div', { class: `redit ${rating.code} ${pending ? 'incomplete' : ''}` },
    h('div', { class: 'redit-h' }, rating.label,
      saved ? h('button', { class: 'iconbtn', title: `Clear ${rating.label}`, 'aria-label': `Clear ${rating.label} rule`,
        onclick: () => commit({ ...cur, operator: '' }) }, icon('close')) : null),
    h('div', { class: 'redit-c' },
      h('select', { 'data-key': `${key}-op`, 'aria-label': `${rating.label} condition`,
        onchange: (e) => commit({ ...cur, operator: e.target.value }) },
        h('option', { value: '' }, 'Not set'),
        ops.map((o) => h('option', { value: o.code, selected: o.code === cur.operator, title: o.label }, OP_SHORT[o.code]))),
      op && op.value_count === 2 ? null : inputs),
    op && op.value_count === 2 ? h('div', { class: 'redit-c' }, inputs) : null,
    pending ? h('span', { class: 'hint' }, 'Enter the value to save') : null);
}

/* ================================================================ profile details sheet */
function profileSheet() {
  const m = S.matrix, hdr = m.header, ed = editable(), L = S.L;
  const tcpId = S.tcp.id;
  const close = () => { S.sheet = false; render(); };
  const patchHeader = (values) => save(() => api('PATCH', `/tcps/${tcpId}/header`, values));
  const sel = (key, list, labelKey, value, field) => h('select', {
    'data-key': key, onchange: (e) => patchHeader({ [field]: numOrNull(e.target.value) }),
  }, h('option', { value: '' }, '—'), list.map((o) => h('option', { value: o.id, selected: String(o.id) === String(value) }, o[labelKey])));
  const kv = (label, value) => [h('dt', null, label), h('dd', null, value || h('span', { class: 'dim' }, '—'))];

  const profile = h('section', { class: 'sheet-sec' }, h('h3', null, 'Profile'),
    ed ? [
      h('label', { class: 'field' }, h('span', null, 'Stage'), sel('h-stage', L.stages, 'name', hdr.stage_id, 'stage_id')),
      h('label', { class: 'field' }, h('span', null, 'Modality'), sel('h-mod', L.modalities, 'name', hdr.modality_id, 'modality_id')),
      h('label', { class: 'field' }, h('span', null, 'Therapeutic area'), sel('h-ta', L.therapeuticAreas, 'name', hdr.therapeutic_area_id, 'therapeutic_area_id')),
      h('label', { class: 'field' }, h('span', null, 'Mechanism of action'),
        h('input', { type: 'text', 'data-key': 'h-moa', value: hdr.moa || '', onchange: (e) => patchHeader({ moa: e.target.value || null }) })),
    ] : h('dl', { class: 'kv' },
      kv('Stage', (byId(L.stages, hdr.stage_id) || {}).name),
      kv('Modality', (byId(L.modalities, hdr.modality_id) || {}).name),
      kv('Therapeutic area', (byId(L.therapeuticAreas, hdr.therapeutic_area_id) || {}).name),
      kv('Mechanism of action', hdr.moa)));

  const tr = h('section', { class: 'sheet-sec' }, h('h3', null, 'TR numbers'),
    h('div', { class: 'chips' }, m.trNumbers.length ? m.trNumbers.map((t) => h('span', {
      class: `chip ${ed ? '' : 'ro'} ${changedHere(t.from_version) ? 'new' : ''}` }, t.tr_number,
      ed ? h('button', { class: 'iconbtn', 'aria-label': `Remove ${t.tr_number}`,
        onclick: () => save(() => api('DELETE', `/tcps/${tcpId}/tr-numbers/${encodeURIComponent(t.tr_number)}`)) }, icon('close')) : null))
      : h('span', { class: 'dim' }, 'None')),
    ed ? h('form', { class: 'inline-add', onsubmit: (e) => {
      e.preventDefault();
      const v = e.target.elements.tr.value.trim();
      if (v) save(() => api('POST', `/tcps/${tcpId}/tr-numbers`, { tr_number: v }));
    } }, h('input', { type: 'text', name: 'tr', placeholder: 'Add a TR number', 'aria-label': 'Add a TR number' }),
       h('button', { class: 'btn sm', type: 'submit' }, 'Add')) : null);

  const why = h('section', { class: 'sheet-sec' }, h('h3', null, `Why v${hdr.version_no} exists`),
    ed ? [
      h('label', { class: 'field' }, h('span', null, 'Type of change'),
        h('select', { 'data-key': 'h-et', onchange: (e) => patchHeader({ edit_type_id: numOrNull(e.target.value) }) },
          L.editTypes.map((o) => h('option', { value: o.id, selected: String(o.id) === String(hdr.edit_type_id) }, o.label)))),
      h('label', { class: 'field' }, h('span', null, 'Reason for the change'),
        h('textarea', { 'data-key': 'h-reason', rows: 3, value: hdr.reason_for_edit || '',
          onchange: (e) => patchHeader({ reason_for_edit: e.target.value || null }) })),
      hdr.comments ? h('p', { class: 'muted' }, hdr.comments) : null,
    ] : h('dl', { class: 'kv' },
      kv('Type of change', (byId(L.editTypes, hdr.edit_type_id) || {}).label),
      kv('Reason', hdr.reason_for_edit),
      hdr.comments ? kv('Comments', hdr.comments) : null));

  const scoring = h('section', { class: 'sheet-sec' }, h('h3', null, 'Impact weights'),
    h('p', { class: 'muted' }, 'How much each impact level counts in a pillar score.'),
    h('div', { class: 'weights3' }, m.impactWeights.map((w) => ed
      ? h('label', { class: 'field' }, h('span', null, w.label),
          h('input', { type: 'number', min: 0, step: 'any', 'data-key': `iw-${w.code}`, value: fmtNum(w.weight),
            onchange: (e) => save(() => api('PUT', `/tcps/${tcpId}/impact-weights/${w.code}`, { weight: e.target.value })) }))
      : h('dl', { class: 'kv' }, kv(w.label, fmtNum(w.weight))))));

  return [
    h('div', { class: 'sheet-scrim', onclick: close }),
    h('aside', { class: 'sheet', role: 'dialog', 'aria-label': 'Profile details',
      onkeydown: (e) => { if (e.key === 'Escape') close(); } },
      h('div', { class: 'sheet-head' },
        h('h2', null, `Profile details, v${hdr.version_no}`),
        h('button', { class: 'iconbtn', 'aria-label': 'Close', onclick: close, 'data-key': 'sheet-close' }, icon('close'))),
      h('div', { class: 'sheet-body' }, profile, tr, why, scoring)),
  ];
}

/* ================================================================ compare */
function countItems(rows) {
  return new Set(rows.map((r) => `${r.item_type}:${r.item_key}`)).size;
}

function compareView() {
  const versions = S.tcp.versions;
  const { from, to, rows, filter } = S.cmp;
  const open = openVersion();
  const pub = publishedNo();
  const opt = (sel) => versions.map((v) => h('option', { value: v.version_no, selected: v.version_no === sel }, `v${v.version_no}, ${v.status.toLowerCase()}`));

  const presets = [];
  if (open && pub) presets.push(h('button', { class: 'btn sm', onclick: () => go({ from: pub, to: open.version_no }) }, `Draft v${open.version_no} vs published v${pub}`));
  const pubs = versions.filter((v) => v.status_code === 'PUBLISHED' || v.status_code === 'SUPERSEDED');
  if (pubs.length >= 2) {
    const [a, b] = pubs.slice(-2);
    presets.push(h('button', { class: 'btn sm', onclick: () => go({ from: a.version_no, to: b.version_no }) }, `Last two published, v${a.version_no} and v${b.version_no}`));
  }
  if (versions.length > 2) presets.push(h('button', { class: 'btn sm', onclick: () => go({ from: versions[0].version_no, to: versions.at(-1).version_no }) }, 'First to latest'));

  const head = h('section', { class: 'cmp-head' },
    h('div', { class: 'cmp-pick' },
      h('label', null, h('span', { class: 'sr' }, 'From version'), h('select', { onchange: (e) => go({ from: e.target.value }) }, opt(from))),
      h('span', { class: 'arrow', 'aria-hidden': 'true' }, '→'),
      h('label', null, h('span', { class: 'sr' }, 'To version'), h('select', { onchange: (e) => go({ to: e.target.value, v: e.target.value }) }, opt(to))),
      h('button', { class: 'btn ghost', title: 'Swap', onclick: () => go({ from: to, to: from }) }, icon('swap'), 'Swap')),
    presets.length ? h('div', { class: 'presets' }, h('span', null, 'Quick picks'), presets) : null);

  if (!rows) return head;
  if (from === to) return [head, h('p', { class: 'muted' }, 'Choose two different versions to see what changed.')];

  const items = new Map();
  for (const r of rows) {
    const k = `${r.item_type}:${r.item_key}`;
    if (!items.has(k)) items.set(k, { key: k, type: r.item_type, itemKey: r.item_key, path: r.item_path, change: r.change_type, fields: [] });
    items.get(k).fields.push(r);
  }
  const all = [...items.values()];
  const counts = { ADDED: 0, REMOVED: 0, MODIFIED: 0 };
  for (const i of all) counts[i.change]++;
  const shown = all.filter((i) => filter === 'ALL' || i.change === filter);
  const groups = new Map();
  for (const i of shown) {
    const g = ['HEADER', 'TR_NUMBER', 'IMPACT_WEIGHT'].includes(i.type) ? 'Profile and scoring' : i.path.split(' / ')[0];
    if (!groups.has(g)) groups.set(g, []);
    groups.get(g).push(i);
  }
  const hueFor = (name) => { const p = S.L.pillars.find((x) => x.name === name); return p ? pillarHue(p.id) : 'var(--ink-3)'; };
  const seg = (id, label) => h('button', { 'aria-pressed': filter === id ? 'true' : 'false', onclick: () => { S.cmp.filter = id; render(); } }, label);

  return [head,
    h('div', { class: 'cmp-sum' },
      h('span', { class: 'total' }, all.length ? `${all.length} item${all.length === 1 ? '' : 's'} changed from v${from} to v${to}` : `No differences between v${from} and v${to}`),
      all.length ? h('div', { class: 'seg', role: 'group', 'aria-label': 'Show' },
        seg('ALL', `All ${all.length}`), seg('MODIFIED', `Modified ${counts.MODIFIED}`),
        seg('ADDED', `Added ${counts.ADDED}`), seg('REMOVED', `Removed ${counts.REMOVED}`)) : null),
    [...groups.entries()].map(([name, list]) => h('section', { class: 'cgroup' },
      h('h2', null, h('i', { style: { background: name === 'Profile and scoring' ? 'var(--ink-3)' : hueFor(name) } }), name),
      list.map(compareItem)))];
}

function compareItem(i) {
  const parts = i.path.split(' / ');
  const title = i.type === 'HEADER' ? 'Profile' : i.type === 'PILLAR' ? 'Pillar settings' : parts.at(-1);
  const ctx = i.type === 'PARAMETER' || i.type === 'CRITERION'
    ? parts.slice(1, i.type === 'PARAMETER' ? -1 : undefined).join(' / ')
    : (i.type === 'IMPACT_WEIGHT' ? 'Impact weight' : i.type === 'TR_NUMBER' ? 'TR number' : '');
  const label = { ADDED: 'Added', REMOVED: 'Removed', MODIFIED: 'Modified' }[i.change];
  const historyBtn = ['PILLAR', 'PARAMETER', 'CRITERION'].includes(i.type)
    ? h('button', { class: 'btn ghost sm', onclick: () => itemHistory(i.type, i.itemKey, i.path) }, icon('history'), 'History') : null;
  const cell = (v, cls) => h('div', { class: `${cls} ${v != null ? 'has' : 'blank'}` }, v != null ? v : '—');
  const one = i.change !== 'MODIFIED';
  const fields = i.fields.filter((f) => !(one && f.field_name === 'sequence')).sort(byField);

  return h('article', { class: `citem ${i.change}` },
    h('div', { class: 'citem-head' },
      h('strong', null, title), ctx ? h('span', { class: 'ctx' }, ctx) : null,
      h('span', { class: `badge ${i.change}` }, label), h('span', { class: 'spacer' }), historyBtn),
    one
      ? h('div', { class: 'cfields one' }, fields.map((f) => [
          h('div', { class: 'fn' }, fieldLabel(f.field_name)),
          i.change === 'ADDED' ? cell(f.new_value, 'new') : cell(f.old_value, 'old')]))
      : h('div', { class: 'cfields' },
          h('div', { class: 'h' }, 'Field'), h('div', { class: 'h' }, `v${S.cmp.from}`), h('div', { class: 'h' }, `v${S.cmp.to}`),
          fields.map((f) => [h('div', { class: 'fn' }, fieldLabel(f.field_name)), cell(f.old_value, 'old'), cell(f.new_value, 'new')])));
}

/* ================================================================ history */
function historyView() {
  const vs = [...S.tcp.versions].reverse();
  return h('ol', { class: 'timeline' }, vs.map((v) => {
    const prev = S.tcp.versions.find((x) => x.version_no === v.version_no - 1);
    const stageChanged = prev && prev.stage !== v.stage;
    return h('li', { class: `s-${v.status_code}` },
      h('span', { class: 'node', 'aria-hidden': 'true' }),
      h('div', { class: 'vcard' },
        h('div', { class: 'vcard-h' },
          h('h3', null, `v${v.version_no}`),
          h('span', { class: `pill ${v.status_code}` }, v.status),
          h('span', { class: 'date' }, v.published_on ? `Published ${fmtDate(v.published_on)}` : `Started ${fmtDate(v.created_on)}`),
          h('span', { class: 'spacer' }),
          h('button', { class: 'btn ghost sm', onclick: () => go({ tab: 'matrix', v: v.version_no }) }, 'View matrix'),
          v.version_no > 1 ? h('button', { class: 'btn sm', onclick: () => go({ tab: 'compare', from: v.version_no - 1, to: v.version_no }) }, `Compare with v${v.version_no - 1}`) : null),
        h('p', { class: 'reason' }, [v.edit_type, v.reason_for_edit].filter(Boolean).join(': ') || 'No reason recorded'),
        h('div', { class: 'facts' },
          h('span', null, 'Stage ', h('b', null, v.stage || '—'), stageChanged ? ` (was ${prev.stage || '—'})` : ''),
          h('span', null, !v.logged_changes ? 'No logged changes yet'
            : v.version_no === 1 ? ['First version, ', h('b', null, v.logged_changes), ' fields recorded']
            : [h('b', null, v.logged_changes), ' fields changed'])),
        v.snapshot_sha256 ? h('span', { class: 'hash', title: `SHA-256 ${v.snapshot_sha256}` }, `Fingerprint ${v.snapshot_sha256.slice(0, 16)}`) : null));
  }));
}

/* ================================================================ item history drawer */
async function itemHistory(type, key, title) {
  let rows;
  try { rows = await api('GET', `/tcps/${S.tcp.id}/item-history?item_type=${type}&item_key=${encodeURIComponent(key)}`); }
  catch (err) { return toast(err.message, 'error'); }
  const byVersion = new Map();
  for (const r of rows) {
    if (!byVersion.has(r.version_no)) byVersion.set(r.version_no, { published: r.published_on, change: r.change_type, rows: [] });
    byVersion.get(r.version_no).rows.push(r);
  }
  const dlg = h('dialog', { class: 'drawer', 'aria-label': `History of ${title}` },
    h('div', { class: 'drawer-body' },
      h('div', { class: 'drawer-head' },
        h('div', null, h('h2', null, title), h('p', { class: 'muted' }, 'Published changes, newest first. Changes in an open draft appear once it is published.')),
        h('button', { class: 'iconbtn', 'aria-label': 'Close', onclick: () => dlg.close() }, icon('close'))),
      byVersion.size ? [...byVersion.entries()].map(([vno, g]) => h('section', { class: 'hist-v' },
        h('h3', null, `v${vno}`, h('span', null, `${{ ADDED: 'Added', REMOVED: 'Removed', MODIFIED: 'Changed' }[g.change]} on ${fmtDate(g.published)}`)),
        [...g.rows].sort(byField).map((r) => h('div', { class: 'hist-row' },
          h('span', { class: 'fn' }, fieldLabel(r.field_name)),
          h('span', null, r.change_type === 'MODIFIED' ? `${r.old_value ?? '—'}  →  ${r.new_value ?? '—'}` : (r.new_value ?? r.old_value ?? '—'))))))
        : h('p', { class: 'dim' }, 'No published history yet.')));
  dlg.addEventListener('close', () => dlg.remove());
  document.body.append(dlg);
  dlg.showModal();
}

/* ================================================================ dialogs */
function modal({ title, message, fields = [], submit, danger, onSubmit }) {
  const err = h('p', { class: 'err', hidden: true });
  const btn = h('button', { class: `btn ${danger ? 'danger' : 'primary'}`, type: 'submit' }, submit);
  const form = h('form', { method: 'dialog' },
    h('h2', null, title), message ? h('p', { class: 'msg' }, message) : null, fields, err,
    h('div', { class: 'buttons' }, h('button', { class: 'btn ghost', type: 'button', onclick: () => dlg.close() }, 'Cancel'), btn));
  const dlg = h('dialog', { 'aria-label': title }, form);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    btn.disabled = true;
    err.hidden = true;
    try {
      await onSubmit(new FormData(form), form);
      dlg.close();
    } catch (ex) {
      err.textContent = ex.message;
      err.hidden = false;
    } finally {
      btn.disabled = false;
    }
  });
  dlg.addEventListener('close', () => dlg.remove());
  document.body.append(dlg);
  dlg.showModal();
  return dlg;
}

function confirmModal({ title, message, action, danger, run, done }) {
  modal({ title, message, submit: action, danger, onSubmit: async () => {
    await run();
    if (done) toast(done);
    await reloadTcp();
    await route();
  } });
}

const fld = (label, control) => h('label', { class: 'field' }, h('span', null, label), control);
const options = (list, labelKey, { blank } = {}) => [blank ? h('option', { value: '' }, blank) : null,
  list.map((o) => h('option', { value: o.id }, o[labelKey]))];

async function newProfileModal() {
  let targets = [];
  try { targets = await api('GET', '/targets'); } catch (err) { return toast(err.message, 'error'); }
  const newBox = h('div', { hidden: targets.length > 0, style: { display: 'grid', gap: '12px' } },
    fld('Target name', h('input', { type: 'text', name: 'target_name' })),
    fld('Program code (leave empty for a new program)', h('input', { type: 'text', name: 'pfr_code', placeholder: 'PFR code' })));
  const targetSel = h('select', { name: 'target', onchange: (e) => { newBox.hidden = e.target.value !== '__new'; } },
    targets.map((t) => h('option', { value: t.id }, t.name + (t.pfr_code || t.pfc_code ? ` (${t.pfr_code || t.pfc_code})` : ''))),
    h('option', { value: '__new', selected: !targets.length }, 'New target…'));
  modal({
    title: 'New profile',
    fields: [fld('Target', targetSel), newBox,
      fld('Profile name', h('input', { type: 'text', name: 'name', required: true, placeholder: 'e.g. Lead profile' })),
      fld('Stage', h('select', { name: 'stage_id' }, options(S.L.stages, 'name', { blank: '—' })))],
    submit: 'Create profile',
    onSubmit: async (fd) => {
      let targetId = fd.get('target');
      if (targetId === '__new') {
        const t = await api('POST', '/targets', { name: fd.get('target_name'), pfr_code: fd.get('pfr_code') || null });
        targetId = t.id;
      }
      const row = await api('POST', '/tcps', { target_research_id: targetId, name: fd.get('name'), stage_id: fd.get('stage_id') || null });
      S.tcps = await api('GET', '/tcps');
      S.tcp = null;
      toast(`Created ${fd.get('name')} with draft v1`);
      go({ tcp: row.id, v: 1, tab: 'matrix', from: null, to: null, p: null });
    },
  });
}

function startVersionModal() {
  const next = S.tcp.versions.at(-1).version_no + 1;
  modal({
    title: `Start v${next}`,
    message: 'The new version starts as a draft with the same content as the latest version. Only what you change gets a new revision.',
    fields: [
      fld('Type of change', h('select', { name: 'edit_type' },
        S.L.editTypes.filter((e) => e.code !== 'INITIAL').map((e) => h('option', { value: e.code }, e.label)))),
      fld('Reason for the change', h('textarea', { name: 'reason', rows: 3, placeholder: 'What prompted this version' })),
    ],
    submit: `Start v${next}`,
    onSubmit: async (fd) => {
      const r = await api('POST', `/tcps/${S.tcp.id}/versions`, { edit_type_code: fd.get('edit_type'), reason: fd.get('reason') || null });
      await reloadTcp();
      toast(`Started draft v${r.version_no}`);
      go({ v: r.version_no, tab: 'matrix' });
    },
  });
}

function publishModal(vno) {
  const n = S.draftDiff ? countItems(S.draftDiff) : null;
  modal({
    title: `Publish v${vno}?`,
    message: `It becomes the current version and can no longer be edited.${n != null ? ` ${n} item${n === 1 ? '' : 's'} changed since v${publishedNo()}.` : ''}`,
    submit: `Publish v${vno}`,
    onSubmit: async () => {
      await api('POST', `/tcps/${S.tcp.id}/publish`);
      await reloadTcp();
      toast(`Published v${vno}`);
      go({ v: vno });
    },
  });
}

function discardModal(vno) {
  modal({
    title: `Discard draft v${vno}?`,
    message: 'Every change made in this draft is deleted. Published versions are not affected.',
    submit: 'Discard draft', danger: true,
    onSubmit: async () => {
      await api('POST', `/tcps/${S.tcp.id}/discard`);
      await reloadTcp();
      toast(`Discarded draft v${vno}`);
      go({ v: publishedNo() || null, from: null, to: null });
    },
  });
}

function rejectModal(vno) {
  modal({
    title: `Return v${vno} to draft`,
    fields: [fld('Comment for the author', h('textarea', { name: 'comment', rows: 3 }))],
    submit: 'Return to draft',
    onSubmit: async (fd) => {
      await api('POST', `/tcps/${S.tcp.id}/reject`, { comment: fd.get('comment') || null });
      await reloadTcp();
      toast(`Returned v${vno} to draft`);
      route();
    },
  });
}

function addPillarModal() {
  const used = new Set(S.matrix.pillars.map((p) => String(p.pillar_id)));
  const free = S.L.pillars.filter((p) => !used.has(String(p.id)));
  const total = S.matrix.pillars.reduce((s, p) => s + Number(p.weight || 0), 0);
  const newName = h('label', { class: 'field', hidden: free.length > 0 },
    h('span', null, 'New pillar name'), h('input', { type: 'text', name: 'new_name' }));
  modal({
    title: 'Add pillar',
    fields: [
      fld('Pillar', h('select', { name: 'pillar', onchange: (e) => { newName.hidden = e.target.value !== '__new'; } },
        free.map((p) => h('option', { value: p.id }, p.name)), h('option', { value: '__new', selected: !free.length }, 'New pillar…'))),
      newName,
      fld('Weight', h('input', { type: 'number', name: 'weight', min: 0, max: 100, step: 'any', value: String(Math.max(0, 100 - total)) })),
      fld('Key design principle', h('textarea', { name: 'kdp', rows: 2, required: true, placeholder: 'The question this pillar answers' })),
      fld('Category', h('input', { type: 'text', name: 'category' })),
    ],
    submit: 'Add pillar',
    onSubmit: async (fd) => {
      let pillarId = fd.get('pillar');
      if (pillarId === '__new') {
        const p = await api('POST', '/pillars', { name: fd.get('new_name') });
        S.L.pillars.push(p);
        pillarId = p.id;
      }
      const maxSeq = Math.max(0, ...S.matrix.pillars.map((p) => p.sequence || 0));
      const r = await api('POST', `/tcps/${S.tcp.id}/pillars`, {
        pillar_id: Number(pillarId), weight: Number(fd.get('weight') || 0),
        key_design_principle: fd.get('kdp'), design_principle_category: fd.get('category') || null,
        sequence: maxSeq + 10,
      });
      S.pillarId = String(r.id);
      await loadMatrix();
      history.replaceState(null, '', hashOf({ ...readHash(), p: r.id }));
      render();
    },
  });
}

function newAttributeModal(p, ct) {
  modal({
    title: 'New attribute',
    message: `It is added to ${ct.label} in ${p.pillar_name} and becomes available to every profile.`,
    fields: [
      fld('Name', h('input', { type: 'text', name: 'name', required: true, placeholder: 'e.g. Kinetic solubility' })),
      fld('Measured as', h('select', { name: 'data_type_id' }, S.L.dataTypes.map((d) => h('option', { value: d.id }, d.label)))),
      fld('Default unit', h('select', { name: 'unit' }, options(S.L.units, 'symbol', { blank: 'No unit' }))),
    ],
    submit: 'Add attribute',
    onSubmit: async (fd) => {
      const a = await api('POST', '/attributes', { name: fd.get('name'), data_type_id: Number(fd.get('data_type_id')), default_unit_id: fd.get('unit') || null });
      S.L.attributes.push(a);
      S.L.attributes.sort((x, y) => x.name.localeCompare(y.name));
      await addParameter(p, ct, a.id);
    },
  });
}

/* ================================================================ start */
window.addEventListener('hashchange', route);
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && S.sheet && !document.querySelector('dialog[open]')) { S.sheet = false; render(); }
});
(async function init() {
  try {
    S.health = await api('GET', '/health');
    if (!S.health.ok) { S.loading = false; return render(); }
    [S.L, S.tcps] = await Promise.all([api('GET', '/lookups'), api('GET', '/tcps')]);
  } catch (err) {
    S.health = { ok: false, message: err.message, database: 'unknown' };
    S.loading = false;
    return render();
  }
  route();
})();
